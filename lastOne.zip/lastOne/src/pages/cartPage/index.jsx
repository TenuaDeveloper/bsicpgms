import Cart from "components/layout/cartitems/index";
import SearchBar from "components/searchbar/searchbar";
import "./index.scss";

/**
 * Needs to refector screen in feature
 * @param {*} props 
 * @returns 
 */
const CartPage = (props) => {
  return (
    <div className="cartpage">
      <div className="container"> 
      <SearchBar/>
      <Cart {...props} />
      </div>
    </div>
  );
}

export default CartPage;