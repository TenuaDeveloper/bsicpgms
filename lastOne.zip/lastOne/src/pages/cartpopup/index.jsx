import { useState, useEffect } from "react";
import CartPopupComp from "components/layout/cartitems/popupComp/cartPopup";
// import SearchBar from "components/searchbar/searchbar";
import "./index.scss";
import { Dialog } from "primereact/dialog";
import carticon from "assets/images/icons/carticon.svg";
import { connect } from "react-redux";
import { changeCartPopupStatusReducer } from "redux/features/cart/cartPopupSlice";
import { useDispatch } from "react-redux";
import { Sidebar } from "primereact/sidebar";

/**
 * Needs to refector screen in feature
 * @param {*} props
 * @returns
 */
const CartPopup = (cartPopupStatus) => {
  const dispatch = useDispatch();
  const [visible, setVisible] = useState(false);

  // if (cartPopupStatus && !visible) {
  //   setVisible(true);
  // }

  useEffect(() => {
    if (cartPopupStatus.cartPopupStatus) {
      setVisible(cartPopupStatus.cartPopupStatus);
    }
  }, [cartPopupStatus, dispatch]);

  const dialogHeader = () => {
    return (
      <div className="cartpopup__header">
        <img src={carticon} alt="cart" className="cartComp__cartChange" />
        <a className="cartComp__shoppingcarttext"> &nbsp;&nbsp;Shopping Cart</a>
      </div>
    );
  };

  const handleVisible = (value) => {
    console.log(value);
    setVisible(value);
    dispatch(changeCartPopupStatusReducer(value));
  };
  const customHeader = (
    <>
      <div className="d-flex shopping-cart-header w-100">
        <i className="pi pi-shopping-bag"></i>
        <h3 className="mb-0">Shopping Cart</h3>
      </div>
    </>
  );

  return (
    <div className="cartpopup">
      {/* {console.log(visible)} */}
      {/* <Dialog
        header={dialogHeader}
        visible={visible}
        position="top-right"
        style={{ width: "50vw" }}
        onHide={() => handleVisible(false)}
        draggable={false}
        resizable={false}
      >
        <p className="m-0">
          <CartPopupComp />
        </p>
      </Dialog> */}
      <Sidebar
        visible={visible}
        icons={customHeader}
        style={{ width: "50vw" }}
        position="right"
        className="shopping-cart-sidebar"
        onHide={() => handleVisible(false)}
      >
        <CartPopupComp />
      </Sidebar>
    </div>
  );
};

const mapStateToProps = (state) => {
  return {
    cartPopupStatus: state.cartPopupStatus.cartPopupStatus,
  };
};

const mapDispatchToProps = {
  // fetchCartPopupStatus: cartPopupStatusActions.fetchCartPopupStatus,
};

export default connect(mapStateToProps, mapDispatchToProps)(CartPopup);
