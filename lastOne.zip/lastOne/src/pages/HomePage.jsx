import FlightTicket from "components/layout/topsection/Flightticket";
import ProductCard from "components/product-card/ProductCard";
import SearchBar from "components/searchbar/searchbar";
import { Dropdown } from "primereact/dropdown";
import { useEffect, useState } from "react";
import { connect, useDispatch, useSelector } from "react-redux";
import { arrivalActions } from "redux/features/newArrivalsFilter/newarrivalSlice";
import { selectedTerminalValue } from "redux/features/terminal/selectedTerminal";
import {
  terminalActions
} from "redux/features/terminal/terminalSlice";
import { offerActions } from "../redux/features/airportOffers/offerSlice";
import { serviceActions } from "../redux/features/airportService/airportServiceSlice";
import "./homepage.scss";
// import {terminalActions} from "redux/features/terminal/"
// import Flight from "components/layout/topsection/flight";
// import { personalizedServicesAndOffersActions } from "redux/features/personalizedServices/personalizedServicesSlice";
import Flight from "components/layout/topsection/ChooseWidget";
import Spotlight from "components/spotlight/Spotlight";
import { getItemInCartAPI } from "redux/features/cart/cartAction";
import { personalizedServicesAndOffersActions } from "redux/features/newPersonalizedServices/newPersonalizedServicesSlice";
import { getPinFlight, getPinInspiration, getPinPickupDrop } from 'redux/features/pingFlight/pinAction';
import { recommendedCategoriesActions } from "redux/features/recommendedCategories/recommendedCategoriesSlice";
import { preferenceActions } from "redux/features/preference/preferenceAction";
import { getWishList } from "redux/features/wishlist/wishlistAction";
import CartPopup from "./cartpopup";

const HomePage = ({
  services,
  offers,
  fetchServices,
  fetchOffers,
  fetchTerminals,
  fetchNewArrivals,
  // servicesAndOffersTerminal,
  fetchRecommendedCategories,
  recommendedCategories,
  fetchPersonalizedServicesAndOffers,
  // personalizedServicesAndOffers,
  userInfo,
  fetchExistingPreference,
  userpreference,
  // fetchPersonalizedServicesAndOffersPaginated,
  // personalizedServicesAndOffersPaginated,
  searchCategory,
  newPersonalizedServicesAndOffers
}) => {
  const [terminalData, setTerminalData] = useState([]);
  const terminalDataRed = useSelector((state) => state.terminals.terminals);
  const [terminaltitle, setTerminalTitle] = useState("Choose a Terminal...");
  const [selectedTerminal, setSelectedTerminal] = useState({});
  const [slectedArrivals, setselectedArrivals] = useState("");
  const selectedOption = useSelector(state => state.common.option)
  // console.log("Arrivals",arrivals)
  //console.log("Services Offers Terminals",servicesAndOffersTerminal)
  //console.log("Selected terminal",selectedTerminal)
  // const searchCategory = useSelector(
  //   (state) => state.SearchCategoryResults.SearchCategoryResults
  // );
  // const selectedTerminalData = useSelector(
  //   (state) => state.servicesAndOffersTerminal.servicesAndOffersTerminal
  // );
  function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) 
   { 
     const j = Math.floor(Math.random() * (i + 1)); [array[i], array[j]] = [array[j], array[i]]; } 
     return array; 
 } 
 const selectedTerminalData = useSelector(
   (state) => state.arrivals.newArrivals
 );
// console.log(selectedTerminalData,"selectedTerminalData")
const terminalOffers = selectedTerminalData?.serachResult?.[0]?.offer || []; 
  const popular = selectedTerminalData?.serachResult?.[0]?.popular || []; 
  const promotions = selectedTerminalData?.serachResult?.[0]?.promotions || []; 
  const terminalServices = selectedTerminalData?.serachResult?.[0]?.services || []; 
  //const allProducts = [...terminalOffers, ...popular, ...promotions, ...terminalServices]; 
 const allProducts = [ ...(Array.isArray(terminalOffers) ? terminalOffers : []), ...(Array.isArray(popular) ? popular : []), ...(Array.isArray(promotions) ? promotions : []), ...(Array.isArray(terminalServices) ? terminalServices : []) ];
  // console.log(allProducts,"allproducts")
  const shuffledProducts = shuffleArray(allProducts);
  // console.log(shuffledProducts,"shuffledProducts")
  const arrivalData = useSelector((state) => state.arrivals.newArrivals);
  const arrivalSubData = arrivalData?.serachResult?.[0] || {};
 //console.log("Selected Terminal Data===>",selectedTerminalData)
  // console.log("searchCategory", searchCategory)
  const dispatch = useDispatch();
  const arrivalOptions = Object.keys(arrivalSubData).filter((item) =>
    Array.isArray(arrivalSubData[item])
  );


  const [flightTerminalValue, setFlightTerminalValue] = useState(null);
  const [dropdownTerminalValue, setDropdownTerminalValue] = useState(null);
  const [inspirationTerminalValue, setInspirationTerminalValue] = useState(null);
  const [flightValue, setFlightValue] = useState(null);
  const [selectedPageNo, setSelectedPageNo] = useState(newPersonalizedServicesAndOffers && newPersonalizedServicesAndOffers.pageNo ? newPersonalizedServicesAndOffers.pageNo : 1);
  const [filterParams, setFilterParams] = useState("");
  const prefrencesList = recommendedCategories && recommendedCategories.items ? Object.keys(recommendedCategories.items) : [];

  useEffect(() => {
    fetchServices();
    fetchOffers();
    fetchTerminals();
    // fetchNewArrivals();
    if (userInfo) {
      fetchRecommendedCategories({"user_id": `${userInfo.memberId}`});
      // fetchPersonalizedServicesAndOffers({ "user_id": `${userInfo.memberId}` });
      dispatch(getPinFlight({ token: userInfo?.accessToken }))
      dispatch(getPinPickupDrop({ token: userInfo?.accessToken }))
      dispatch(getPinInspiration({ token: userInfo?.accessToken }))
      fetchExistingPreference({ token: userInfo.accessToken });
    }
    // if(recommendedCategories && recommendedCategories.items) {
    //   fetchPersonalizedServicesAndOffers({"req":{"productCategories" : Object.keys(recommendedCategories.items)}})      
    // }
    // if (personalizedServicesAndOffers && personalizedServicesAndOffers.resultData) {
      // fetchPersonalizedServicesAndOffersPaginated({ "resultData": personalizedServicesAndOffers.resultData, "pageNo": selectedPageNo })
    // }
    if (userInfo) {
      dispatch(getItemInCartAPI({ token: userInfo?.accessToken }));
      dispatch(getWishList({ token: userInfo?.accessToken }))
    }
    if(userInfo && userInfo.memberId!==0 && recommendedCategories && recommendedCategories.items) {
      fetchPersonalizedServicesAndOffers({"filter": `filterType=`, "selectedPageNo": selectedPageNo, "req":{"productCategories" : Object.keys(recommendedCategories.items)}, "filterType": ""})      
    }
    else if(userInfo && userpreference && userpreference.userpreference) {
        fetchPersonalizedServicesAndOffers({"filter": `filterType=`, "selectedPageNo": selectedPageNo, "req":{"productCategories" : userpreference.userpreference}, "filterType": ""})      
      }
     else if(userInfo && recommendedCategories && recommendedCategories.items) {
        fetchPersonalizedServicesAndOffers({"filter": `filterType=`, "selectedPageNo": selectedPageNo, "req":{"productCategories" : Object.keys(recommendedCategories.items)}, "filterType": ""})      
      }
      else {
        fetchPersonalizedServicesAndOffers({"filter": `filterType=`, "selectedPageNo": selectedPageNo, "req":{"productCategories" : []}, "filterType": ""});
      }
     }, [fetchOffers, dispatch, fetchTerminals]);

 const servicesAndOffers = services.concat(offers);
  // console.log(servicesAndOffers,"servicesAndOffers")
  // const shuffledServicesAndOffers = servicesAndOffers
  //   .map((value) => ({ value, sort: Math.random() }))
  //   .sort((a, b) => a.sort - b.sort)
  //   .map(({ value }) => value);
  const filteredPremiumItems = servicesAndOffers &&
  servicesAndOffers.length > 0 && servicesAndOffers.reduce((acc, service) => {
    
    if (service.serviceName == "Valet Parking" || service.serviceName == 'Al Safwa First Lounge') {
      if (acc.length === 0 || acc[acc.length - 1].length === 2) {
        acc.push([service]);
      } else {
        acc[acc.length - 1].push(service);
      }
    }
    return acc;
  }, []);
  
//  const filteredPremiumItems = services.filter(service => service.serviceName == "Valet Parking" || service.serviceName == 'VIP Lounge');
  // console.log(filteredPremiumItems,"filteredPremiumItems")
  // console.log(service,)
  useEffect(() => {
    if (flightTerminalValue) {
     console.log(flightTerminalValue,"****************flightTerminalValue*******");
      handleSelectTerminal(flightTerminalValue);
    }
    else{
      setSelectedTerminal({})
    }
    // //
    // else if (dropdownTerminalValue) {
    //   // console.log(dropdownTerminalValue);
    //   handleSelectTerminal(dropdownTerminalValue);
    // }
    // else if (inspirationTerminalValue) {
    //   // console.log(inspirationTerminalValue);
    //   handleSelectTerminal(inspirationTerminalValue);
    // }
  }, [flightTerminalValue, dropdownTerminalValue, inspirationTerminalValue]);

  //console.log("inside HomePage",flightTerminalValue)
  const handleSelectTerminal = (key) => {
    const selectedTerminalNo = terminalDataRed.find((it) => it.id === key);
    //console.log("selectedTerminalNo ==>",selectedTerminalNo);
    setSelectedTerminal({ key, value: selectedTerminalNo?.terminalName });
    console.log("Selected key value ==>", terminalDataRed, key);
    setselectedArrivals("");

    if (key !== "") {
      console.log(selectedTerminalNo?.terminalNumber,"terminalNumber")
      // dispatch(
      //   servicesAndOffersTerminalSliceAction.fetchServicesAndOffersTerminal(
      //     selectedTerminalNo?.terminalNumber
      //   )
      dispatch(
        arrivalActions.fetchNewArrivals( {
          "terminal":`terminal=${ selectedTerminalNo?.terminalNumber}`
        }
        )
      );
      // dispatch(
      //   selectedTerminalValue({
      //     option: selectedTerminalNo ? selectedTerminalNo.terminalNumber : "",
      //   })
      // );
      setTerminalTitle(
        selectedTerminalNo
          ? "Terminal " + selectedTerminalNo.terminalNumber
          : "Choose a Terminal"
      );
    } else {
      dispatch(selectedTerminalValue({ option: "" }));
      setTerminalTitle("Choose a Terminal");
    }
  };

  const handlePageNo = () => {
    // if (recommendedCategories && recommendedCategories.items && personalizedServicesAndOffers && personalizedServicesAndOffers.resultData) {
    //   fetchPersonalizedServicesAndOffersPaginated({ "resultData": personalizedServicesAndOffers.resultData, "pageNo": selectedPageNo + 1 })
    // }
    fetchPersonalizedServicesAndOffers({"filter": `filterType=${slectedArrivals}${filterParams}`, "selectedPageNo": selectedPageNo+1, "req":{"productCategories" : prefrencesList}, "filterType": slectedArrivals});
    setSelectedPageNo(selectedPageNo + 1);
  }
  const arrivaloptions = [
    // { label: "Select ", value: "new" },
    { label: "New Arrivals", value: "new" },
    { label: "Popular", value: "popular" },
    { label: "Promotions", value: "promotions" },
    // { label: "Services", value: "Services" },
  ];

  // const reloadarrival = () => {
  //   dispatch(fetchNewArrivals());
  // }

  const handleFilter = (val) => {
    setselectedArrivals(arrivaloptions.find(item => item.value == val).value)
    fetchPersonalizedServicesAndOffers({"filter": `filterType=${val}${filterParams}`, "selectedPageNo": selectedPageNo, "req":{"productCategories" : prefrencesList}, "filterType": arrivaloptions.find(item => item.value == val).value});
  }

  return (
    <div className="home">
      <Spotlight />
      <Flight setFlightValue={setFlightTerminalValue} setDropdownValue={setDropdownTerminalValue} setInspirationValue={setInspirationTerminalValue} setFilterParams={setFilterParams} setselectedArrivals={setselectedArrivals} />
      {/* <Slider />
      <Flight setFlightValue={setFlightTerminalValue} setDropdownValue={setDropdownTerminalValue} setInspirationValue={setInspirationTerminalValue} /> */}
      <section className="l-section">
        <div className="container">
          <SearchBar />
          {selectedOption === 'flight' ? <FlightTicket /> : null}
          <div className="l-title">
            <div className="d-flex align-items-center home__reco">
              <h2 className="mb-0">Recommended Products</h2>
              <div className="card d-flex  justify-content-end prdfilter">
                <Dropdown
                style={{ width: "165px" }}
                value={selectedTerminal.key}
                onChange={(e) => handleSelectTerminal(e.value)}
                options={terminalDataRed}
                virtualScrollerOptions={{ itemSize: 38 }}
                placeholder="Select Terminal"
                className="w-full md:w-14rem"
                optionLabel="terminalName"
                optionValue="id"
                disabled={flightTerminalValue ? true : false}
              />
                    <div>
                  </div>
                <Dropdown
                  style={{ width: "165px" }}
                  value={slectedArrivals}
                  options={arrivaloptions}
                  virtualScrollerOptions={{ itemSize: 38 }}
                  placeholder="Select Filter"
                  className="w-full md:w-14rem"
                  onChange={(e) => handleFilter(e.value)}
                  // onClick={reloadarrival}
                />
              </div>
            </div>
          </div>
          {/* {personalizedServicesAndOffersPaginated &&
          personalizedServicesAndOffersPaginated.servicesAndOffers &&
          personalizedServicesAndOffersPaginated.servicesAndOffers.length > 0 ?
          <ProductCard
            products={personalizedServicesAndOffersPaginated.servicesAndOffers}
            prem={(filteredPremiumItems)} />
          : <>
            {slectedArrivals !== "" ? (
              <ProductCard
                products={arrivalSubData[slectedArrivals]}
                prem={filteredPremiumItems}
              />
            ) : searchCategory.length > 0 ? (
              <ProductCard
                products={searchCategory}
                prem={filteredPremiumItems}
              />
            ) : (
              <>
                {selectedTerminal && selectedTerminal.key ? (
                  <ProductCard
                    products={selectedTerminalData}
                    prem={filteredPremiumItems}
                  />
                ) : (
                  <ProductCard
                    products={shuffledServicesAndOffers && shuffledServicesAndOffers.length > 12 ? shuffledServicesAndOffers.slice(0, 12) : shuffledServicesAndOffers}
                    prem={filteredPremiumItems}
                  />
                )}
              </>
            )}
          </>
        } */}
          {/* {searchCategory && searchCategory.length > 0 ? (
            <ProductCard
              products={searchCategory && searchCategory.length > 32 ? searchCategory.slice(0, 32) : searchCategory}
              prem={filteredPremiumItems}
            />
          ) : (
            <>
              {personalizedServicesAndOffersPaginated &&
                personalizedServicesAndOffersPaginated.servicesAndOffers &&
                personalizedServicesAndOffersPaginated.servicesAndOffers.length > 0 ?
                <ProductCard
                  products={personalizedServicesAndOffersPaginated.servicesAndOffers}
                  prem={(filteredPremiumItems)} />
                : <>
                  {slectedArrivals !== "" ? (
                    <ProductCard
                      products={arrivalSubData[slectedArrivals]}
                      prem={filteredPremiumItems}
                    />
                  ) : (
                    <>
                      {selectedTerminal && selectedTerminal.key ? (
                        <ProductCard
                          products={selectedTerminalData}
                          prem={filteredPremiumItems}
                        />
                      ) : (
                        <ProductCard
                          products={shuffledServicesAndOffers && shuffledServicesAndOffers.length > 12 ? shuffledServicesAndOffers.slice(0, 12) : shuffledServicesAndOffers}
                          prem={filteredPremiumItems}
                        />
                      )}
                    </>
                  )}
                </>
              }
            </>
          )} */}
          {searchCategory && searchCategory.length > 0 ? (
            <ProductCard
              products={searchCategory && searchCategory.length > 32 ? searchCategory.slice(0, 32) : searchCategory}
              prem={filteredPremiumItems}              
              wishlist={false}
            />
          ) :
          (
            <>
              {selectedTerminal && selectedTerminal.key ? (
                <ProductCard
                  products={allProducts}
                  prem={filteredPremiumItems}               
                  wishlist={false}
                />
              ) : 
              <>
              {newPersonalizedServicesAndOffers &&
                    newPersonalizedServicesAndOffers.servicesAndOffers &&
                    newPersonalizedServicesAndOffers.servicesAndOffers.length > 0 &&
                    <ProductCard
                      products={newPersonalizedServicesAndOffers.servicesAndOffers}
                      prem={(filteredPremiumItems)}               
                      wishlist={false} />
            }</>
              }
            </>
          )



          
        //   <>
        //   {newPersonalizedServicesAndOffers &&
        //         newPersonalizedServicesAndOffers.servicesAndOffers &&
        //         newPersonalizedServicesAndOffers.servicesAndOffers.length > 0 &&
        //         <ProductCard
        //           products={newPersonalizedServicesAndOffers.servicesAndOffers}
        //           prem={(filteredPremiumItems)} />
        // }</>
        }
        <a className="home__viewmore" onClick={handlePageNo}>View More...</a>
        </div>
      </section>
      <section className="l-section">
        <div className="container">
          <div className="l-title">
            <div className="d-flex align-items-center">
              <h2 className="mb-0">Today's Deal</h2>
            </div>
          </div>
          <ProductCard products={offers && offers.length > 8 ? offers.slice(0, 4) : offers}               
              wishlist={false}/>
          <a className="home__viewmore">View More...</a>
        </div>
      </section>
      <CartPopup />
    </div>
  );
};

const mapStateToProps = (state) => {
  return {
    services: state.services.services,
    offers: state.offers.offers,
    recommendedCategories: state.recommendedCategories.recommendedCategories,
    userpreference: state.preference.userpreference,
    // personalizedServicesAndOffers: state.personalizedServicesAndOffers.personalizedServicesAndOffers,
    userInfo: state.auth.userInfo,
    // personalizedServicesAndOffersPaginated: state.personalizedServicesAndOffersPaginated.personalizedServicesAndOffersPaginated,
    servicesAndOffersTerminal: state.servicesAndOffersTerminal.servicesAndOffersTerminal,
    searchCategory: state.SearchCategoryResults.SearchCategoryResults,
    newPersonalizedServicesAndOffers: state.newPersonalizedServicesAndOffers.newPersonalizedServicesAndOffers,
  };
};

const mapDispatchToProps = {
  fetchServices: serviceActions.fetchServices,
  fetchOffers: offerActions.fetchOffers,
  fetchTerminals: terminalActions.fetchTerminals,
  fetchRecommendedCategories: recommendedCategoriesActions.fetchRecommendedCategories,
  fetchExistingPreference: preferenceActions.fetchExistingPreference,
  fetchPersonalizedServicesAndOffers: personalizedServicesAndOffersActions.fetchPersonalizedServicesAndOffers,
  // fetchPersonalizedServicesAndOffersPaginated: personalizedServicesAndOffersPaginatedActions.fetchPersonalizedServicesAndOffersPaginated,
  fetchNewArrivals: arrivalActions.fetchNewArrivals,
};

export default connect(mapStateToProps, mapDispatchToProps)(HomePage);
