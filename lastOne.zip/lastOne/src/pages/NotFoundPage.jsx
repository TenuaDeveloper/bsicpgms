import notFoundImg from "assets/images/404.svg";

const NotFoundPage = () => {
  return (
    <div className="l-not-found">
      <img src={notFoundImg} alt="not-found" width="200" height="200" />
    </div>
  );
}

export default NotFoundPage;