import React, { useState, useEffect, createContext } from "react";
import { useSelector, useDispatch } from 'react-redux';
import axios from "axios";
import { fetchFav, deleteFav } from '../redux/features/fav/favAction';
const backendURL = process.env.REACT_APP_REST_API_URL || "http://localhost:8080";
const GET_FAV_URL =  backendURL +"/api/v1/favourites/listFavouriteItems";

const FavouritesContext = createContext();

export const FavouritesProvider = ({ children }) => {
  const dispatch = useDispatch();
  const [favourites, setFavourites] = useState([]);
  const favoriteItems = useSelector((state) => state.favoriteItems.favoriteItems);

  // Add your bearer token here
  const bearerToken = localStorage.getItem('userToken')
    ? localStorage.getItem('userToken')
    : null;

  // Fetch favourite items from the API
  useEffect(() => {
    if (bearerToken) {
      axios
      .get(GET_FAV_URL, {
          headers: {
            Authorization: `Bearer ${bearerToken}`,
          },
        })
        .then((response) => {
          setFavourites(response.data);
        })        
        .catch((error) => console.error(error));
    }
  }, [bearerToken]);


  const addToFavourites = (item) => {
    let data = { 'service_id': item };
    dispatch(fetchFav(data));
    console.log("******************item added to favourite*************",item)
  };

  const removeFromFavourites = (itemId) => {
    let data = itemId;
    dispatch(deleteFav(data));
    console.log("******************item removed from favourite*************")
  };

  const isFavourite = (itemId) => {
    if (Array.isArray(favourites)) {
      return favourites.some((item) => item.id === itemId);
    }
    return false;
  };
    

  return (
   <FavouritesContext.Provider
  value={{ favourites, addToFavourites, removeFromFavourites, isFavourite }}
>
  {children}
</FavouritesContext.Provider>
  );
};

export default FavouritesContext;
