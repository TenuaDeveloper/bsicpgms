import React, { useContext, useEffect, useState } from 'react';
import ProductCard from "components/product-card/ProductCard";
import FavouritesContext from '../../context/FavouritesContext';
import "../product-card/product-card.scss";

function AddtoFav() {
  const { favourites, removeFromFavourites } = useContext(FavouritesContext);
  const [favItems, setFavItems] = useState(favourites);

  useEffect(() => {
    setFavItems(favourites);
  }, [favourites]);

  if (!favItems) {
    return <div>Loading...</div>;
  }

  return (
    <div className="container py-5">
      <div className="favourites__header d-flex align-items-center">
              <i className="pi pi-heart"></i>
              <h3 className="mb-0">
              &nbsp;  Your Favourites ({favItems.length}
                &nbsp;items)
              </h3>
            </div>
      <div className="row"></div>
      <div className="row pt-2">
      {favItems.length === 0 ? (
          <h1>No favourites found</h1>
        ) : (
          
            <div>
              <ProductCard
                products={favItems}
                prem={[]}
              />
            </div>
         
        )}
      </div>
    </div>
  );
}

export default AddtoFav;
