
import React, { useState, useEffect, useContext} from "react";
import "./product-card.scss";
import { Rating } from 'primereact/rating';
import { Dialog } from 'primereact/dialog';
import { fetchWishList, deleteWishList, addToWishList, deleteFromWishList, getWishList } from '../../redux/features/wishlist/wishlistAction';
import { useSelector, useDispatch } from 'react-redux';
import { Button } from 'primereact/button';
import { fetchFavourites } from '../../redux/features/fav/favouriteSlice';
import Popup from '../popupcomponent/Popup';
import Pop from '../popupcomponent/Pop';
import MyPopup from '../popupcomponent/MyPopup';
import PopupNew from "../popupcomponent/PopupNew";
import {addToCart, cartError} from '../../redux/features/cart/cartslice';
import {addToCartAPI} from "../../redux/features/cart/cartAction";
import { getItemInCartAPI } from "../../redux/features/cart/cartAction";
import { connect } from "react-redux";
import { changeCartPopupStatusReducer } from "redux/features/cart/cartPopupSlice";
import offerCard from "../../assets/images/icon-offer-vertical.svg"
import newCard from "../../assets/images/icon-new-vertical.svg"
import FavouritesContext from '../../context/FavouritesContext';
import { useNavigate, useParams } from 'react-router-dom';

const ProductCard = ({ products, prem, isfav, iswishlisted, isAdded, showSavedtoCart=true, cartPopupStatus, fetchCartPopupStatus, wishlist }) => {
  
  const navigate = useNavigate();
  const params = useParams();

  const [visible, setVisible] = useState(params && params.serviceId && products && products.find(item => item.id == params.serviceId) ? true : false);
  const [wishicon, setWishicon] = useState(iswishlisted ? true : false);
  const [favicon, setFavIcon] = useState(isfav ? true : false);
  const [wishlistSelectedProduct, setWishlistSelectedProduct] = useState([]);
  const [favSelectedProduct, setFavSelectedProduct] = useState([]);
  const [popvisible, setpopVisible] = useState(params && params.serviceId && products && products.find(item => item.id == params.serviceId) ? true : false);
  const [showSecPopup, setShowSecPopup] = useState(false);
  const [formData, setFormData] = useState({});
  const [selectedProduct, setSelectedProduct] = useState(params && params.serviceId && products && products.find(item => item.id == params.serviceId) ? products.find(item => item.id == params.serviceId) :null);
  const dispatch = useDispatch();
  const [favSelecteded, setFavSelecteded] = useState([]);
  
   // selectors
 const { userInfo } = useSelector((state) => state.auth);
 const selectedFlights  = useSelector((state) => state.flight.flightList.filter(item => item.selected));
 const selectedPickups  = useSelector((state) => state.pickupDrop.pickupDropList.filter(item => item.selected));
 const selectedInspirations  = useSelector((state) => state.inspiration.inspirationList.filter(item => item.selected));
 const {inspirationList}  = useSelector((state) => state.inspiration);
 const {pickupDropList}  = useSelector((state) => state.pickupDrop);
 const {flightList}  = useSelector((state) => state.flight);
 const optionType = useSelector(state => state.common.option)
 const favourite = useSelector(state => state.favourite.favourite)
 const { favourites, addToFavourites, removeFromFavourites, isFavourite, favoriteItems } = useContext(FavouritesContext);
 
  const handleHide = () => {
    setVisible(false);
    setpopVisible(false);
    navigate('/home');
    // setShowSecPopup(false);
  };
  const GetPricePopup = (product) => {
    if(wishlist) {
      if (userInfo) {
        dispatch(deleteWishList(product.id));
        // console.log("input data of delete wishlist is", wishproduct.id)
        dispatch(getWishList({ token: userInfo.accessToken }))
      } else {
        dispatch(deleteFromWishList(product.id));
        // console.log("delete wishlist is", wishproduct.id)
      }
    }
    setVisible(true)
    navigate(`/home/service/${product.id}`);
    setSelectedProduct(product)
  };
  const cartPopup = (product) => {
    if(wishlist) {
    if (userInfo) {
      dispatch(deleteWishList(product.id));
      // console.log("input data of delete wishlist is", wishproduct.id)
      dispatch(getWishList({ token: userInfo.accessToken }))
    } else {
      dispatch(deleteFromWishList(product.id));
      // console.log("delete wishlist is", wishproduct.id)
    }
  }
    setpopVisible(true)    
    navigate(`/home/service/${product.id}`);
    setSelectedProduct(product)
  }
  function handlePopupSecCloses() {
    setShowSecPopup(false);
    setVisible(false);
    
  }
  const handleYesWithFormData = (formData) => {
    setVisible(false);
    setShowSecPopup(true);
    // navigate(`/service/${product.id}`);
    // console.log("Product to be upgraded:", prem);
    console.log("Received formData in ProductCard:", formData);
    setFormData(formData);
    
  };

  useEffect(() => {
    setFavIcon(isfav ? true : false);
    setWishicon(isAdded ? true : false);
    if (userInfo) {
      dispatch(getWishList({ token: userInfo.accessToken }));
      dispatch(fetchFavourites({ token: userInfo.accessToken }));
      // dispatch(getItemInCartAPI({ token: userInfo?.accessToken }));
    }
  }, [isfav, isAdded, dispatch, userInfo]);

  const getProductCartDesc = (description) => {
    let result = "";
    if (description && description[0] && description[0].length > 50) {
      result = description[0].match(/.{1,55}/) ?? [0];
      result = `${result}...`;
    } else {
      result = description[0];
    }
    return result;
  }

  function handleAddToWishList(wishproduct) {
    let data = wishlistSelectedProduct;
    const ifExists = wishlistSelectedProduct.find(item => item == wishproduct.id);
    if (!ifExists) {
      data.push(wishproduct.id)
      setWishlistSelectedProduct(data);
    } else {
      const index = favSelectedProduct.indexOf(wishproduct.id);
      data.splice(index, 1);
      setWishlistSelectedProduct(data)
    }

    //   console.log("wish values : ", wishproduct.id)
    //   console.log("isAdded : ", isAdded)
    // dispatch(getWishList({token: userInfo.accessToken}))
    let inputData = { 'serviceId': wishproduct.id };
    if (!ifExists) {
      if (userInfo) {
        dispatch(fetchWishList(inputData));
        // console.log("input data of wishlist is", inputData)
        dispatch(getWishList({ token: userInfo.accessToken }))
      }
      else {
        dispatch(addToWishList(wishproduct));
        // console.log("wishproduct is", wishproduct)
      }
      setWishicon(true)

    } else {
      if (userInfo) {
        dispatch(deleteWishList(wishproduct.id));
        // console.log("input data of delete wishlist is", wishproduct.id)
        dispatch(getWishList({ token: userInfo.accessToken }))
      } else {
        dispatch(deleteFromWishList(wishproduct.id));
        // console.log("delete wishlist is", wishproduct.id)
      }
      setWishicon(false)

    }
  }

  function handleAddToFavourites(favproduct) {
    const ifExists = favourite.find(item => item.id === favproduct.id);
    if (ifExists) {
      removeFromFavourites(favproduct.id);
      dispatch(fetchFavourites({ token: userInfo.accessToken }));
    } else {
      addToFavourites(favproduct.id);
      dispatch(fetchFavourites({ token: userInfo.accessToken }));
    }
  }

  function hasFavoriteProduct(product, favourite) {
    const id = product.id
    if (favourite.some((favourites) => favourites.id === id)) {
      return true;
    }
    return false;
  }

  const isFav = [];

  for (let i = 0; i < products.length; i++) {
    const product = products[i];
    isFav[product.id] = hasFavoriteProduct(product, favourite);
  }

  // function handleAddToFavourites(favproduct) {
  //   const favSelectedProductVal = [].concat(favSelecteded, favproduct.id);
  //   // favSelectedProductVal.push[favproduct.id]
  //   console.log(favproduct.id, favSelectedProductVal, favSelecteded)
  //   setFavSelecteded(favSelectedProductVal);
  //   // if (userInfo && userInfo.accessToken) {
  //   //   setFavIcon(true);
  //   //   // dispatch(fetchFavourites({ token: userInfo.accessToken }));
  //   //   if (isfav) {
  //   //     // removeFromFavourites(favproduct.id);
  //   //     setFavIcon(true);
  //   //     // dispatch(fetchFavourites({ token: userInfo.accessToken }));
  //   //     // setIsProductFav(false);
  //   //   } else {
  //   //     // addToFavourites(favproduct.id);
  //   //     setFavIcon(false);
  //   //     // dispatch(fetchFavourites({ token: userInfo.accessToken }));
  //   //     // let data = favSelectedProduct;
  //   //     // const index = favSelectedProduct.indexOf(wishproduct.id);
  //   //     // if(!index) {
  //   //     //   data.push(wishproduct.id)
  //   //     //   setFavSelectedProduct(data);
  //   //     // }
  //   //     // console.log(favSelectedProduct)
  //   //     // setIsProductFav(true);
  //   //   }
  //   // }
  // }

  // function handleRemoveToFavourites(favproduct) {
  //   // console.log("$$$$$$$$$$$$$$$$$$$$", userInfo.accessToken)
  //   const selectedFavItem = favSelecteded && favSelecteded.find(item => item == favproduct.id)
  //   if(selectedFavItem) {
  //     const indexOf = favSelecteded && favSelecteded.indexOf(favproduct.id)
  //     const fillteredFav = favSelecteded
  //     if (indexOf > -1) { // only splice array when item is found
  //       fillteredFav.splice(indexOf, 1); // 2nd parameter means remove one item only
  //     }
  //     console.log(selectedFavItem, indexOf, fillteredFav)
  //     setFavSelectedProduct(fillteredFav)
  //   }
  //   // if (userInfo && userInfo.accessToken) {
  //   //   setFavIcon(true);
  //   //   // dispatch(fetchFavourites({ token: userInfo.accessToken }));
  //   //   if (isfav) {
  //   //     // removeFromFavourites(favproduct.id);
  //   //     setFavIcon(true);
  //   //     // dispatch(fetchFavourites({ token: userInfo.accessToken }));
  //   //     // setIsProductFav(false);
  //   //   } else {
  //   //     // addToFavourites(favproduct.id);
  //   //     setFavIcon(false);
  //   //     // dispatch(fetchFavourites({ token: userInfo.accessToken }));
  //   //     // let data = favSelectedProduct;
  //   //     // const index = favSelectedProduct.indexOf(wishproduct.id);
  //   //     // if(!index) {
  //   //     //   data.push(wishproduct.id)
  //   //     //   setFavSelectedProduct(data);
  //   //     // }
  //   //     // console.log(favSelectedProduct)
  //   //     // setIsProductFav(true);
  //   //   }
  //   // }
  // }

  function handleAddToCart(prodItem, qty,cartdata) { // function to close the popup// function to close the popup
    // adding add to cart action here, we need to look back once api is ready  cartError
    // const { type, data, flightNumber } = action.payload;
    let quantity = qty === undefined ? 1 : qty
    // console.log("from wishlist", wishlist)
    // const isInspriration = inspirationList.length > 0 && optionType === "inspiration";
    // const isFlight = flightList.length > 0 && optionType === "flight";
    // const isPickup = pickupDropList.length > 0 && optionType === "pickupDrop";
  console.log("optionType : ========= ",optionType)
    const isInspriration = inspirationList.length > 0 && optionType === "inspiration" && selectedInspirations.length>0;
    const isFlight = flightList.length > 0 && optionType === "flight" && selectedFlights.length>0;
    const isPickup = pickupDropList.length > 0 && optionType === "pickupDrop" && selectedPickups.length>0;
    
    const cartData = {
      serviceName: prodItem.serviceName,
      description: prodItem.description[0],
      id: prodItem.id,
      unitPrice: prodItem.unitPrice,
      offerPrice: prodItem.offerPrice,
      currency: prodItem.currency,
      quantity: quantity,
      images: prodItem.images,
      selected: false
    }
    if (isInspriration || isFlight || isPickup) {
      if (userInfo?.accessToken){
        if(optionType === "flight") {
          selectedFlights.forEach((item) => {
            const cartPayload = {
              "serviceId": prodItem.id,
              "quantity": quantity,
              "flightId": item.flightId,
              "location": "",
              "token": userInfo.accessToken,
              "pinnedFlight" : true,
              "pickupDrop" : false,
              "inspiration" : false,
              "terminal" : "" ,
              "productDetails":cartdata
            }
            dispatch(addToCartAPI(cartPayload))
            dispatch(getItemInCartAPI({token: userInfo?.accessToken}))
          })
        } 
        else if(optionType === "pickupDrop") {
          selectedPickups.forEach((item) => {
            const cartPayload = {
              "serviceId": prodItem.id,
              "quantity": quantity,
              "flightId": 0,
              "location": "",
              "token": userInfo.accessToken,
              "pinnedFlight" : false,
              "pickupDrop" : true,
              "inspiration" : false,
              "terminal" : item.terminal,
              "productDetails":cartdata
            
            }
            // console.log("Quantity of item ======>",prodItem)
            dispatch(addToCartAPI(cartPayload))
            dispatch(getItemInCartAPI({token: userInfo?.accessToken}))
          })
        }
        else if(optionType === "inspiration") {
          selectedInspirations.forEach((item) => {
            const cartPayload = {
              "serviceId": prodItem.id,
              "quantity": quantity,
              "flightId": 0,
              "location": item.location,
              "token": userInfo.accessToken,
              "pinnedFlight" : false,
              "pickupDrop" : false,
              "inspiration" : true,
              "terminal" : "" ,
              "productDetails":cartdata
            }
            dispatch(addToCartAPI(cartPayload))
            dispatch(getItemInCartAPI({token: userInfo?.accessToken}))
          })
        } 
      }
      else {
        if (optionType === "flight" && selectedFlights.length>0) {
          selectedFlights.forEach((item) => {
            
            dispatch(addToCart({"prodItem": prodItem, type: optionType, data: cartData, flightNumber: item.flightId, 
              "productDetails":cartdata }))
          })
        }
        else if(optionType === "pickupDrop" && selectedPickups.length>0)
        {
          selectedPickups.forEach((item) => {
            dispatch(addToCart({"prodItem": prodItem, type: optionType, data: cartData, flightNumber: item.terminal, 
              "productDetails":cartdata }))
          })
        } 
        else  if(optionType === "inspiration" && selectedInspirations.length>0){
          selectedInspirations.forEach((item) => {
            dispatch(addToCart({"prodItem": prodItem, type: optionType, data: cartData, flightNumber: item.location, 
              "productDetails":cartdata }))
          })
        }
      }
    } 
    else{
      const option = "uncategorized"
      dispatch(addToCart({"prodItem": prodItem, type: option, data: cartData, flightNumber: "uncategorized", 
        "productDetails":cartdata }))
      if (userInfo?.accessToken){
        const cartPayload = {
          "serviceId": prodItem.id,
          "quantity": prodItem.quantity,
          "flightId": 0,
          "location": "",
          "token": userInfo.accessToken,
          "pinnedFlight" : false,
          "pickupDrop" : false,
          "inspiration" : false,
          "terminal" : "",
          "productDetails":cartdata
        }
        // console.log(cartPayload,"cartPayload")
        dispatch(addToCartAPI(cartPayload))
        dispatch(getItemInCartAPI({token: userInfo?.accessToken}))
      }
      // toast.error("Please pin a Flight or Inspiration", {
      //   position: toast.POSITION.TOP_CENTER
      // });
    }
    setVisible(false);
  } 

  const changeCartPopupStatus = (value) => {
    dispatch(changeCartPopupStatusReducer(value));
  }
  
  const offerAmountCal = (data) => {
    let offerAmmount = 0;
        if(data.offer) {
          if(data.offerType == "Percentage"){
            offerAmmount = data.unitPrice - (data.offerPrice/100)*data.unitPrice;
            // console.log("^^^^^^^^^^",data, offerAmmount)
          }
          if(data.offerType == "Flat"){
            offerAmmount = data.unitPrice - data.offerPrice;
          } 
          if(data.offerType == "Others"){
            offerAmmount = data.unitPrice;
          }
        }
        return offerAmmount.toFixed(2);
      }

  return (
    <div className="product-card-wrapper">
      <div className="row g-4">
        {products && products.length > 0 && products.map((product, index) =>
          <div key={index} className="col-xl-3 col-lg-4 col-md-6">
            <div className="product-card">
              <div className="product-card__thumb">
                <img src={product.images && product.images[0]} alt="name" />
                
                {product.offer && <div className="product-card__overlay_image"><img src={offerCard} /></div>}
                {!product.offer && parseInt((new Date() - new Date(product.createdDate)) / (1000 * 60 * 60 * 24), 10) < 30 && 
                <div className="product-card__overlay_image"><img src={newCard} /></div>}
                {/* {favSelecteded && favSelecteded.length > 0 && favSelecteded.find(item => item == product.id) ? <a className="product-card__favourite" onClick={() => handleRemoveToFavourites(product)}><i className="pi pi-heart-fill" /></a> :
                  <a className="product-card__favourite" onClick={() => handleAddToFavourites(product)}><i className="pi pi-heart" /></a>} */}
                   {(userInfo) && <a className="product-card__favourite" onClick={() => handleAddToFavourites(product)}>{isFav[product.id] ? (
                  <i className="pi pi-heart-fill fav-icon" />
                ) : (
                  <i className="pi pi-heart fav-icon" />
                )}
                </a>}
                {/* <> {product.arrival_terminals && product.arrival_terminals.map((item2, idx) =>
                  <a className="product-card__terminal" key={idx} ><span className="product-card__dot">T{item2}</span></a>
                )}
                </> */}
              </div>
              <div className="product-card__details">
                <div className="product-card__block">
                  <h3>{product.serviceName}</h3>
                  {product.offerText && product.offerText.length > 0 ?
                  <div className="product-card__save">{product.offerText && product.offer && product.offerText.slice(0,60)}</div>
                  : <>{product.description && product.description.length > 0 && <p>{getProductCartDesc(product.description).slice(0,60)}</p>}</>}
                </div>
                
                      
                <div className="product-card__footer">
                <div className="l-rating mb-3">
                    <Rating value={product.ratingStars} readOnly cancel={false} />
                    <span className="product-card__rating">{product.ratingCount} ratings</span>
                  </div>
                  <div className="d-flex justify-content-between">
                    <div>
                    <div className="d-flex gap-2 align-items-center">
                      {product.category == "Lounge" || product.category == "Parking" || product.category == "Services"|| product.category == "Passenger Service"?
                      ("") :(<>{product.offerType == "Others" ? <strong className="product-card__price">
                            {product.currency}&nbsp;{product.unitPrice}
                          </strong> : <>
                        {product.offer && product.offerType && product.offerType != "Others" ? <>
                          <span className="product-card__actualprice">{product.currency}&nbsp;{product.unitPrice}</span>
                          <strong className="product-card__price">{product.currency}&nbsp;{product.offerPrice}</strong>
                        </> :
                          <strong className="product-card__price">
                            {product.currency}&nbsp;{product.unitPrice}
                          </strong>}</>}
                        
                          </>)}
                        </div>
                        
                      <div className="product-card__loyality">{product.loyaltyPoints && product.loyaltyPoints} Reward Points</div>
                    </div>
                    <div className="d-flex gap-2">
                      {/* {product?.serviceItemType?.serviceType == "Lounge" || product?.serviceItemType?.serviceType == "Parking" || product?.serviceItemType?.serviceType == "Spa" ? */}
                      {product.category == "Lounge" || product.category== "Parking" || product.category== "Services"|| product.category== "Passenger Service"?
                        <button type="button" className="product-card__getprice" onClick={() => GetPricePopup(product)}>Get Price</button> :
                        <>
                          {showSavedtoCart && <>{wishlistSelectedProduct && wishlistSelectedProduct.length > 0 && wishlistSelectedProduct.find(item => item == product.id) ?
                            <button key={product.id} type="button" className="l-btn l-btn--icon l-btn--outline" onClick={() => handleAddToWishList(product)}><i className="pi pi-bookmark-fill"></i></button> :
                            <button type="button" key={product.id} className="l-btn l-btn--icon l-btn--outline" onClick={() => handleAddToWishList(product)}><i className="pi pi-bookmark"></i></button>}</>}
                          <button type="button" className="l-btn l-btn--icon l-btn--secondary" onClick={() => cartPopup(product)}><i className="pi pi-shopping-bag"></i></button></>}

                    </div>
                  </div>
                </div>
                
              </div>
            </div>
          </div>
        )
        }
      </div>

      {/* {visible && <Popup visible={visible} onHide={handleHide} selectedCard={selectedProduct} handleYes={handleYesWithFormData} />}
       */}
         {visible && <PopupNew changeCartPopupStatus={() => changeCartPopupStatus(true)} visible={visible} onHide={handleHide} selectedCard={selectedProduct} addToCart={(quantity) => handleAddToCart(selectedProduct, quantity)} handleYes={handleYesWithFormData} />}
         {selectedProduct && selectedProduct.serviceName === "Short Term Parking" && showSecPopup && (

<PopupNew
  visible={showSecPopup}
  selectedCard={(prem[0][1])}
  onHide={handlePopupSecCloses}
  addToCart={() => handleAddToCart(prem[0][1])}
  preStoredData={formData}
  changeCartPopupStatus={() => changeCartPopupStatus(true)}
/>

)}
      {selectedProduct && selectedProduct.serviceName === "Al Mourjan Business Lounge" && showSecPopup && (
        <PopupNew
          visible={showSecPopup}
          selectedCard={(prem[0][0])}
          onHide={handlePopupSecCloses}
          addToCart={() => handleAddToCart(prem[0][0])}
          preStoredData={formData}
          changeCartPopupStatus={() => changeCartPopupStatus(true)}
        />
      )}
      
       {popvisible&&<MyPopup changeCartPopupStatus={() => changeCartPopupStatus(true)} visible ={popvisible} selectedCard={selectedProduct} addToCart={(quantity,cartdata) => handleAddToCart(selectedProduct, quantity,cartdata)} onHide={handleHide}/>}
      {/* {popvisible&&<MyPopup visible ={popvisible} selectedCard={selectedProduct} onHide={handleHide}/>} */}
     
      {/* {popvisible && <Pop visible={popvisible} onHide={handleHide} selectedCard={selectedProduct} content="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum." />} */}
    </div>
  );
};


const mapStateToProps = (state) => {
  return {
    cartPopupStatus: state.cartPopupStatus.cartPopupStatus,
  };
};

const mapDispatchToProps = {
  // fetchCartPopupStatus: cartPopupStatusActions.fetchCartPopupStatus,
};

export default connect(mapStateToProps, mapDispatchToProps)(ProductCard);

