import React from 'react';
import { Card } from 'primereact/card';
import userEvent from '@testing-library/user-event';
import { useSelector } from "react-redux";

const LoggedUserName = () => {
  const { userInfo } = useSelector((state) => state.auth);
  const content = (
    <>
      {userInfo ? (
        <div style={{ fontFamily: 'Roboto', fontWeight: 400, fontStyle: 'normal', fontSize: '14px', letterSpacing: 'normal' }}>
          <div>Logged By: {userInfo.email}</div>
        </div>
      ) : (
        <div style={{ fontFamily: 'Roboto', fontWeight: 400, fontStyle: 'normal', fontSize: '14px', letterSpacing: 'normal' }}>Not Logged In.</div>
      )}
    </>
  );

  return (
    <Card style={{ width: '100%', height: '10%' }} >
      {content}
    </Card>
  );
};

export default LoggedUserName;
