import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import "./subtotal.css";
import offers from "./offers.json";
import {
  totTalPrice,
  getTotalSelectedItemPrice,
} from "../../../redux/features/cart/selector";
import userData from "./userData.json";
import { resetBookingId } from "../../../redux/features/purchasedItem/purchasedItemAction";
// const prdData =  useSelector(state => state.cart.cart.flight);
const Cartsubtotal = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const handlePayNowClick = () => {
    dispatch(resetBookingId());
    navigate("/paymentoptions");
  };
  const [offerCode, setOfferCode] = useState("");
  const [discount, setDiscount] = useState(0);
  const [errorMessage, setErrorMessage] = useState("");
  const subtotal = useSelector((state) => getTotalSelectedItemPrice(state));
  const { userInfo } = useSelector((state) => state.auth);
  const [offerApplied, setOfferApplied] = useState(false);
  const [loyaltyPointsUsed, setLoyaltyPointsUsed] = useState(0);
  const [showPointsInput, setShowPointsInput] = useState(false);
  const [pointsInputValue, setPointsInputValue] = useState("");
  const [balance, setBalance] = useState(0);
  const [showofferInput, setShowofferInput] = useState(false);

  React.useEffect(() => {
    if (userInfo) {
      const user = userData.find((user) => user.id === 1);
      setBalance(user.balance);
    }
  }, [userData, userInfo]);

  const handleApplyOfferCode = (e) => {
    e.preventDefault();
    const selectedOffer = offers.find((offer) => offer.code === offerCode);
    if (selectedOffer) {
      if (selectedOffer.type === "percent") {
        setDiscount(subtotal * selectedOffer.discount);
      } else if (selectedOffer.type === "flat") {
        setDiscount(selectedOffer.discount);
      } else {
        setDiscount(0);
      }
      setOfferApplied(true);
      setErrorMessage("");
      setShowofferInput(false);
    } else {
      setDiscount(0);
      setOfferApplied(false);
      setErrorMessage("Promocode is Invalid/expired");
    }
  };
  useEffect(() => {
    const selectedOffer = offers.find((offer) => offer.code === offerCode);
    if (selectedOffer) {
      if (selectedOffer.type === "percent") {
        setDiscount(subtotal * selectedOffer.discount);
      } else if (selectedOffer.type === "flat") {
        setDiscount(selectedOffer.discount);
      } else {
        setDiscount(0);
      }
      setOfferApplied(true);
      setErrorMessage("");
      setShowofferInput(false);
    } else {
      setDiscount(0);
      setOfferApplied(false);
      //  setErrorMessage('Promocode is Invalid/expired');
    }
  }, [subtotal, offerCode]);

  // const total = offerApplied ? subtotal - discount : subtotal;
  const total = offerApplied ? subtotal - discount : subtotal;
  const remainingBalance = Math.max(total - loyaltyPointsUsed * 0.5, 0);
  const REWARD_POINTS_PER_DOLLAR = 10;
  const rewardPoints = Math.floor(total / REWARD_POINTS_PER_DOLLAR);
  const handleUsePointsClick = () => {
    // console.log("userinfo:", userInfo);
    if (userInfo) {
      setShowPointsInput(true);
    } else {
      navigate("/login");
    }
  };
  const handlePointsInputChange = (e) => {
    const value = e.target.value;
    if (!isNaN(value) && value !== "") {
      setPointsInputValue(value);
    }
  };

  const handlePointsInputSubmit = (e) => {
    e.preventDefault();
    const pointsToUse = parseInt(pointsInputValue);
    if (pointsToUse > 0 && pointsToUse <= balance) {
      setLoyaltyPointsUsed(pointsToUse);
      setShowPointsInput(false);
    }
  };
  const handleCloseButtonClick = () => {
    setShowPointsInput(false);
  };
  const showOffer = () => {
    setShowofferInput(true);
  };

  return (
    <div>
      <div className="coupon_container">
        <div className="Coupon_wrapper">
          <div className="Coupon_couponInnerBox ">
            <div className="Coupon_couponIcon">
              <img
                className="couponIcon"
                src="https://www.tatacliq.com/src/general/components/img/coupon.png"
                alt="image"
              />
            </div>
            <div className="Coupon_headingText" onClick={showOffer}>
              Check for Coupons
            </div>
          </div>
          {offerApplied && (
            <div className="couponCodeText">
              <div className="Coupon_text">You saved ${discount}</div>
              <div className="Coupon_subtext">
                The coupon has been applied succesfully
              </div>
            </div>
          )}
        </div>
        {showofferInput && (
          <form onSubmit={handleApplyOfferCode} className="offer_code">
            <div className="enter_offer">
              <input
                type="text"
                className="enter_offer_input"
                placeholder="Enter Offer Code"
                value={offerCode}
                onChange={(e) => setOfferCode(e.target.value)}
              />
              <button type="submit" className="enter_offer_buttn">
                {" "}
                Apply{" "}
              </button>
            </div>
          </form>
        )}
        {errorMessage && <div className="error-promo">{errorMessage}</div>}
      </div>
      <div className="coupon_container">
        <div className="Coupon_wrapper">
          <div
            className="Coupon_couponInnerBox "
            onClick={handleUsePointsClick}
          >
            <div className="Coupon_couponIcon">
              <img
                className="couponIcon"
                src="https://rentoutcar.com/wp-content/uploads/2019/06/Get-paid.png"
                alt="image"
              />
            </div>
            <div className="Coupon_headingText">Redeem Your Points</div>
          </div>
          {loyaltyPointsUsed > 0 && (
            <div className="couponCodeText">
              <div className="Coupon_text">
                You saved ${Math.max(loyaltyPointsUsed * 0.5, 0)}
              </div>
              <div className="Coupon_subtext">
                You have successfully redeemed {loyaltyPointsUsed} points.
              </div>
            </div>
          )}
        </div>
        <div className="form-container">
          {showPointsInput && (
            <form onSubmit={handlePointsInputSubmit}>
              <input
                placeholder="Enter points to use:"
                value={pointsInputValue}
                onChange={handlePointsInputChange}
              />
              <button className="points_button" type="submit">
                Use
              </button>
              <button
                className="points_button_close"
                onClick={handleCloseButtonClick}
              >
                Close
              </button>
              <div className="balance_sub_head">
                <span>Total available points</span>
                <span className="balance_sub_total">{balance}</span>
              </div>
            </form>
          )}
        </div>
      </div>
      <div className="subtotal-container">
        <div className="item-cal mt-4 pt-3">
          <div className="row">
            <div class="order_summary">Order Summary</div>
            <div className="pt-3 pb-2">
              <div class="summary_sub">
                <div className="summary_sub_head">
                  <span>Sub Total</span>
                </div>
                <span className="summary_sub_total">${subtotal}</span>
              </div>
            </div>

            <div className="pt-3 pb-2">
              <div class="summary_sub">
                <div className="summary_sub_head">
                  <span>Coupon Discount</span>
                </div>
                <span className="summary_sub_total">${discount}</span>
              </div>
            </div>
            <div className="pt-3 pb-2">
              <div class="summary_sub">
                <div className="summary_sub_head">
                  <span>Points Claimed</span>
                </div>
                <span className="summary_sub_total">
                  ${Math.max(loyaltyPointsUsed * 0.5, 0)}
                </span>
              </div>
            </div>
          </div>

          <div className="pt-3 pb-2 total-sub-container">
            <div class="total_sub">
              <div className="total_sub_head">
                <span>Amount Payable</span>
              </div>
              <span className="total_sub_total">${remainingBalance}</span>
            </div>
          </div>
          <div className="pt-3 pb-2">
            <div class="summary_sub">
              <div className="summary_sub_discount">
                <span>
                  You will save $
                  {Math.max(loyaltyPointsUsed * 0.5 + discount, 0)} in this
                  order
                </span>
              </div>
            </div>
          </div>

          <div class="points_sub">
            <div className="points_sub_head">
              <span>Earned Rewards Points *</span>
            </div>
            <span className="points_sub_total">
              {Math.max(rewardPoints, 0)}
            </span>
          </div>
        </div>
        <div className="row">
          <div className="col pay-col">
            <button className="pay-now" onClick={handlePayNowClick}>
              Checkout
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cartsubtotal;
