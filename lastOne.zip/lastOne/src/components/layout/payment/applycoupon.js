import React, { useState } from 'react';
import { Card } from 'primereact/card';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useDispatch } from 'react-redux';
import { addRedeemData } from 'redux/features/cart/cartslice';

const ApplyCoupon = ({ totalprice, onSavedPrice }) => {
  const [couponCode, setCouponCode] = useState('');
  const [savedPrice, setSavedPrice] = useState(0);
  const [errorMessage, setErrorMessage] = useState('');
  const dispatch = useDispatch()

  const validCouponCodes = {
    FIRST20: 0.2,
    NEW23: 0.3,
    DISCOUNT23: 0.5,
  };

  const handleApplyCoupon = (e) => {
    e.preventDefault();

    if (validCouponCodes.hasOwnProperty(couponCode)) {
      const savedAmount = totalprice * validCouponCodes[couponCode];
      setSavedPrice(savedAmount);
      setErrorMessage('');
      toast.success(`You Saved INR ${savedAmount.toFixed(2)}`);
      onSavedPrice(savedAmount); // call the parent function to update savedPrice state
      dispatch(addRedeemData({
        couponCode,
        couponAmount:savedAmount
      }))
    } else {
      setCouponCode('');
      setErrorMessage('Promo code is invalid or expired');
    }

  };

  const content = (
    <>
      <div style={{ marginBottom: '10px' }}>Apply Coupon/Offer Code</div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ width: '50%', borderRight: '1px solid #ced4da', padding: '0 10px' }}>
          <InputText placeholder="Enter coupon code" value={couponCode} onChange={(e) => setCouponCode(e.target.value)} style={{width:'137px',height:'36px'}} />
        </div>
        <div style={{ width: '50%', padding: '0 10px' }}>
          <Button
            label="Apply"
            className="p-button-secondary"
            style={{ background: '#f2f2f2', color: 'black', border: '1px solid #ced4da', borderRadius: '0',width:'100px' ,height:'36px'}}
            onClick={handleApplyCoupon}
          />
        </div>
      </div>
      <div style={{ marginTop: '25px' }}>{errorMessage && <div className="error-promo">{errorMessage}</div>}</div>
      <div style={{paddingLeft: "10px"}}>* Use <strong>FIRST20</strong> to receive INR 200 off</div>
      
      <ToastContainer />
    </>
  );

  return <Card style={{ padding: '10px' }}>{content}</Card>;
};

export default ApplyCoupon;
