import React from 'react';
import img from "../images/order.svg";
import "./PurchaseCard.css";
import { useSelector } from 'react-redux';
const getArrayToObj=(data)=>{
  return data.reduce((a, v) => ({ ...a, [v.flightId]: v}), {});
}

const modifyCart=(cart,key,obj)=>{
  Object.keys(cart[key]).forEach(item=>cart[key][item].forEach((it,index)=> {
    cart[key][item][index] = {...cart[key][item][index],...obj[item]}
  }))
}
const PurchaseCard = (cardcontent) => {
  const { orderSummaryData } = cardcontent;
  const cartData = useSelector(state=>state.cart.cart);
  const cart = JSON.parse(JSON.stringify(cartData))
  const findCartFlight = useSelector(state=>state.flight.flightList);
  const findInspirationFlight = useSelector(state=>state.inspiration.inspirationList);
  const findPickupDrop = useSelector(state=>state.pickupDrop.pickupDropList);
  
  const flightToObj = getArrayToObj(findCartFlight)
  const inspirationToObj = getArrayToObj(findInspirationFlight);
  const pickDropToObj = getArrayToObj(findPickupDrop)
  modifyCart(cart,'flight',flightToObj);
  modifyCart(cart,'pickupDrop',pickDropToObj)
  modifyCart(cart,'inspiration',inspirationToObj)
  
  
  Object.keys(cart.flight).forEach(item=>cart.flight[item].forEach((it,index)=> {
    cart.flight[item][index] = {...cart.flight[item][index],...flightToObj[item]}
  }))
  const currentDate = new Date();
    const options = {  month: 'long',day: 'numeric', year: 'numeric' };
    const formattedDate = currentDate.toLocaleDateString('en-US', options);
  // console.log("cart=>",cart);
  const orderData = Object.keys(cart).map(it => Object.values(cart[it]).flat().map(yt=>({...yt,type:it}))).flat();

  const offerAmountCal = (data) => {
    let offerAmmount = 0;
        if(data.offer) {
          if(data.offerType == "Percentage"){
            offerAmmount = data.unitPrice - (data.offerPrice/100)*data.unitPrice;
            // console.log("^^^^^^^^^^",data, offerAmmount)
          }
          if(data.offerType == "Flat"){
            offerAmmount = data.unitPrice - data.offerPrice;
          } 
          if(data.offerType == "Others"){
            offerAmmount = data.unitPrice;
          }
        }
        return offerAmmount.toFixed(2);
      }
  
  return (
    <div>
       {orderData.map((item,index)=>
    <div className="purchase-card">
      {item.flightNo && <div className="flight-info">
        <div className="flight-code">{item.flightNo} • {item.scheduleDate}</div>
        <div className="flight-route">{item?.source}-{item?.destination}</div>
        <div className="flight-terminal">HIA</div>
      </div>}
      <div className="purchase-info">
        <div className="purchase-image">
          <img src={item.images} alt="order" />
        </div>
        <div className="purchase-details">
          <div className="product-name">{item.serviceName.slice(0,30)}</div>
          <div className="product-price">
            {item.offer ?  <><div className="current-price">{item.currency}<span>&nbsp;</span>{offerAmountCal(item)}</div><div className="strike-through">{item.currency}&nbsp;{item.unitPrice}</div></> : <><div className="current-price">{item.currency}<span>&nbsp;</span>{item.unitPrice}</div></>}
            {/* <div className="old-price">$150</div>
            <div className="discount">You Save 21%</div> */}
          </div>
          <div className="reward-points">Earned +{item.loyaltyPoints} Reward Points</div>
        </div>
      </div>
      {orderData.length-1!==index&&
  <div >
  <hr />
  </div>
  }
    </div>
       )}
        </div>
  );
};

export default PurchaseCard;
