import React from "react";
import { Card } from "primereact/card";
import img from "../images/order.svg";
import PurchaseCard from "./purchasecard"; 
import { useSelector } from 'react-redux';

const OrderSummary = (props) => {
  const headerStyle = {
    fontFamily: "Roboto, sans-serif",
    fontWeight: "400",
    fontStyle: "normal",
    color: "#252525",
    paddingLeft: "12px",
  };

  const flightInCart = useSelector(state => state.cart.cart.flight)
  const pickupInCart = useSelector(state => state.cart.cart.pickupDrop);
  const inspirationInCart = useSelector(state => state.cart.cart.inspiration);
  const uncategorizedInCart = useSelector(state => state.cart.cart.uncategorized);

  const { orderSummaryData } = props;

  const header = (
    <div className="p-card-title" style={headerStyle}>
      <div>Order Summary</div>
    </div>
  );

  console.log(flightInCart)

  const content = (
    <>
      <>
        <PurchaseCard cardcontent={orderSummaryData} />
      </>
    </>
  );

  return <Card title={header} style={{ padding: '0' }}>{content}</Card>;
};

export default OrderSummary;
