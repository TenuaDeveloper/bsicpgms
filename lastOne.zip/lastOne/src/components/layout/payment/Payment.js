import React, { useState, useEffect } from "react";
import SearchBar from "../../searchbar/searchbar";
import "./paymentpage.css";
// import { Container } from 'primereact/container';
// import { Row } from 'primereact/row';
// import { Col } from 'primereact/col';
import { Card } from "primereact/card";
import { Container, Row, Col } from "react-bootstrap";
import PaymentMerchant from "./paymentmerchant";
import ApplyCoupon from "./applycoupon";
// import LoggedUserName from './loggedusername';
import Cartsubtotal from "./cartsubtotal";
import PriceSummary from "./pricesummary";
//import Pricesummary from "components/order-details/pricesummary";
import OrderSummary from "./ordersummary";
import axios from "axios";
import orderPlacedCartData from "../../order-details/ordersummary";
import { useSelector, useDispatch } from 'react-redux';
import { totTalPrice, getTotalSelectedItemPrice, getUnitSelectedItemPrice, getOfferDiscountPrice, getOfferDiscount } from "../../../redux/features/cart/selector"


function Payment() {
  const [amount, setAmount] = useState("");
  const [orderSummaryData, setOrderSummaryData] = useState([]);
  const [savedPrice, setSavedPrice] = useState(0);
  const [redeemedAmount, setRedeemedAmount] = useState(0);
  const [redeemPoints, setRedeemedPoints] = useState(0);
  const [productPrice, setProductPrice] = useState(0);
  const [totalAmount, setTotalAmount] = useState(0);
  const [offerDiscount, setOfferDiscount] = useState(0);

  const totalprice = 1000;
  const subtotal = useSelector(state => getTotalSelectedItemPrice(state));
  const unitPrice = useSelector(state => getUnitSelectedItemPrice(state));
  const discountPrice = useSelector(state => getOfferDiscountPrice(state));
  const discountPercentage = useSelector(state => getOfferDiscount(state));
  // console.log("savedPrice",savedPrice)

  // Dummy Data
  useEffect(() => {
    axios
      .get("/order.json")
      .then((response) => setOrderSummaryData(response.data))
      .catch((error) => console.error(error));
  }, []);

  const handleAmountChange = (e) => {
    setAmount(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // handle payment submission logic here
  };

  const handleSavedPrice = (value) => {
    setSavedPrice(value);
  };

  const handleRedeemAmount = (amount) => {
    setRedeemedAmount(amount);
  };

  const handleReedeemPoints = (points) => {
    setRedeemedPoints(points);
  };

  return (
    <div className="container place-order-wrapper">
      <div className="searchbar-payment">
        <SearchBar />
      </div>
      <h2 className="payment-heading mb-4" style={{ color: "#004164" }}>
        Place Order
      </h2>
      <div className="row">
        <div className="col-md-8">
          <OrderSummary
            id="order-summary-card"
            className="card-style"
            orderSummaryData={orderSummaryData}
          />
          <PaymentMerchant
            className="payment-block card-style"
            onRedeemAmount={handleRedeemAmount}
            onRedeemPoints={handleReedeemPoints}
            offeredDiscountPrice ={discountPrice}
            offeredDiscountPercent={discountPercentage}
            totalAmount={subtotal}
            couponDiscount={savedPrice}
            pointsRedeemed={redeemedAmount}
            productPrice={unitPrice}
            offerDiscount={discountPrice}
            pointsRedeemedCount={redeemPoints}
            discountPercentage={discountPercentage}
          />
        </div>
        <div className="col-md-4">
          <ApplyCoupon
            id="payment-coupon-card"
            className="card-style"
            style={{ height: "120px" }}
            totalprice={totalprice}
            onSavedPrice={handleSavedPrice}
          />
          <PriceSummary
            id="productsummary-card"
            className="card-style"
            style={{ height: "150px" }}
            totalAmount={subtotal}
            couponDiscount={savedPrice}
            pointsRedeemed={redeemedAmount}
            productPrice={unitPrice}
            offerDiscount={discountPrice}
            pointsRedeemedCount={redeemPoints}
            discountPercentage={discountPercentage}
          />
        </div>
      </div>

      {/* <Container>
        <Row>
          <Col
            md={6}
            className="d-flex flex-column mb-3"
            id="logged-by-user-card-id"
            style={{ width: "70%" }}
          >
            

            <div className="card-spacing"></div>

            <OrderSummary
              id="order-summary-card"
              className="card-style"
              orderSummaryData={orderSummaryData}
            />

            <div className="card-spacing"></div>

            <PaymentMerchant
              className="payment-block card-style"
              onRedeemAmount={handleRedeemAmount}
              onRedeemPoints={handleReedeemPoints}
            />
          </Col>
          <Col
            md={6}
            className="ml-md-4 mb-2"
            id="payment-coupon-card-col"
            style={{ marginLeft: "0%", width: "30%" }}
          >
            <ApplyCoupon
              id="payment-coupon-card"
              className="card-style"
              style={{ height: "120px" }}
              totalprice={totalprice}
              onSavedPrice={handleSavedPrice}
            />
            <br />
           
            <PriceSummary
              id="productsummary-card"
              className="card-style"
              style={{ height: "150px" }}
              totalAmount={totalAmount}
              couponDiscount={savedPrice}
              pointsRedeemed={redeemedAmount}
              productPrice={productPrice}
              offerDiscount={offerDiscount}
              pointsRedeemedCount={redeemPoints}
            />

   
          </Col>
        </Row>
      </Container> */}
    </div>
  );
}

export default Payment;
