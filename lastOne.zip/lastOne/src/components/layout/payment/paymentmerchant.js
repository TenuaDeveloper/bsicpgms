import React, { useState } from 'react';
import { Card } from 'primereact/card';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { RadioButton } from 'primereact/radiobutton';
import { ToastContainer, toast } from "react-toastify";
import { useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from 'react-redux';
import { disCountandPoints } from 'redux/features/cart/cartAction';
import { addRedeemData, resetCart } from 'redux/features/cart/cartslice';
import { setOrderData } from 'redux/features/orders/orderSlice';
import { addPurchases } from 'redux/features/purchaseList/purchaseListSlice';
import {getTotalCartCount } from '../../../redux/features/cart/selector'
// const getArrayToObj = (data) => {
//   return data.reduce((a, v) => ({ ...a, [v.flightId]: v }), {});
// };



// const modifyCart = (cart, key, obj) => {
//   Object.keys(cart[key]).forEach((item) =>
//     cart[key][item].forEach((it, index) => {
//       cart[key][item][index] = { ...cart[key][item][index], ...obj[item] };
//     })
//   );
// };

const PaymentMerchant = ({ onRedeemAmount,
   onRedeemPoints,
    totalAmount,
    offeredDiscountPrice,
    offeredDiscountPercent,
    productPrice, 
    offerDiscount,
     couponDiscount, 
     pointsRedeemed, 
     pointsRedeemedCount, 
     discountPercentage
   }) => {
  const [netBanking, setNetBanking] = useState(false);
  const [creditCard, setCreditCard] = useState(false);
  const [points, setPoints] = useState('');
  const [redeemedAmount, setRedeemedAmount] = useState(0);
  const [availablePoints, setAvailablePoints] = useState(32550);
  const formattedPoints = availablePoints.toLocaleString();
  const cartData = useSelector(state => state.cart.cart);
  const { userInfo, userToken } = useSelector((state) => state.auth);
  const qty = useSelector((state)=>getTotalCartCount(state));
  const findCartFlight = useSelector(state => state.flight.flightList);
  const findInspirationFlight = useSelector(state => state.inspiration.inspirationList);
  const findPickupDrop = useSelector(state => state.pickupDrop.pickupDropList);
  const cart = JSON.parse(JSON.stringify(cartData))
  const orderData = Object.keys(cart).map(it => Object.values(cart[it]).flat().map(yt => ({ ...yt, type: it }))).flat();
  const dispatch = useDispatch()
  console.log("orderData qty", qty)
 // console.log("Reedemed points and reedemed Amount",pointsRedeemedCount, pointsRedeemed)
  const idsSet = new Set();
  for (let i = 0; i < orderData.length; i++) {
    const id = orderData[i].id;
    idsSet.add(id);
  }

  const idsArray = Array.from(idsSet);
  console.log(idsArray);

  const headerStyle = {
    fontFamily: 'Roboto, sans-serif',
    fontWeight: '400',
    fontStyle: 'normal',
    color: '#252525',
    paddingLeft: '12px'
  };

  const POINTS_PER_DOLLAR = 2000;
  const REDEMPTION_RATE = 100;
  const navigate = useNavigate();

  function calculateRedemptionAmount(pointsToRedeem) {
    const dollarsToRedeem = pointsToRedeem / POINTS_PER_DOLLAR;
    const redemptionAmount = dollarsToRedeem * REDEMPTION_RATE;
    return redemptionAmount;
  }

  const handleApply = () => {
    console.log(totalAmount, "totalAmount..............")

    if (availablePoints >= points) {
      const redemptionAmount = calculateRedemptionAmount(points);
      setRedeemedAmount(redemptionAmount);
      if (totalAmount >= redemptionAmount) {
        const remainingPoints = availablePoints - points;
        setAvailablePoints(remainingPoints);
        toast.success(`Saved INR ${redemptionAmount}, remaining ${remainingPoints.toLocaleString()} points`);
        onRedeemAmount(redemptionAmount);
        onRedeemPoints(points);
        dispatch(addRedeemData({
          points,
          pointsAmount: redemptionAmount

        }))
      }
      else {
        toast.error(`Sorry you can't reedeem Points beyond ${totalAmount}`);
      }
    } else {
      toast.error(`Sorry you can reedeem only upto ${formattedPoints} Points`);
    }

    // else{
    //   toast.error(`Sorry you can't reedeem Points beyond ${totalAmount}`);
    // }
  };

  /**
   * Needs to refector this once api is ready to consume
   */
  const updateOrderDetails = () => {
    const cpCart = JSON.parse(JSON.stringify(cartData))

    // const flightToObj = getArrayToObj(findCartFlight)
    // const inspirationToObj = getArrayToObj(findInspirationFlight);
    // const pickDropToObj = getArrayToObj(findPickupDrop)

    // modifyCart(cpCart, 'flight', flightToObj);
    // modifyCart(cpCart, 'pickupDrop', pickDropToObj)
    // modifyCart(cpCart, 'inspiration', inspirationToObj)

    // Object.keys(cpCart.flight).forEach(item => cpCart.flight[item].forEach((it, index) => {
    //   cpCart.flight[item][index] = { ...cpCart.flight[item][index], ...flightToObj[item] }
    // }))

    // const orderData = Object.keys(cpCart).map(it => Object.values(cart[it]).flat().map(yt => ({ ...yt, type: it }))).flat();

    // console.log(" orderData ", orderData)

    // dispatch(setOrderData(cpCart))
    // dispatch(resetCart())
  }

  const getCategInfo  = (key, type) => {
    switch (type) {
      case "flight":
        return {
          flightId: key,
          orderScheduledDate: findCartFlight.find(item => item.flightId == key)?.scheduleDate
        }
      
      case "pickupDrop": 
        return {
          pickupDrop: key,
          orderScheduledDate: findPickupDrop.find(item => item.id == key)?.scheduleDate
        }

      case "inspiration": 
        return {
          location: key,
          orderScheduledMonth: findInspirationFlight.find(item => item.location == key )?.scheduleMonth
        }
    
      default:
        return { }
        break;
    }
  }

  const formateObj = (obj, type) => {
    let res = [];
    Object.keys(obj).map(key=> {
      obj[key].map(data=> {
        const temp = {
          serviceId: data.id,
          purchasedPrice: data.unitPrice,
          unitsPurchased: 1,
          ...getCategInfo(key, type)
          }
        res.push(temp);
      })
      
    })
    return res;
  }

  const formateCartData = () => {
    const cpCart = JSON.parse(JSON.stringify(cartData));
    return {
      pinFlightPurchases: formateObj(cpCart.flight, "flight"),
      pinPickupDropPurchases: formateObj(cpCart.pickupDrop, "pickupDrop"),
      pinInspirationPurchases: formateObj(cpCart.inspiration, "inspiration"),
      uncategorizedPurchases: formateObj(cpCart.uncategorized, "uncategorized")
    }

  }

  const handlePayNow = (e) => {
    e.preventDefault()
    // const points = event.target.dataset.cartData;
    const resData = formateCartData();
    const toBePaidAmount = productPrice - (offerDiscount+couponDiscount+pointsRedeemed).toFixed(1)
    const payload = {
      token: userToken,
      data: {
        "userId": userInfo.id,
        "sumAmount": productPrice,
        "totalAmount": toBePaidAmount,
        "redeemedPoints": pointsRedeemedCount,
        "redeemedPointsAmount": pointsRedeemed,
        "paymentMethod": "Credit Card",
        "refrenceId": 113456,
        "offeredDiscountPrice": totalAmount,
        "offeredDiscountPercent": discountPercentage,
        "deliveryCharge": 40,
        "totalQuantity":qty,
        ...resData
      }
    }
    dispatch(addPurchases({...payload})).then(res => {
      dispatch(resetCart());
      navigate("/Ordersummary");
    })
    // updateOrderDetails();
    // navigate("/Ordersummary");
  }

  const header = <div className="p-card-title" style={headerStyle}><div>Payment Method</div></div>;

  const content = (
    <div style={{ paddingLeft: '12px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
        <h6 style={{ marginRight: '10px' }}><b>Redeem Points</b></h6>
        <span style={{ fontFamily: 'Roboto, sans-serif', fontWeight: '400', fontStyle: 'normal', fontSize: '16px', color: '#252525' }}>{formattedPoints} Loyalty Points</span>
      </div>
      <p>Points to be redeemed</p>

      <div className="input-group mb-3">
        <InputText placeholder="" style={{ height: '45px' }} value={points} onChange={(e) => setPoints(e.target.value)} />
        <Button label={`= INR ${redeemedAmount.toFixed(1)}`} className="p-button-secondary" style={{ height: '45px', background: '#f2f2f2', color: 'black', border: '1px solid #ced4da', borderRadius: '0' }} />
        <span style={{ margin: "0 5px" }}></span>
        <Button label="Apply" className="p-button-secondary" style={{ background: '#f2f2f2', color: 'black', border: '1px solid #ced4da', borderRadius: '0', height: '45px' }} onClick={handleApply} />
      </div>
      <ToastContainer />


      <hr />
      <div className="flex flex-wrap gap-3">
        <div className="radio-button">
          <div style={{ display: "flex", alignItems: "center", paddingTop: "5px", paddingBottom: "5px" }}>
            <RadioButton id="netbanking" name="paymentMethod" value={true} onChange={(e) => setNetBanking(e.value)} checked={netBanking} style={{ borderWidth: 0, marginRight: "10px" }} />
            <label htmlFor="netbanking" style={{ fontFamily: "Roboto, sans-serif", fontWeight: 400, fontStyle: "normal", fontSize: "16px", color: "#252525" }}>Net Banking/Bank Transfer</label>
          </div>
        </div>
        <hr />
        <div className="radio-button">
          <div style={{ display: "flex", alignItems: "center", paddingTop: "5px", paddingBottom: "5px" }}>
            <RadioButton id="creditcard" name="paymentMethod" value={false} onChange={(e) => setCreditCard(e.value)} checked={creditCard} style={{ borderWidth: 0, marginRight: "10px" }} />
            <label htmlFor="creditcard" style={{ fontFamily: "Roboto, sans-serif", fontWeight: 400, fontStyle: "normal", fontSize: "16px", color: "#252525" }}>Credit Card/Debit Card/ATM Card</label>
          </div>
          <br />
          <div style={{ marginTop: "10px" }}>
            <form>
              <div className="mb-3" style={{ width: '60%', margin: '0 auto', position: 'relative' }}>
                <label htmlFor="cardNumber" className="form-label">Card Number</label>
                <div style={{ display: 'flex', alignItems: 'center' }}>
                  <InputText id="cardNumber" name="cardNumber" className="form-control" style={{ height: '45px', paddingRight: '40px' }} />
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" style={{ position: 'absolute', right: '10px', width: '30px', height: '30px' }}>
                    <path fill="#FF5F00" d="M15.245 17.831h-6.49V6.168h6.49v11.663z"></path>
                    <path fill="#EB001B" d="M9.167 12A7.404 7.404 0 0 1 12 6.169 7.417 7.417 0 0 0 0 12a7.417 7.417 0 0 0 11.999 5.831A7.406 7.406 0 0 1 9.167 12z"></path>
                    <path fill="#F79E1B" d="M24 12a7.417 7.417 0 0 1-12 5.831c1.725-1.358 2.833-3.465 2.833-5.831S13.725 7.527 12 6.169A7.417 7.417 0 0 1 24 12z"></path>
                  </svg>
                </div>
              </div>
              <div className="row" style={{ marginLeft: '19%' }}>
                <div className="col-sm-3">
                  <label htmlFor="expiryDate" className="col-form-label">Expiry Date</label>
                  <InputText id="expiryDate" name="expiryDate" className="form-control" placeholder="Expiry Date" style={{ height: '45px' }} />
                </div>
                <div className="col-sm-3">
                  <label htmlFor="expiryYear" className="col-form-label">Expiry Year</label>
                  <InputText id="expiryYear" name="expiryYear" className="form-control" placeholder="Expiry Year" style={{ height: '45px' }} />
                </div>
                <div className="col-sm-3">
                  <label htmlFor="cvv" className="col-form-label">CVV</label>
                  <InputText id="cvv" name="cvv" className="form-control" type="password" placeholder="CVV" style={{ height: '45px' }} />
                </div>
              </div>
              <br />
              <div className="mb-3" style={{ width: '60%', margin: '0 auto' }}>
                <label htmlFor="cardHoldersName" className="form-label">Card Holder's Name</label>
                <InputText id="cardHoldersName" name="cardHoldersName" className="form-control" style={{ height: '45px' }} />
                <div data-attr={idsArray} style={{ display: 'flex', justifyContent: 'center', marginTop: '10px' }}>
                  <Button id="pay-button" data-attr={idsArray} label="PAY" onClick={handlePayNow} className="p-button-secondary" style={{ backgroundColor: '#004164', color: '#ffffff', border: 'none', width: '100%' }} />
                </div>
              </div>


            </form>
          </div>
        </div>
      </div>
    </div>
  );

  return <Card title={header}>{content}</Card>;
};

export default PaymentMerchant;
