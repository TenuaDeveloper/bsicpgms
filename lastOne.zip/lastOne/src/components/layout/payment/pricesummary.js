import React from 'react';
import { Card } from 'primereact/card';

const PriceSummary = ({productPrice, offerDiscount, couponDiscount, pointsRedeemed, totalAmount,pointsRedeemedCount, discountPercentage}) => {

  console.log("totalAmount",totalAmount)
  return (
    <Card title="Price Summary">
      <div className="summary_sub" style={{ marginBottom: "10px" }}>
        <div className="summary_sub_head">
          <span>Original Product Price</span>
        </div>
        <span className="summary_sub_total">INR {productPrice}</span>
      </div>
      <div className="summary_sub" style={{ marginBottom: "10px" }}>
        <div className="summary_sub_head">
          <span>You Saved ({Math.round(discountPercentage)}%)</span>
        </div>
        <span className="summary_sub_total">INR {offerDiscount}</span>
      </div>
      <div className="summary_sub" style={{ marginBottom: "20px" }}>
        <div className="summary_sub_head">
          <span>Price After Discount</span>
        </div>
        <span className="summary_sub_total">INR {totalAmount}</span>
      </div>
      <div className="summary_sub" style={{ marginBottom: "20px" }}>
        <div className="summary_sub_head">
          <span>Delivery Charges</span>
        </div>
        <span className="summary_sub_total">Free</span>
      </div>      
      <div className="summary_sub" style={{ marginBottom: "20px" }}>
        <div className="summary_sub_head">
          <span>Coupon Discount</span>
        </div>
        <span className="summary_sub_total">INR {couponDiscount}</span>
      </div>
      <hr style={{ margin: "10px 0px" }} />
      <div className="summary_sub" style={{ marginBottom: "5px", marginTop: "5px" }}>
        <div className="summary_sub_head">
          <span>Points Redeemed ({pointsRedeemedCount})</span>
        </div>
        <span className="summary_sub_total">INR {pointsRedeemed.toFixed(1)}</span>
      </div>
      <hr style={{ margin: "10px 0px" }} />
      <div className="total_sub">
        <div className="total_sub_head">
          <span>Total Amount to be Paid</span>
        </div>
        <span className="total_sub_total">INR {totalAmount-couponDiscount-pointsRedeemed.toFixed(1)}</span>
      </div>
    </Card>
  );
};

export default PriceSummary;
