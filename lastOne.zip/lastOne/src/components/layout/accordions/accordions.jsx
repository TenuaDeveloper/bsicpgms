import React, { useState } from 'react';
import './accordions.scss'
import { Panel } from 'primereact/panel';

const Accordion = ({ title, contentBlock }) => {
  // const [isActive, setIsActive] = useState(false);
  // console.log(title)

  return (
    <div className="accordion">
    <Panel header={title} toggleable>
      <p className="m-0">
        {contentBlock}
      </p>
    </Panel>
    </div>
  );
};

export default Accordion;
