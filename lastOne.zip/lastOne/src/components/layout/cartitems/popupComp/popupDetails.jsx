import React, { useState } from "react";
import "../cartComp.scss";
import { InputNumber } from 'primereact/inputnumber'; 
import { useSelector, useDispatch } from 'react-redux';
import { updateCartItemAPI, getItemInCartAPI } from "redux/features/cart/cartAction"
import { addToCart } from "redux/features/cart/cartslice";

const Details = ({
  data,
  showdivider,
  onEditClick,
  onDeleteClick,
  onWishlistClick,
  key,
  optionType,
  flight,
  pickup,
  inspiration,
  uncategorized
}) => {
  const description = Array.isArray(data.description)
    ? data.description[0]
    : data.description;
  const quantity = data.quantity === undefined ? data.unitAdded : data.quantity;
  let title = data.serviceName === undefined ? data.name : data.serviceName;
  const productDetails =
    data.productDetails &&
    data.productDetails != undefined &&
    JSON.parse(data.productDetails) &&
    JSON.parse(data.productDetails) != undefined
      ? JSON.parse(data.productDetails)
      : {};

      let offerAmmount = 0;
      if(data.offer) {
        if(data.offerType == "Percentage"){
          offerAmmount = data.unitPrice - (data.offerPrice/100)*data.unitPrice;
          // console.log("^^^^^^^^^^",data, offerAmmount)
        }
        if(data.offerType == "Flat"){
          offerAmmount = data.unitPrice - data.offerPrice;
        } 
        if(data.offerType == "Others"){
          offerAmmount = data.unitPrice;
        }
      }

      const dispatch = useDispatch();
  const { userInfo } = useSelector((state) => state.auth);
  const [stateQty, setStateQty] = useState(data.quantity);

  const handleChange = (prodItem, qty, productDetails) => {
    setStateQty(qty);
    // console.log("44444444444444444", qty, prodItem, productDetails)
    let quantity = qty === undefined ? 1 : qty
    const isInspriration = inspiration;
    const isFlight = flight;
    const isPickup = pickup;
    // console.log(quantity, isInspriration, )
    const cartData = {
      serviceName: prodItem.serviceName,
      description: prodItem.description[0],
      id: prodItem.id,
      unitPrice: prodItem.unitPrice,
      offerPrice: prodItem.offerPrice,
      currency: prodItem.currency,
      quantity: quantity,
      images: prodItem.images,
      selected: false
    }
  
    if (isInspriration || isFlight || isPickup) {
      if (userInfo?.accessToken){
        if(optionType === "flight") {
            const cartPayload = {
              "serviceId": prodItem.id,
              "quantity": quantity,
              "flightId": flight.flightId,
              "location": "",
              "token": userInfo.accessToken,
              "pinnedFlight" : true,
              "pickupDrop" : false,
              "inspiration" : false,
              "terminal" : "" ,
              // "productDetails":productDetails
            }
            dispatch(updateCartItemAPI(cartPayload))
            dispatch(getItemInCartAPI({token: userInfo?.accessToken}))
        } 
        else if(optionType === "pickupDrop") {
            const cartPayload = {
              "serviceId": prodItem.id,
              "quantity": quantity,
              "flightId": 0,
              "location": "",
              "token": userInfo.accessToken,
              "pinnedFlight" : false,
              "pickupDrop" : true,
              "inspiration" : false,
              "terminal" : pickup.terminal,
              // "productDetails":productDetails.toString()
            
            }
            // console.log("Quantity of item ======>",prodItem)
            dispatch(updateCartItemAPI(cartPayload))
            dispatch(getItemInCartAPI({token: userInfo?.accessToken}))
        }
        else if(optionType === "inspiration") {
            const cartPayload = {
              "serviceId": prodItem.id,
              "quantity": quantity,
              "flightId": 0,
              "location": inspiration.location,
              "token": userInfo.accessToken,
              "pinnedFlight" : false,
              "pickupDrop" : false,
              "inspiration" : true,
              "terminal" : "" ,
              // "productDetails":productDetails
            }
            dispatch(updateCartItemAPI(cartPayload))
            dispatch(getItemInCartAPI({token: userInfo?.accessToken}))
        } 
      }
      else {
        if (optionType === "flight" && flight) {
            dispatch(addToCart({"prodItem": prodItem, type: optionType, data: cartData, flightNumber: flight.flightId, 
            "productDetails":productDetails }))
        }
        else if(optionType === "pickupDrop" && pickup)
        {
            dispatch(addToCart({"prodItem": prodItem, type: optionType, data: cartData, flightNumber: pickup.terminal, 
            "productDetails":productDetails }))
        } 
        else  if(optionType === "inspiration" && inspiration){
            dispatch(addToCart({"prodItem": prodItem, type: optionType, data: cartData, flightNumber: inspiration.location, 
            "productDetails":productDetails
               }))
        }
      }
    }
    else{
      const option = "uncategorized"
      dispatch(addToCart({"prodItem": prodItem, type: option, data: cartData, flightNumber: "uncategorized", 
        }))
      if (userInfo?.accessToken){
        const cartPayload = {
          "serviceId": prodItem.id,
          "quantity": quantity,
          "flightId": 0,
          "location": "",
          "token": userInfo.accessToken,
          "pinnedFlight" : false,
          "pickupDrop" : false,
          "inspiration" : false,
          "terminal" : "",
          // "productDetails":productDetails
        }
        // console.log(cartPayload,"cartPayload")
        dispatch(updateCartItemAPI(cartPayload))
        dispatch(getItemInCartAPI({token: userInfo?.accessToken}))
      }
    }
  }
      
  return (
    <>
      <div className="row g-0 w-100" key={key}>
        <div className="col-md-4">
          <div className="cart-item__image">
            <img src={data.images && data.images[0]} alt={data.serviceName} />
          </div>
        </div>
        <div className="col-md-8">
          <div className="cart-item__details h-100 d-flex">
            <div className="h-100">
              <h3>{data.serviceName}</h3>
              <ul className="l-datalist">
                {/* {console.log("************************", JSON.parse(data.productDetails))} */}
                {productDetails &&
                  productDetails != null &&
                  Object.keys(productDetails).map((key, index) => {
                    return (
                      <li className="l-datalist__item">
                        <label>{key}</label>
                        <span>: {productDetails[key]}</span>
                      </li>
                    );
                  })}
              </ul>
              {/* <div className="cartComp__column2">
          Sold By
        </div>

        <div className="cartComp__column5">
          : ABC Electronics
        </div> */}
              {/* <div className=""> Sold By &nbsp; : &nbsp; ABC Electronics</div> */}
              <ul className="l-datalist">
                <li className="l-datalist__item">
                  <label>Product Price</label>
                  <span>
                    :
                    {data.offer ? (
                      <>
                        {" "}<a className="cartComp__line">
                        {data.currency}{" "}
                          {data.unitPrice}{" "}
                          {console.log(data.unitprice)}
                        </a>
                      </>
                    ) : (
                      <strong>
                        {" "}
                        {data.currency}{" "}
                        {data.unitPrice}{" "}
                      </strong>
                    )}
                  </span>
                </li>
              </ul>
              {data.offer && <ul className="l-datalist">
                <li className="l-datalist__item">
                  <label>Offer Price</label>
                  <span>
                    :
                    {data.offer && 
                       <strong> {data.currency}{" "}
                        {offerAmmount.toFixed(2)}</strong>
                        }
                  </span>
                </li>
              </ul>}
              <div className=" bd-highlight reward-points" style={{ paddingLeft: "130px" }}>
                <span>Earned +{data.loyaltyPoints} Reward Points</span>
              </div>
              <ul className="l-datalist">
                <li className="l-datalist__item" >
                  <label style={{paddingTop: "15px"}}>Quantity</label>
                  {/* <span> */}
                    {/* :{" "} */}
                    {/* {(data.quantity && data.quantity == undefined) ||
                    data.quantity == 0
                      ? 1
                      : data.quantity} */}
                      
                    <div key={data.id} className="form-form-group pop-option2" style={{height: "30px"}} >
                      <InputNumber                          
                          value={stateQty}
                          onChange={(e) => handleChange(data, e.value, productDetails)}
                          min={1}
                          max={5}
                          mode="decimal"
                          name="quantity"
                          showButtons
                    />
                    </div>
                  {/* </span> */}
                </li>
              </ul>
              <ul className="l-datalist">
                <li className="l-datalist__item">
                  <label>Total Price</label>
                  <span>
                    : {data.offer ? 
                    <strong>
                    {" "}
                    {data.currency}{" "}
                    {offerAmmount*stateQty}{" "}
                  </strong> :
                  <strong>
                  {" "}
                  {data.currency}{" "}
                  {data.unitPrice*stateQty}{" "}
                </strong>}                      
                  </span>
                </li>
              </ul>
            
            </div>
            <div className="d-flex gap-2">
              <button
                type="button"
                key={data.id}
                className="l-btn l-btn--icon l-btn--outline"
              >
                <i className="pi pi-pencil"></i>
              </button>
              <button
                type="button"
                key={data.id}
                className="l-btn l-btn--icon l-btn--outline l-btn--delete"
                onClick={onDeleteClick}
              >
                <i className="pi pi-trash"></i>
              </button>
              <button
                type="button"
                key={data.id}
                className="l-btn l-btn--icon l-btn--outline"
                onClick={onWishlistClick}
              >
                <i className="pi pi-bookmark"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Details;
