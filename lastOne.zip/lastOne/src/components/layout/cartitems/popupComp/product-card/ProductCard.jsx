
import React, { useState, useEffect } from "react";
import "./product-card.scss";
import { Rating } from 'primereact/rating';
import { fetchWishList, deleteWishList, addToWishList, deleteFromWishList, getWishList } from 'redux/features/wishlist/wishlistAction';
import { useSelector, useDispatch } from 'react-redux';
import { fetchFavourites } from 'redux/features/fav/favouriteSlice';
import MyPopup from 'components/popupcomponent/MyPopup';
import PopupNew from "components/popupcomponent/PopupNew";
import {addToCart, cartError} from 'redux/features/cart/cartslice';
import {addToCartAPI} from "redux/features/cart/cartAction";
import { getItemInCartAPI } from "redux/features/cart/cartAction"
const ProductCard = ({ products, prem, isfav, iswishlisted, isAdded }) => {

  const [visible, setVisible] = useState(false);
  const [wishicon, setWishicon] = useState(iswishlisted ? true : false);
  const [favicon, setFavIcon] = useState(isfav ? true : false);
  const [wishlistSelectedProduct, setWishlistSelectedProduct] = useState([]);
  const [favSelectedProduct, setFavSelectedProduct] = useState([]);
  const [popvisible, setpopVisible] = useState(false);
  const [showSecPopup, setShowSecPopup] = useState(false);
  const [formData, setFormData] = useState({});
  const [selectedProduct, setSelectedProduct] = useState(null);
  const dispatch = useDispatch();

   // selectors
 const { userInfo } = useSelector((state) => state.auth);
 const selectedFlights  = useSelector((state) => state.flight.flightList.filter(item => item.selected));
 const selectedPickups  = useSelector((state) => state.pickupDrop.pickupDropList.filter(item => item.selected));
 const selectedInspirations  = useSelector((state) => state.inspiration.inspirationList.filter(item => item.selected));
 const {inspirationList}  = useSelector((state) => state.inspiration);
 const {pickupDropList}  = useSelector((state) => state.pickupDrop);
 const {flightList}  = useSelector((state) => state.flight);
 const optionType = useSelector(state => state.common.option)
 
  const handleHide = () => {
    setVisible(false);
    setpopVisible(false);
    // setShowSecPopup(false);
  };
  const GetPricePopup = (product) => {
    setVisible(true)
    setSelectedProduct(product)
  };
  const cartPopup = (product) => {
    setpopVisible(true)
    setSelectedProduct(product)
  }
  function handlePopupSecCloses() {
    setShowSecPopup(false);
    setVisible(false);
    
  }
  const handleYesWithFormData = (formData) => {
    setVisible(false);
    setShowSecPopup(true);
    // console.log("Product to be upgraded:", prem);
    // console.log("Received formData in ProductCard:", formData);
    setFormData(formData);
    
  };

  useEffect(() => {
    setFavIcon(isfav ? true : false);
    setWishicon(isAdded ? true : false);
    if (userInfo) {
      dispatch(getWishList({ token: userInfo.accessToken }));
      // dispatch(fetchFavourites({ token: userInfo.accessToken }));
      // dispatch(getItemInCartAPI({ token: userInfo?.accessToken }));
    }
  }, [isfav, isAdded, dispatch, userInfo]);

  const getProductCartDesc = (description) => {
    let result = "";
    if (description && description[0] && description[0].length > 50) {
      result = description[0].match(/.{1,55}/) ?? [0];
      result = `${result}...`;
    } else {
      result = description[0];
    }
    return result;
  }

  function handleAddToWishList(wishproduct) {
    let data = wishlistSelectedProduct;
    const ifExists = wishlistSelectedProduct.find(item => item == wishproduct.id);
    if (!ifExists) {
      data.push(wishproduct.id)
      setWishlistSelectedProduct(data);
    } else {
      const index = favSelectedProduct.indexOf(wishproduct.id);
      data.splice(index, 1);
      setWishlistSelectedProduct(data)
    }

    //   console.log("wish values : ", wishproduct.id)
    //   console.log("isAdded : ", isAdded)
    // dispatch(getWishList({token: userInfo.accessToken}))
    let inputData = { 'serviceId': wishproduct.id };
    if (!ifExists) {
      if (userInfo) {
        dispatch(fetchWishList(inputData));
        // console.log("input data of wishlist is", inputData)
        dispatch(getWishList({ token: userInfo.accessToken }))
      }
      else {
        dispatch(addToWishList(wishproduct));
        // console.log("wishproduct is", wishproduct)
      }
      setWishicon(true)

    } else {
      if (userInfo) {
        dispatch(deleteWishList(wishproduct.id));
        // console.log("input data of delete wishlist is", wishproduct.id)
        dispatch(getWishList({ token: userInfo.accessToken }))
      } else {
        dispatch(deleteFromWishList(wishproduct.id));
        // console.log("delete wishlist is", wishproduct.id)
      }
      setWishicon(false)

    }
  }

  function handleAddToFavourites(favproduct) {
    if (userInfo && userInfo.accessToken) {
      // dispatch(fetchFavourites({ token: userInfo.accessToken }));
      if (isfav) {
        // removeFromFavourites(favproduct.id);
        setFavIcon(true);
        // dispatch(fetchFavourites({ token: userInfo.accessToken }));
        // setIsProductFav(false);
      } else {
        // addToFavourites(favproduct.id);
        setFavIcon(false);
        // dispatch(fetchFavourites({ token: userInfo.accessToken }));
        // let data = favSelectedProduct;
        // const index = favSelectedProduct.indexOf(wishproduct.id);
        // if(!index) {
        //   data.push(wishproduct.id)
        //   setFavSelectedProduct(data);
        // }
        // console.log(favSelectedProduct)
        // setIsProductFav(true);
      }
    }
  }
  function handleAddToCart(prodItem, qty) { // function to close the popup
    // adding add to cart action here, we need to look back once api is ready  cartError
    // const { type, data, flightNumber } = action.payload;
    let quantity = qty === undefined ? 1 : qty
    //console.log("Quantity of item ======>",quantity,prodItem)
    // const isInspriration = inspirationList.length > 0 && optionType === "inspiration";
    // const isFlight = flightList.length > 0 && optionType === "flight";
    // const isPickup = pickupDropList.length > 0 && optionType === "pickupDrop";
  console.log("optionType : ========= ",optionType)
    const isInspriration = inspirationList.length > 0 && optionType === "inspiration" && selectedInspirations.length>0;
    const isFlight = flightList.length > 0 && optionType === "flight" && selectedFlights.length>0;
    const isPickup = pickupDropList.length > 0 && optionType === "pickupDrop" && selectedPickups.length>0;
    
    const cartData = {
      serviceName: prodItem.serviceName,
      description: prodItem.description[0],
      id: prodItem.id,
      unitPrice: prodItem.unitPrice,
      offerPrice: prodItem.offerPrice,
      currency: prodItem.currency,
      unitAdded: quantity,
      images: prodItem.images,
      selected: false
    }
  
    if (isInspriration || isFlight || isPickup) {
      if (userInfo?.accessToken){
        if(optionType === "flight") {
          selectedFlights.forEach((item) => {
            const cartPayload = {
              "serviceId": prodItem.id,
              "quantity": quantity,
              "flightId": item.flightId,
              "location": "",
              "token": userInfo.accessToken,
              "pinnedFlight" : true,
              "pickupDrop" : false,
              "inspiration" : false,
              "terminal" : "" ,
              // "productDetails":formData
            }
            dispatch(addToCartAPI(cartPayload))
            dispatch(getItemInCartAPI({token: userInfo?.accessToken}))
          })
        } 
        else if(optionType === "pickupDrop") {
          selectedPickups.forEach((item) => {
            const cartPayload = {
              "serviceId": prodItem.id,
              "quantity": quantity,
              "flightId": 0,
              "location": "",
              "token": userInfo.accessToken,
              "pinnedFlight" : false,
              "pickupDrop" : true,
              "inspiration" : false,
              "terminal" : "",
              // "productDetails":formData
            
            }
            // console.log("Quantity of item ======>",prodItem)
            dispatch(addToCartAPI(cartPayload))
            dispatch(getItemInCartAPI({token: userInfo?.accessToken}))
          })
        }
        else if(optionType === "inspiration") {
          selectedInspirations.forEach((item) => {
            const cartPayload = {
              "serviceId": prodItem.id,
              "quantity": quantity,
              "flightId": 0,
              "location": item.location,
              "token": userInfo.accessToken,
              "pinnedFlight" : false,
              "pickupDrop" : false,
              "inspiration" : true,
              "terminal" : "" ,
              // "productDetails":formData
            }
            dispatch(addToCartAPI(cartPayload))
            dispatch(getItemInCartAPI({token: userInfo?.accessToken}))
          })
        } 
      }
      else {
        if (optionType === "flight" && selectedFlights.length>0) {
          selectedFlights.forEach((item) => {
            dispatch(addToCart({type: optionType, data: cartData, flightNumber: item.flightNo }))
          })
        }
        else if(optionType === "pickupDrop" && selectedPickups.length>0)
        {
          selectedPickups.forEach((item) => {
            dispatch(addToCart({type: optionType, data: cartData, flightNumber: item.flightNo }))
          })
        } 
        else  if(optionType === "inspiration" && selectedInspirations.length>0){
          selectedInspirations.forEach((item) => {
            dispatch(addToCart({type: optionType, data: cartData, flightNumber: item.location }))
          })
        }
      }
    } 
    else{
      const option = "uncategorized"
      dispatch(addToCart({type: option, data: cartData, flightNumber: "uncategorized" }))
      if (userInfo?.accessToken){
        const cartPayload = {
          "serviceId": prodItem.id,
          "quantity": prodItem.quantity,
          "flightId": 0,
          "location": "",
          "token": userInfo.accessToken,
          "pinnedFlight" : false,
          "pickupDrop" : false,
          "inspiration" : false,
          "terminal" : "",
          // "productDetails":formData
        }
        // console.log(cartPayload,"cartPayload")
        dispatch(addToCartAPI(cartPayload))
        dispatch(getItemInCartAPI({token: userInfo?.accessToken}))
      }
      // toast.error("Please pin a Flight or Inspiration", {
      //   position: toast.POSITION.TOP_CENTER
      // });
    }
    setVisible(false);
  } 

  const offerAmountCal = (data) => {
  let offerAmmount = 0;
      if(data.offer) {
        if(data.offerType == "Percentage"){
          offerAmmount = data.unitPrice - (data.offerPrice/100)*data.unitPrice;
          // console.log("^^^^^^^^^^",data, offerAmmount)
        }
        if(data.offerType == "Flat"){
          offerAmmount = data.unitPrice - data.offerPrice;
        } 
        if(data.offerType == "Others"){
          offerAmmount = data.unitPrice;
        }
      }
      return offerAmmount.toFixed(2);
    }

  return (
    <div className="product-card-wrapper">
      <div className="row g-4">
        {products && products.length > 0 && products.map((product, index) =>
          <div key={index} className="col-md-6">
            <div className="product-card">
              <div className="product-card__thumb">
                <img src={product.images && product.images[0]} alt="name" />
                {favSelectedProduct && favSelectedProduct.find(item => item == product.id) ? <a className="product-card__favourite" onClick={() => handleAddToFavourites(product)}><i className="pi pi-heart-fill" /></a> :
                  <a className="product-card__favourite" onClick={() => handleAddToFavourites(product)}><i className="pi pi-heart" /></a>}
                {/* <> {product.arrival_terminals && product.arrival_terminals.map((item2, idx) =>
                  <a className="product-card__terminal" key={idx} ><span className="product-card__dot">T{item2}</span></a>
                )}
                </> */}
              </div>
              <div className="product-card__details">
                <div className="product-card__description">
                  <h3>{product.serviceName}</h3>
                  {product.offerText && product.offerText.length > 0 ?
                  <div className="product-card__save">{product.offerText && product.offer && product.offerText.slice(0,60)}</div>
                  : <>{product.description && product.description.length > 0 && <p>{getProductCartDesc(product.description).slice(0,60)}</p>}</>}
                    <div className="l-rating mb-3">
                    <Rating value={product.ratingStars} readOnly cancel={false} />
                    <span className="product-card__rating">{product.ratingCount} ratings</span>
                  </div>
                  <div className="d-flex justify-content-between">
                    <div>
                    <div className="d-flex gap-2 align-items-center">
                        <>{product.offerType == "others" ? <strong className="product-card__price">
                            {product.currency}&nbsp;{product.unitPrice}
                          </strong> : <>
                        {product.offer && product.offerType && product.offerType != "Others" ? <>
                          <span className="product-card__actualprice">{product.currency}&nbsp;{product.unitPrice}</span>
                          <strong className="product-card__price">{product.currency}&nbsp;{offerAmountCal(product)}</strong>
                        </> :
                          <strong className="product-card__price">
                            {product.currency}&nbsp;{product.unitPrice}
                          </strong>}</>}
                        
                          </>
                        </div>

                      <div className="product-card__loyality">{product.loyaltyPoints && product.loyaltyPoints} Reward Points</div>
                    </div>
                    <div className="d-flex gap-2">
                      {/* {product?.serviceItemType?.serviceType == "Lounge" || product?.serviceItemType?.serviceType == "Parking" || product?.serviceItemType?.serviceType == "Spa" ? */}
                      {product.category == "Lounge" || product.category== "Parking" || product.category== "Services" ?
                        <button type="button" className="product-card__getprice" onClick={() => GetPricePopup(product)}>Get Price</button> :
                        <>
                          {/* {wishlistSelectedProduct && wishlistSelectedProduct.length > 0 && wishlistSelectedProduct.find(item => item == product.id) ?
                            <button key={product.id} type="button" className="l-btn l-btn--icon l-btn--outline" onClick={() => handleAddToWishList(product)}><i className="pi pi-bookmark-fill"></i></button> :
                            <button type="button" key={product.id} className="l-btn l-btn--icon l-btn--outline" onClick={() => handleAddToWishList(product)}><i className="pi pi-bookmark"></i></button>} */}
                          <button type="button" className="l-btn l-btn--icon l-btn--secondary" onClick={() => cartPopup(product)}><i className="pi pi-shopping-bag"></i></button></>}

                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )
        }
      </div>

      {/* {visible && <Popup visible={visible} onHide={handleHide} selectedCard={selectedProduct} handleYes={handleYesWithFormData} />}
       */}
         {visible && <PopupNew visible={visible} onHide={handleHide} selectedCard={selectedProduct} addToCart={(quantity) => handleAddToCart(selectedProduct, quantity)} handleYes={handleYesWithFormData} />}
      {selectedProduct && selectedProduct.serviceName === "Normal Parking" && showSecPopup && (

<PopupNew
  visible={showSecPopup}
  selectedCard={(prem[0][0])}
  onHide={handlePopupSecCloses}
  addToCart={() => handleAddToCart(prem[0][0])}
  preStoredData={formData}
/>

)}
      {selectedProduct && selectedProduct.serviceName === "Premium Lounge" && showSecPopup && (
        <PopupNew
        visible={showSecPopup}
          selectedCard={(prem[0][1])}
          onHide={handlePopupSecCloses}
          addToCart={() => handleAddToCart(prem[0][0])}
          preStoredData={formData}
        />
      )}
       {popvisible&&<MyPopup visible ={popvisible} selectedCard={selectedProduct} addToCart={(quantity) => handleAddToCart(selectedProduct, quantity)} onHide={handleHide}/>}
      {/* {popvisible&&<MyPopup visible ={popvisible} selectedCard={selectedProduct} onHide={handleHide}/>} */}
     
      {/* {popvisible && <Pop visible={popvisible} onHide={handleHide} selectedCard={selectedProduct} content="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum." />} */}
    </div>
  );
};

export default ProductCard;

