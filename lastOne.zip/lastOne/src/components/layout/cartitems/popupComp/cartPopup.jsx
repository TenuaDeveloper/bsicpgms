import React, { useState, useEffect } from "react";
import { Row } from "react-bootstrap";
import Actions from "../Actions";
import Cartsubtotal from "../cartsubtotal";
import Details from "./popupDetails";
// import Itemimage from './Itemimage';
import Recommendeditem from "../recommended";
import { useSelector, useDispatch } from "react-redux";
// import OfferCard from '../../offercard/offercard';
import {
  removeCart,
  itemSelect,
  itemUnSelect,
  selectAll,
  unSelectAll,
} from "../../../../redux/features/cart/cartslice";
import Accordion from "../../accordions/accordions";
import { getTotalCartCount } from "../../../../redux/features/cart/selector";
import emptyCartImg from "../../../../assets/images/icons/emptycart.png";
import "../styles.css";
// import DeleteConfirmation from '../../popup/deleteConfirmation'
import {
  getItemInCartAPI,
  deleteItemInCartAPI,
} from "../../../../redux/features/cart/cartAction";
// import WishList from '../../../screens/wishlist/wishlist'
// import {WishListIcon, WishListFilledIcon} from '../../../assets/params/icons/icons';
import {
  fetchWishList,
  deleteWishList,
  addToWishList,
  deleteFromWishList,
  getWishList,
} from "../../../../redux/features/wishlist/wishlistAction";

import carticon from "assets/images/icons/carticon.svg";
import "./cartPopupComp.scss";
import { useNavigate } from "react-router-dom";
import ProductCard from "components/layout/cartitems/popupComp/product-card/ProductCard";
import { connect } from "react-redux";
import { Divider } from "primereact/divider";
import moment from "moment";
import { changeCartPopupStatusReducer } from "redux/features/cart/cartPopupSlice";

const dropDownList = ["", "parking", "Shoping", "Spa", "Launges"];

const CartPopupComp = ({
  isAdded,
  wishlistItems,
  flight,
  pickupDrop,
  inspiration,
  uncategorized,
  flightListData,
  pickupDropData,
  inspirationData,
  userInfoData,
}) => {
  // cart releated data listing here again need to refector once api is avilable
  // const flightInCart = useSelector(state => state.cart.cart.flight);
  const flightInCart = flight;
  const pickupInCart = pickupDrop;
  const inspirationInCart = inspiration;
  const uncategorizedInCart = uncategorized;
  // console.log("flight In Cart Data=======>", flightInCart)
  // console.log("pickup In Cart Data=======>", pickupInCart)
  // console.log("inspiration In Cart Data=======>", inspirationInCart)
  const flightList = flightListData;
  const { pickupDropList } = pickupDropData;
  const { inspirationList } = inspirationData;
  const { userInfo } = userInfoData;
  const [displayConfirmationModal, setDisplayConfirmationModal] =
    useState(false);
  const [deleteMessage, setDeleteMessage] = useState(null);
  const [type, setType] = useState(null);
  const [itemIndex, setItemIndex] = useState(null);
  const [itemKey, setItemKey] = useState(null);
  const cartTotal = getTotalCartCount();
  const dispatch = useDispatch();
  let cartKey = Object.keys(flightInCart);
  let pickupKey = Object.keys(pickupInCart);
  let inspirationKey = Object.keys(inspirationInCart);
  let uncategorizedKey = Object.keys(uncategorizedInCart);
  const [wishicon, setWishicon] = useState(isAdded ? true : false);
  // const wishlistItems = useSelector(state => state.wishlistItems.wishlistItems)
  const selectedwishListItems =
    wishlistItems && wishlistItems.length > 0
      ? wishlistItems.length > 2
        ? wishlistItems.slice(0, 2)
        : wishlistItems
      : [];
  // console.log(selectedwishListItems);
  const addtowishlistItems = useSelector(
    (state) => state.addtowishlistItems.addtowishlistItems
  );
  const navigate = useNavigate();

  useEffect(() => {
    if (userInfo && userInfo?.accessToken) {
      dispatch(getItemInCartAPI({ token: userInfo?.accessToken }))
      dispatch(getWishList({ token: userInfo?.accessToken }))
    }
  }, [])

  // const handleCartDelete = (itemIndex,key,type) => {
  //   // console.log("delete cart called ", itemIndex)
  //   console.log("Data Sending to Slice",itemIndex,key)
  //   dispatch(removeCart({ itemIndex ,key, type}))
  // }
  // const handlePickupDelete = (itemIndex,key, type) => {
  //   // console.log("delete cart called ", itemIndex)
  //   console.log("Data Sending to Slice",itemIndex,key)
  //   dispatch(removeCart({ itemIndex ,key, type}))
  // }

  // const handleInspirationDelete = (itemIndex,key, type) => {
  //   // console.log("delete cart called ", itemIndex)
  //   console.log("Data Sending to Slice",itemIndex,key)
  //   dispatch(removeCart({ itemIndex ,key, type}))
  // }

  function handleAddToWishList(wishproduct) {
    let inputData = { serviceId: wishproduct.id };
    if (userInfo) {
      dispatch(fetchWishList(inputData));
    } else {
      dispatch(addToWishList(wishproduct));
    }
  }

  const handleDelete = (itemIndex, itemKey, type) => {
    let cartPayload = {};
    if (type === "flight") {
      const flight = flightList.find((ele) => ele.flightNo === itemKey);
      const flightId = flight.flightId;
      const item = flightInCart[itemKey][itemIndex];
      cartPayload = {
        serviceId: item.id,
        flightId: flightId,
        location: "",
        flightType: type,
        token: userInfo?.accessToken,
      };
    } else if (type === "pickupDrop") {
      const pickup = pickupDropList.find((ele) => ele.terminal === itemKey);
      const terminal = pickup.terminal
      const item = pickupInCart[itemKey][itemIndex];
      cartPayload = {
        serviceId: item.id,
        flightId: 0,
        location: "",
        flightType: type,
        token: userInfo?.accessToken,
        terminal: terminal
      };
    } else if (type === "inspiration") {
      const insp = inspirationList.find((ele) => ele.location === itemKey);
      const location = insp.location;
      const item = inspirationInCart[itemKey][itemIndex];
      cartPayload = {
        serviceId: item.id,
        flightId: 0,
        location: location,
        flightType: type,
        token: userInfo?.accessToken,
      };
    } else {
      const item = uncategorizedInCart[itemKey][itemIndex];
      cartPayload = {
        serviceId: item.id,
        flightId: 0,
        location: "",
        flightType: "uncategorized",
        token: userInfo?.accessToken,
      };
    }

    if (userInfo) {
      dispatch(deleteItemInCartAPI(cartPayload));
    }
    dispatch(removeCart({ itemIndex, itemKey, type }));
    setDisplayConfirmationModal(false);
  };

  const handleCartToWishlist = (index, key, type) => {
    if (type === "flight") {
      const item = flightInCart[key][index];
      // console.log("item is:", item)
      // console.log("***********************cart to wishlist***********")
      handleAddToWishList(item);
      handleDelete(index, key, type);
    } else if (type === "pickupDrop") {
      const item = pickupInCart[key][index];
      handleAddToWishList(item);
      handleDelete(index, key, type);
    } else if (type === "inspiration") {
      const item = inspirationInCart[key][index];
      handleAddToWishList(item);
      handleDelete(index, key, type);
    } else {
      const item = uncategorizedInCart[itemKey][index];
      handleAddToWishList(item);
      handleDelete(index, key, type);
    }
  };

  const hideConfirmationModal = () => {
    setDisplayConfirmationModal(false);
  };

  const handleCheckBoxClick = (itemIndex, key, type) => {
    //console.log("I am selected",Object.keys(flightInCart))
    if (flightInCart[key][itemIndex].selected) {
      dispatch(itemUnSelect({ itemIndex, key, type }));
    } else {
      // console.log("Not Selected")
      dispatch(itemSelect({ itemIndex, key, type }));
    }
  };
  const handlePickupCheckBoxClick = (itemIndex, key, type) => {
    //console.log("I am selected",Object.keys(flightInCart))
    if (pickupInCart[key][itemIndex].selected) {
      dispatch(itemUnSelect({ itemIndex, key, type }));
    } else {
      // console.log("Not Selected")
      dispatch(itemSelect({ itemIndex, key, type }));
    }
  };

  const handleInspirationCheckBoxClick = (itemIndex, key, type) => {
    //console.log("I am selected",Object.keys(flightInCart))
    if (inspirationInCart[key][itemIndex].selected) {
      dispatch(itemUnSelect({ itemIndex, key, type }));
    } else {
      // console.log("Not Selected")
      dispatch(itemSelect({ itemIndex, key, type }));
    }
  };

  const handleUncategorizedCheckBoxClick = (itemIndex, key, type) => {
    //console.log("I am selected",Object.keys(flightInCart))
    if (uncategorizedInCart[key][itemIndex].selected) {
      dispatch(itemUnSelect({ itemIndex, key, type }));
    } else {
      // console.log("Not Selected")
      dispatch(itemSelect({ itemIndex, key, type }));
    }
  };
  useEffect(() => {
    defaultSelctAll();
  }, []);

  useEffect(() => {
    if (userInfo) {
      dispatch(getWishList({ token: userInfo?.accessToken }));
    }
  }, [userInfo, dispatch]);

  const defaultSelctAll = () => {
    dispatch(selectAll({ list: cartKey, type: "flight" }));
    dispatch(selectAll({ list: pickupKey, type: "pickupDrop" }));
    dispatch(selectAll({ list: inspirationKey, type: "inspiration" }));
    dispatch(selectAll({ list: uncategorizedKey, type: "uncategorized" }));
  };
  const handleSelectAll = () => {
    if (isSelectedAll()) {
      dispatch(unSelectAll({ list: cartKey, type: "flight" }));
      dispatch(unSelectAll({ list: pickupKey, type: "pickupDrop" }));
      dispatch(unSelectAll({ list: inspirationKey, type: "inspiration" }));
      dispatch(unSelectAll({ list: uncategorizedKey, type: "uncategorized" }));
    } else {
      defaultSelctAll();
    }
  };
  const isSelectedAll = () => {
    let temp = 0;
    let totalCount = 0;
    cartKey.map((key) => {
      flightInCart[key].map((ele) => {
        totalCount++;
        if (ele.selected) temp++;
      });
    });
    pickupKey.map((key) => {
      pickupInCart[key].map((ele) => {
        totalCount++;
        if (ele.selected) temp++;
      });
    });
    inspirationKey.map((key) => {
      inspirationInCart[key].map((ele) => {
        totalCount++;
        if (ele.selected) temp++;
      });
    });
    uncategorizedKey.map((key) => {
      uncategorizedInCart[key].map((ele) => {
        totalCount++;
        if (ele.selected) temp++;
      });
    });
    if (!totalCount) return false;
    if (totalCount === temp) return true;
    return false;
  };

  const showDeleteModal = (itemIndex, itemKey, type) => {
    setItemIndex(itemIndex);
    setItemKey(itemKey);
    setType(type);
    setDeleteMessage("Are you sure you want to remove the item?");
    setDisplayConfirmationModal(true);
  };

  const handletohome = () => {
    navigate("/");
  };

  const isSelected = isSelectedAll();
  // console.log("flightInCart ::: ", flightInCart);

  const continueShopping = () => {
    // navigate('/home');
    dispatch(changeCartPopupStatusReducer(false));
  }

  const proceedToCart = () => {
    navigate('/cart');
    dispatch(changeCartPopupStatusReducer(false));
  }

  return (
    <div>
      {cartTotal ? (
        <div>
          <div className="cartPopupComp">
            {/* <div className="cartPopupComp__shoppingcart">
              <img src={carticon} alt="cart" className="cartPopupComp__cartChange" />
              <a className="cartPopupComp__shoppingcarttext">  &nbsp;&nbsp;Shopping Cart</a>

              <div className="cartPopupComp__continueShopping">
                <div className="cartPopupComp__continueShoppingbox"></div>
                <div className="cartPopupComp__continueShoppingtext">Continue Shopping</div>
              </div>
            </div> */}
          </div>
          <div className="cartPopupComp__container">
            <div className="d-flex mb-2">
              <h4>Added item to Cart</h4>
            </div>
            <div>
              {Object.keys(flightInCart).map((key, index) => {
                const flight = flightList.find((ele) => ele.flightId == key || ele.flightNo == key);
                const type = "flight";
                const cards = flightInCart[key].map((item, index) => (
                  <div className="cart-item d-flex" key={`${key}-${index}`}>
                    {/* <Itemimage data={item} onCheckBoxClick={() => handleCheckBoxClick(index, key,type)} /> */}
                    <Details
                      data={item}
                      showdivider={
                        flightInCart[key] &&
                          flightInCart[key].length == index + 1
                          ? false
                          : true
                      }
                      userInfo={userInfo}
                      optionType={type}
                      flight={flight}
                    />
                    <Actions
                      key={`${key}-${index}`}
                      data={item}
                      onDeleteClick={() => showDeleteModal(index, key, type)}
                      onWishlistClick={() =>
                        handleCartToWishlist(index, key, type)
                      }
                    />
                  </div>
                ));
                return (
                  <Accordion
                    title={`Flight: ${flight?.flightNo} • ${flight?.scheduleDate} | 
                  ${flight?.source} - ${flight?.destination
                      } | HIA`}
                    contentBlock={cards}
                    key={index}
                  />
                );
              })}
              {Object.keys(pickupInCart).map((key, index) => {
                const pickup =
                  pickupDropList.find(
                    (ele) => ele.terminal == key);
                const type = "pickupDrop";
                // var pickup = {}; // Create an array for common items in another two arrays.
                // for (var i = 0; i < pickupDropList.length; i++) {
                //     for (var j = 0; j < pickupInCart[key].length; j++) {
                //       if (pickupDropList[i].terminal.slice(0,1) == pickupInCart[key][j].pickupOrDrop) { // If the item is common in both arrays
                //         pickup = pickupDropList[i]; // Push common items to the array
                //       }
                //     }
                // }         
                // key is a flight no
                console.log("pickup***********", pickup, pickupDropList, pickupInCart, key)
                const cards = pickupInCart[key].map((item, index) => (
                  <div className="cart-item d-flex" key={`${key}-${index}`}>
                    {/* <Itemimage data={item} onCheckBoxClick={() => handlePickupCheckBoxClick(index, key, type)} /> */}
                    <Details
                      data={item}
                      showdivider={
                        pickupInCart[key] &&
                          pickupInCart[key].length == index + 1
                          ? false
                          : true
                      }
                      optionType={type}
                      pickup={pickup}
                    />
                    <Actions
                      key={`${key}-${index}`}
                      data={item}
                      onDeleteClick={() => showDeleteModal(index, key, type)}
                      onWishlistClick={() =>
                        handleCartToWishlist(index, key, type)
                      }
                    />
                  </div>
                ));
                return (
                  <Accordion
                    title={`${pickup?.terminal}: HIA • ${pickup?.scheduleDate} `}
                    contentBlock={cards}
                    key={index}
                  />
                );
              })}
              {Object.keys(inspirationInCart).map((key, index) => {
                const inspiration =
                  inspirationList.find((ele) => ele.location == key) || {};
                const type = "inspiration";
                // key is a flight no
                const cards = inspirationInCart[key].map((item, index) => (
                  <div className="cart-item d-flex" key={`${key}-${index}`}>
                    {/* <Itemimage data={item} onCheckBoxClick={() => handleInspirationCheckBoxClick(index, key, type)} /> */}
                    <Details
                      data={item}
                      showdivider={
                        inspirationInCart[key] &&
                          inspirationInCart[key].length == index + 1
                          ? false
                          : true
                      }
                      optionType={type}
                      inspiration={inspiration}
                    />
                    <Actions
                      key={`${key}-${index}`}
                      data={item}
                      onDeleteClick={() => showDeleteModal(index, key, type)}
                      onWishlistClick={() =>
                        handleCartToWishlist(index, key, type)
                      }
                    />
                  </div>
                ));
                return (
                  <Accordion
                    title={`Inspiration:  ${inspiration.location} | ${inspiration.scheduleMonth} `}
                    contentBlock={cards}
                    key={index}
                  />
                );
              })}
              {uncategorizedInCart.uncategorized && uncategorizedInCart.uncategorized.length > 0 && Object.keys(uncategorizedInCart).map((key, index) => {
                // const inspiration = inspirationList.find(ele => ele.location === key);
                const type = "uncategorized";
                // key is a flight no
                const cards = uncategorizedInCart[key].map((item, index) => (
                  <div className="cart-item d-flex" key={`${key}-${index}`}>
                    {/* <Itemimage data={item} onCheckBoxClick={() => handleUncategorizedCheckBoxClick(index, key,type)} /> */}
                    <Details
                      data={item}
                      showdivider={
                        uncategorizedInCart[key] &&
                          uncategorizedInCart[key].length == index + 1
                          ? false
                          : true
                      }
                      optionType={type}
                      uncategorized={true}
                    />
                    <Actions
                      key={`${key}-${index}`}
                      data={item}
                      onDeleteClick={() => showDeleteModal(index, key, type)}
                      onWishlistClick={() =>
                        handleCartToWishlist(index, key, type)
                      }
                    />
                  </div>
                ));
                return (
                  <Accordion
                    title="Other Items"
                    contentBlock={cards}
                    key={index}
                  />
                );
              })}
            </div>

            {/* <div className='col-md-4'>
                <Cartsubtotal />

              </div> */}
            {/* 
            <div className="cartPopupComp__continueShopping">
              <div className="cartPopupComp__continueShoppingbox"></div>
              <div className="cartPopupComp__continueShoppingtext">
                Continue Shopping
              </div>
            </div>
            <div className="cartPopupComp__continueShopping2">
              <div className="cartPopupComp__continueShoppingbox2"></div>
              <div className="cartPopupComp__continueShoppingtext2">
                Proceed to Checkout
              </div>
            </div> */}
          </div>
          <div className="l-btn-wrapper">
            <button type="button" className="l-btn l-btn--outline" onClick={() => continueShopping()}>
              Continue Shopping
            </button>
            <button type="button" className="l-btn l-btn--primary" onClick={() => proceedToCart()}>
              Proceed to Cart
            </button>
          </div>
          {selectedwishListItems.length > 0 && <div className="cart-wishlist">
            <div className="cart-wishlist__header d-flex align-items-center">
              <i className="pi pi-bookmark"></i>
              <h3>
                Saved for Later ({selectedwishListItems.length}
                &nbsp;items)
              </h3>
            </div>
            <div className="cart-wishlist__content">
              <ProductCard
                products={selectedwishListItems}
                prem={[]}
                showSavedtoCart={false}                
                wishlist={true}
              />
            </div>
          </div>}
        </div>
      ) : (
        <div className="d-flex justify-content-center">
          <img
            src={emptyCartImg}
            alt=""
            style={{ width: "200px", height: "200px" }}
          />
        </div>
      )}
      <div></div>
    </div>
  );
};

const mapStateToProps = (state) => {
  return {
    wishlistItems: state.wishlistItems.wishlistItems,
    flight: state.cart.cart.flight,
    pickupDrop: state.cart.cart.pickupDrop,
    inspiration: state.cart.cart.inspiration,
    uncategorized: state.cart.cart.uncategorized,
    flightListData: state.flight.flightList,
    pickupDropData: state.pickupDrop,
    inspirationData: state.inspiration,
    userInfoData: state.auth,
  };
};

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(CartPopupComp);
