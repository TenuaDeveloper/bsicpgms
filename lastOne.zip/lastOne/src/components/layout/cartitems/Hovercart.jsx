
import React from 'react'
import crtimg from './cart_img.jpg'
import './styles.css'
const Hovercart = () => {
  return (
    <>

      <div id="cards_landscape_wrap-2">
        <div className="container">
          <div className="row">
            <div className="col-xs-12 col-sm-6 col-md-3 col-lg-3">
              <a href="">
                <div className="card-flyer">
                  <div className="text-box">
                    <div className="image-box">
                      <img src="https://cdn.pixabay.com/photo/2018/03/30/15/11/deer-3275594_960_720.jpg" alt="" />
                    </div>
                    <div className="text-container">
                      <h6>Title 01</h6>
                      <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                    </div>
                  </div>
                </div>
              </a>
            </div>
           
          </div>
        </div>
      </div>

    </>
    // <>
    //   <div className='Hove' >
    //     <div >
    //       <div>
    //         <img src={crtimg} className='hovImage' alt="" />
    //       </div>
    //       <div >
    //         <p className='title-txt-hov fs-6'>Product Name </p>
    //       </div>
    //       <div className="d-flex w-25">
    //         <div >
    //           <p className='prd-price-hov fs-6'>Qty : 4</p>
    //         </div>
    //         <div >
    //           <p className='prd-price-hov fs-6'>$ : 200</p>
    //         </div></div>
    //     </div>
    //     <hr />
    //     <div >
    //       <div>
    //         <img src={crtimg} className='hovImage' alt="" />
    //       </div>
    //       <div >
    //         <p className='title-txt-hov fs-6'>Product Name </p>
    //       </div>
    //       <div className="d-flex w-25">
    //         <div >
    //           <p className='prd-price-hov fs-6'>Qty : 4</p>
    //         </div>
    //         <div >
    //           <p className='prd-price-hov fs-6'>$ : 200</p>
    //         </div></div>
    //     </div>
    //     <hr />
    //     <div >
    //       <div>
    //         <img src={crtimg} className='hovImage' alt="" />
    //       </div>
    //       <div >
    //         <p className='title-txt-hov fs-6'>Product Name </p>
    //       </div>
    //       <div className="d-flex w-25">
    //         <div >
    //           <p className='prd-price-hov fs-6'>Qty : 4</p>
    //         </div>
    //         <div >
    //           <p className='prd-price-hov fs-6'>$ : 200</p>
    //         </div></div>
    //     </div>
    //     <hr />
    //     <div className='row'>
    //       <p className=' total-txt-hov fs-6 '>Total : $ 500</p>
    //     </div>
    //   </div>


    // </>
  )
}

export default Hovercart
