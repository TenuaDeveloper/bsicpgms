import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import './subtotal.css';
import offers from './offers.json';
import { totTalPrice, getTotalSelectedItemPrice, getUnitSelectedItemPrice, getOfferDiscountPrice, getOfferDiscount } from "../../../redux/features/cart/selector"
import userData from './userData.json';
import { resetBookingId } from '../../../redux/features/purchasedItem/purchasedItemAction';

import { Panel } from 'primereact/panel';

const Cartsubtotal = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const handlePayNowClick = () => {
    dispatch(resetBookingId());
    navigate('/payment');
  };
  // console.log("%%%%%%%%%%%%%%", SummaryDetails.getTotalSelectedItemPrice)
  const [offerCode, setOfferCode] = useState('');
  const [discount, setDiscount] = useState(0);
  const [errorMessage, setErrorMessage] = useState('');
  const subtotal = useSelector(state => getTotalSelectedItemPrice(state));
  const { userInfo } = useSelector((state) => state.auth);
  const [offerApplied, setOfferApplied] = useState(false);
  const [loyaltyPointsUsed, setLoyaltyPointsUsed] = useState(0);
  const [showPointsInput, setShowPointsInput] = useState(false);
  const [pointsInputValue, setPointsInputValue] = useState('');
  const [balance, setBalance] = useState(0);
  const [showofferInput, setShowofferInput] = useState(false);
  
  const unitPrice = useSelector(state => getUnitSelectedItemPrice(state));
  const discountPrice = useSelector(state => getOfferDiscountPrice(state));
  const discountPercentage = useSelector(state => getOfferDiscount(state));

  // console.log(unitPrice, subtotal, discountPrice, discountPercentage)
  

  React.useEffect(() => {
    if (userInfo) {
      const user = userData.find((user) => user.id === 1);
      setBalance(user.balance);
    }
  }, [userData, userInfo]);

  const handleApplyOfferCode = (e) => {
    e.preventDefault();
    const selectedOffer = offers.find((offer) => offer.code === offerCode);
    if (selectedOffer) {
      if (selectedOffer.type === 'percent') {
        setDiscount(subtotal * selectedOffer.discount);
      } else if (selectedOffer.type === 'flat') {
        setDiscount(selectedOffer.discount);
      } else {
        setDiscount(0);
      }
      setOfferApplied(true);
      setErrorMessage('');
      setShowofferInput(false)
    } else {
      setDiscount(0);
      setOfferApplied(false);
      setErrorMessage('Promocode is Invalid/expired');
    }

  };
  useEffect(() => {
    const selectedOffer = offers.find((offer) => offer.code === offerCode);
    if (selectedOffer) {
      if (selectedOffer.type === 'percent') {
        setDiscount(subtotal * selectedOffer.discount);
      } else if (selectedOffer.type === 'flat') {
        setDiscount(selectedOffer.discount);
      } else {
        setDiscount(0);
      }
      setOfferApplied(true);
      setErrorMessage('');
      setShowofferInput(false)
    } else {
      setDiscount(0);
      setOfferApplied(false);
      //  setErrorMessage('Promocode is Invalid/expired');
    }
  }, [subtotal, offerCode]);

  // const total = offerApplied ? subtotal - discount : subtotal;
  const total = offerApplied ? subtotal - discount : subtotal;
  const remainingBalance = Math.max(total - (loyaltyPointsUsed * 0.5), 0);
  const REWARD_POINTS_PER_DOLLAR = 10;
  const rewardPoints = Math.floor(total / REWARD_POINTS_PER_DOLLAR);
  const handleUsePointsClick = () => {
    // console.log("userinfo:", userInfo)
    if (userInfo) {
      setShowPointsInput(true);
    } else {
      navigate('/login');
    }
  };
  const handlePointsInputChange = (e) => {
    const value = e.target.value;
    if (!isNaN(value) && value !== '') {
      setPointsInputValue(value);
    }
  };

  const handlePointsInputSubmit = (e) => {
    e.preventDefault();
    const pointsToUse = parseInt(pointsInputValue);
    if (pointsToUse > 0 && pointsToUse <= balance) {
      setLoyaltyPointsUsed(pointsToUse);
      setShowPointsInput(false);
    }
  };
  const handleCloseButtonClick = () => { setShowPointsInput(false); }
  const showOffer = () => { setShowofferInput(true); }

  return (
    <div className="cartComp__subtotal-container">
      <Panel header="Price Summary">
        <p className="m-0">
          <div className="pt-3 pb-2">
            <div class="cartComp__summary_sub">
              <div className="cartComp__summary_sub_head"><span>Original Product price</span></div>
              <span className="cartComp__summary_sub_head2">INR&nbsp;{unitPrice}</span>

            </div>
          </div>
          <div className="pt-3 pb-2">
            <div class="cartComp__summary_sub">
              <div className="cartComp__summary_sub_head"><span>You Saved&nbsp;({Math.round(discountPercentage)}%)</span></div>
              <span className="cartComp__summary_sub_head2">INR&nbsp;{discountPrice.toFixed(1)}</span>
            </div>
          </div>
          <div className="pt-3 pb-2">
            <div class="cartComp__summary_sub">
              <div className="cartComp__summary_sub_head"><span>Price After Discount</span></div>
              <span className="cartComp__summary_sub_head2">INR&nbsp;{subtotal}</span>
            </div>
          </div>
          <div className="pt-3 pb-2">
            <div class="cartComp__summary_sub">
              <div className="cartComp__summary_sub_head"><span>Delivery Charges</span></div>
              <span className="cartComp__summary_sub_head2">Free</span>
            </div>
          </div>

          <div className="pt-3 pb-2 cartComp__total-sub-container">
            <div class="cartComp__summary_sub">
              <div className="cartComp__summary_sub_head3"><span>Total amount to be paid</span></div>
              <span 
              // className="cartComp__summary_sub_head4"
              >
                {/* ${remainingBalance} */}
                INR&nbsp;{subtotal}
                </span>
            </div>
          </div>
        </p>
        <div className="cartComp__cardDivider2"></div>
      </Panel>
      <button className="cartComp__placeOrder" onClick={handlePayNowClick}>
        <p className="cartComp__placeOrderText"> Place Order</p>
        </button>
      {/* <SummaryDetails /> */}
    </div>
  );
};

export default Cartsubtotal
