import React from 'react'
// import edit from '../../../assets/params/images/icon/edit.png'
// import prddelete from '../../../assets/params/images/icon/delete.png'
// import {WishListIcon} from '../../../assets/params/icons/icons';

const Actions = ({onEditClick, onDeleteClick, onWishlistClick, key}) => {
  return (
    <>
      <div onClick={onEditClick} key={key}>
        {/* <img className="action_box" src={edit} alt="" />
      </div>
      <div onClick={onDeleteClick}>
        <img className="action_box" src={prddelete} alt="" />
      </div>
      <div onClick={onWishlistClick}>
      <WishListIcon className="action_box"/> */}
      </div>
    </>
  )
}

export default Actions
