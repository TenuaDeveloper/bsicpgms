import React, { useState, useEffect } from "react";
import { Row } from "react-bootstrap";
import Actions from "./Actions";
import Cartsubtotal from "./cartsubtotal";
import Details from "./details";
// import Itemimage from './Itemimage';
import Recommendeditem from "./recommended";
import { useSelector, useDispatch } from "react-redux";
// import OfferCard from '../../offercard/offercard';
import {
  removeCart,
  itemSelect,
  itemUnSelect,
  selectAll,
  unSelectAll,
} from "../../../redux/features/cart/cartslice";
import Accordion from "../accordions/accordions";
import { getTotalCartCount } from "../../../redux/features/cart/selector";
import emptyCartImg from "../../../assets/images/icons/emptycart.png";
import "./styles.css";
// import DeleteConfirmation from '../../popup/deleteConfirmation'
import {
  getItemInCartAPI,
  deleteItemInCartAPI,
} from "../../../redux/features/cart/cartAction";
// import WishList from '../../../screens/wishlist/wishlist'
// import {WishListIcon, WishListFilledIcon} from '../../../assets/params/icons/icons';
import {
  fetchWishList,
  deleteWishList,
  addToWishList,
  deleteFromWishList,
  getWishList,
} from "../../../redux/features/wishlist/wishlistAction";

import carticon from "assets/images/icons/carticon.svg";
import "./cartComp.scss";
import { useNavigate } from "react-router-dom";
import ProductCard from "components/product-card/ProductCard";
import { connect } from "react-redux";
import { Divider } from "primereact/divider";
import moment from "moment";

const dropDownList = ["", "parking", "Shoping", "Spa", "Launges"];

const Displaycart = ({
  isAdded,
  wishlistItems,
  flight,
  pickupDrop,
  inspiration,
  uncategorized,
  flightListData,
  pickupDropData,
  inspirationData,
  userInfoData,
  cart,
}) => {
  // cart releated data listing here again need to refector once api is avilable
  // const flightInCart = useSelector(state => state.cart.cart.flight);
  const flightInCart = flight;
  const pickupInCart = pickupDrop;
  const inspirationInCart = inspiration;
  const uncategorizedInCart = uncategorized;
  // console.log("flight In Cart Data=======>", flightInCart)
  // console.log("pickup In Cart Data=======>", pickupInCart)
  // console.log("inspiration In Cart Data=======>", inspirationInCart)
  const flightList = flightListData;
  const { pickupDropList } = pickupDropData;
  const { inspirationList } = inspirationData;
  const { userInfo } = userInfoData;
  const [displayConfirmationModal, setDisplayConfirmationModal] =
    useState(false);
  const [deleteMessage, setDeleteMessage] = useState(null);
  const [type, setType] = useState(null);
  const [itemIndex, setItemIndex] = useState(null);
  const [itemKey, setItemKey] = useState(null);
  const cartTotal = getTotalCartCount();
  const dispatch = useDispatch();
  let cartKey = Object.keys(flightInCart);
  let pickupKey = Object.keys(pickupInCart);
  let inspirationKey = Object.keys(inspirationInCart);
  let uncategorizedKey = Object.keys(uncategorizedInCart);
  const [wishicon, setWishicon] = useState(isAdded ? true : false);
  const selectedPickups  = useSelector((state) => state.pickupDrop.pickupDropList);
  // const wishlistItems = useSelector(state => state.wishlistItems.wishlistItems)
  const selectedwishListItems =
    wishlistItems && wishlistItems.length > 0
      ? wishlistItems.length > 4
        ? wishlistItems.slice(0, 4)
        : wishlistItems
      : [];
  // console.log(selectedwishListItems);
  const addtowishlistItems = useSelector(
    (state) => state.addtowishlistItems.addtowishlistItems
  );
  const navigate = useNavigate();

  useEffect(() => {
    if (userInfo && userInfo?.accessToken) {
      dispatch(getItemInCartAPI({token: userInfo?.accessToken}))
      dispatch(getWishList({ token: userInfo?.accessToken }))
    }
  }, [])

  // const handleCartDelete = (itemIndex,key,type) => {
  //   // console.log("delete cart called ", itemIndex)
  //   console.log("Data Sending to Slice",itemIndex,key)
  //   dispatch(removeCart({ itemIndex ,key, type}))
  // }
  // const handlePickupDelete = (itemIndex,key, type) => {
  //   // console.log("delete cart called ", itemIndex)
  //   console.log("Data Sending to Slice",itemIndex,key)
  //   dispatch(removeCart({ itemIndex ,key, type}))
  // }

  // const handleInspirationDelete = (itemIndex,key, type) => {
  //   // console.log("delete cart called ", itemIndex)
  //   console.log("Data Sending to Slice",itemIndex,key)
  //   dispatch(removeCart({ itemIndex ,key, type}))
  // }

  function handleAddToWishList(wishproduct) {
    let inputData = { serviceId: wishproduct.id };
    if (userInfo) {
      dispatch(fetchWishList(inputData));
    } else {
      dispatch(addToWishList(wishproduct));
    }
  }

  const handleDelete = (itemIndex, itemKey, type) => {
    let cartPayload = {};
    console.log(itemIndex, itemKey, type);
    if (type === "flight") {
      const flight = flightList.find((ele) => ele.flightId == itemKey);
      const flightId = flight.flightId;
      const item = flightInCart[itemKey][itemIndex];
      console.log(flightInCart, item);
      cartPayload = {
        serviceId: item.id,
        flightId: flightId,
        location: "",
        flightType: type,
        token: userInfo?.accessToken,
        terminal: ""
      };
    } else if (type === "pickupDrop") {
      const pickup = pickupDropList.find((ele) => ele.terminal == itemKey);
      const item = pickupInCart[itemKey][itemIndex];
      const terminal = pickup.terminal
      cartPayload = {
        serviceId: item.id,
        flightId: 0,
        location: "",
        flightType: type,
        token: userInfo?.accessToken,
        terminal: terminal
      };
    } else if (type === "inspiration") {
      const insp = inspirationList.find((ele) => ele.location == itemKey);
      const location = insp.location;
      const item = inspirationInCart[itemKey][itemIndex];
      cartPayload = {
        serviceId: item.id,
        flightId: 0,
        location: location,
        flightType: type,
        token: userInfo?.accessToken,
        terminal: ""
      };
    } else {
      const item = uncategorizedInCart.uncategorized[itemIndex];
      cartPayload = {
        serviceId: item.id,
        flightId: 0,
        location: "",
        flightType: "uncategorized",
        token: userInfo?.accessToken,
        terminal: ""
      };
    }

    if (userInfo) {
      dispatch(deleteItemInCartAPI(cartPayload));
    }
    dispatch(removeCart({ itemIndex, itemKey, type }));
    setDisplayConfirmationModal(false);
  };

  const handleCartToWishlist = (index, key, type) => {
    console.log(index, key, type, flightInCart);
    if (type === "flight") {
      const item = flightInCart[key][index];
      // console.log("item is:", item)
      // console.log("***********************cart to wishlist***********")
      handleAddToWishList(item);
      handleDelete(index, key, type);
    } else if (type === "pickupDrop") {
      const item = pickupInCart[key][index];
      handleAddToWishList(item);
      handleDelete(index, key, type);
    } else if (type === "inspiration") {
      const item = inspirationInCart[key][index];
      handleAddToWishList(item);
      handleDelete(index, key, type);
    } else {
      const item = uncategorizedInCart.uncategorized[index];
      handleAddToWishList(item);
      handleDelete(index, key, type);
    }
    if (userInfo) {
      dispatch(getWishList({ token: userInfo?.accessToken }))
    }
  };

  const hideConfirmationModal = () => {
    setDisplayConfirmationModal(false);
  };

  const handleCheckBoxClick = (itemIndex, key, type) => {
    //console.log("I am selected",Object.keys(flightInCart))
    if (flightInCart[key][itemIndex].selected) {
      dispatch(itemUnSelect({ itemIndex, key, type }));
    } else {
      // console.log("Not Selected")
      dispatch(itemSelect({ itemIndex, key, type }));
    }
  };
  const handlePickupCheckBoxClick = (itemIndex, key, type) => {
    //console.log("I am selected",Object.keys(flightInCart))
    if (pickupInCart[key][itemIndex].selected) {
      dispatch(itemUnSelect({ itemIndex, key, type }));
    } else {
      // console.log("Not Selected")
      dispatch(itemSelect({ itemIndex, key, type }));
    }
  };

  const handleInspirationCheckBoxClick = (itemIndex, key, type) => {
    //console.log("I am selected",Object.keys(flightInCart))
    if (inspirationInCart[key][itemIndex].selected) {
      dispatch(itemUnSelect({ itemIndex, key, type }));
    } else {
      // console.log("Not Selected")
      dispatch(itemSelect({ itemIndex, key, type }));
    }
  };

  const handleUncategorizedCheckBoxClick = (itemIndex, key, type) => {
    //console.log("I am selected",Object.keys(flightInCart))
    if (uncategorizedInCart[key][itemIndex].selected) {
      dispatch(itemUnSelect({ itemIndex, key, type }));
    } else {
      // console.log("Not Selected")
      dispatch(itemSelect({ itemIndex, key, type }));
    }
  };
  useEffect(() => {
    defaultSelctAll();
  }, []);

  useEffect(() => {
    if (userInfo) {
      dispatch(getItemInCartAPI({ token: userInfo?.accessToken }));
      dispatch(getWishList({ token: userInfo?.accessToken }));
    }
  }, [userInfo, dispatch]);

  const defaultSelctAll = () => {
    dispatch(selectAll({ list: cartKey, type: "flight" }));
    dispatch(selectAll({ list: pickupKey, type: "pickupDrop" }));
    dispatch(selectAll({ list: inspirationKey, type: "inspiration" }));
    dispatch(selectAll({ list: uncategorizedKey, type: "uncategorized" }));
  };
  const handleSelectAll = () => {
    if (isSelectedAll()) {
      dispatch(unSelectAll({ list: cartKey, type: "flight" }));
      dispatch(unSelectAll({ list: pickupKey, type: "pickupDrop" }));
      dispatch(unSelectAll({ list: inspirationKey, type: "inspiration" }));
      dispatch(unSelectAll({ list: uncategorizedKey, type: "uncategorized" }));
    } else {
      defaultSelctAll();
    }
  };
  const isSelectedAll = () => {
    let temp = 0;
    let totalCount = 0;
    cartKey.map((key) => {
      flightInCart[key].map((ele) => {
        totalCount++;
        if (ele.selected) temp++;
      });
    });
    pickupKey.map((key) => {
      pickupInCart[key].map((ele) => {
        totalCount++;
        if (ele.selected) temp++;
      });
    });
    inspirationKey.map((key) => {
      inspirationInCart[key].map((ele) => {
        totalCount++;
        if (ele.selected) temp++;
      });
    });
    uncategorizedKey.map((key) => {
      uncategorizedInCart[key].map((ele) => {
        totalCount++;
        if (ele.selected) temp++;
      });
    });
    if (!totalCount) return false;
    if (totalCount === temp) return true;
    return false;
  };

  const showDeleteModal = (itemIndex, itemKey, type) => {
    setItemIndex(itemIndex);
    setItemKey(itemKey);
    setType(type);
    setDeleteMessage("Are you sure you want to remove the item?");
    setDisplayConfirmationModal(true);
  };

  const handletohome = () => {
    navigate("/");
  };

  const isSelected = isSelectedAll();
  // console.log("flightInCart ::: ", flightInCart);
  return (
    <div>
      {cartTotal ? (
        <div>
          <div className="cartComp">
            <div className="cartComp__shoppingcart">
              <img src={carticon} alt="cart" className="cartComp__cartChange" />
              <a className="cartComp__shoppingcarttext">
                {" "}
                &nbsp;&nbsp;Shopping Cart
              </a>

              <div className="cartComp__continueShopping">
                <div className="cartComp__continueShoppingbox"></div>
                <div className="cartComp__continueShoppingtext">
                  Continue Shopping
                </div>
              </div>
            </div>
          </div>
          <div className="cartComp__container">
            <div className="row">
              <div className="col-md-8">
                <div className="col-md-12">
                  {Object.keys(flightInCart).map((key, index) => {
                    const flight = flightList.find(
                      (ele) => ele.flightId == key || ele.flightNo == key
                    );
                    // console.log(flight, flightList, key)
                    const type = "flight";
                    const cards = flightInCart[key].map((item, index) => (
                      <div className="cart-item d-flex" key={`${key}-${index}`}>
                        {/* <Itemimage data={item} onCheckBoxClick={() => handleCheckBoxClick(index, key,type)} /> */}
                        <Details
                          data={item}
                          showdivider={
                            flightInCart[key] &&
                            flightInCart[key].length == index + 1
                              ? false
                              : true
                          }
                          key={`${key}-${index}`}
                          data={item}
                          onDeleteClick={() => handleDelete(index, key, type)}
                          onWishlistClick={() =>
                            handleCartToWishlist(index, key, type)
                          }
                          optionType={type}
                          flight={flight}
                        />
                        {/* <Actions key={`${key}-${index}`} data={item} onDeleteClick={() => showDeleteModal(index, key, type)} onWishlistClick={() => handleCartToWishlist(index, key, type)} /> */}
                      </div>
                    ));
                    return (
                      <Accordion
                        title={`Flight: ${flight?.flightNo} • ${flight?.scheduleDate} | 
                        ${flight?.source} - ${
                          flight?.destination
                        } | HIA`}
                        contentBlock={cards}
                        key={index}
                      />
                    );
                  })}
                  {Object.keys(pickupInCart).map((key, index) => {
                    const pickup =
                    pickupDropList.find(
                      (ele) => ele.terminal == key);
                    // console.log(pickup,pickupDropList, parseInt(key), parseInt(key.match(/\d+/g)[0]))
                    const type = "pickupDrop";
                    // key is a flight no
                    const cards = pickupInCart[key].map((item, index) => (
                      <div className="cart-item d-flex" key={`${key}-${index}`}>
                        {/* <Itemimage data={item} onCheckBoxClick={() => handlePickupCheckBoxClick(index, key, type)} /> */}
                        <Details
                          data={item}
                          showdivider={
                            pickupInCart[key] &&
                            pickupInCart[key].length == index + 1
                              ? false
                              : true
                          }
                          key={`${key}-${index}`}
                          data={item}
                          onDeleteClick={() => handleDelete(index, key, type)}
                          onWishlistClick={() =>
                            handleCartToWishlist(index, key, type)
                          }
                          optionType={type}
                          pickup={pickup}
                        />
                        {/* <Actions key={`${key}-${index}`} data={item} onDeleteClick={() => showDeleteModal(index, key, type)} onWishlistClick={() => handleCartToWishlist(index, key, type)} /> */}
                      </div>
                    ));
                    return (
                      <Accordion
                        title={`${pickup?.terminal}: HIA • ${pickup?.scheduleDate} `}
                        contentBlock={cards}
                        key={index}
                      />
                    );
                  })}
                  {Object.keys(inspirationInCart).map((key, index) => {
                    const inspiration =
                      inspirationList.find((ele) => ele.location == key) || {};
                    const type = "inspiration";
                    // key is a flight no
                    const cards = inspirationInCart[key].map((item, index) => (
                      <div className="cart-item d-flex" key={`${key}-${index}`}>
                        {/* <Itemimage data={item} onCheckBoxClick={() => handleInspirationCheckBoxClick(index, key, type)} /> */}
                        <Details
                          data={item}
                          showdivider={
                            inspirationInCart[key] &&
                            inspirationInCart[key].length == index + 1
                              ? false
                              : true
                          }
                          key={`${key}-${index}`}
                          data={item}
                          onDeleteClick={() => handleDelete(index, key, type)}
                          onWishlistClick={() =>
                            handleCartToWishlist(index, key, type)
                          }
                          optionType={type}
                          inspiration={inspiration}
                        />
                        {/* <Actions key={`${key}-${index}`} data={item} onDeleteClick={() => showDeleteModal(index, key, type)} onWishlistClick={() => handleCartToWishlist(index, key, type)} /> */}
                      </div>
                    ));
                    return (
                      <Accordion
                        title={`Inspiration:  ${inspiration.location} | ${inspiration.scheduleMonth} `}
                        contentBlock={cards}
                        key={index}
                      />
                    );
                  })}
                  {uncategorizedInCart.uncategorized && uncategorizedInCart.uncategorized.length > 0 && Object.keys(uncategorizedInCart).map((key, index) => {
                    // const inspiration = inspirationList.find(ele => ele.location === key);
                    const type = "uncategorized";
                    // key is a flight no
                    const cards = uncategorizedInCart[key].map(
                      (item, index) => (
                        <div
                          className="cart-item d-flex"
                          key={`${key}-${index}`}
                        >
                          {/* <Itemimage data={item} onCheckBoxClick={() => handleUncategorizedCheckBoxClick(index, key,type)} /> */}
                          <Details
                            data={item}
                            showdivider={
                              uncategorizedInCart[key] &&
                              uncategorizedInCart[key].length == index + 1
                                ? false
                                : true
                            }
                            key={`${key}-${index}`}
                            data={item}
                            onDeleteClick={() => handleDelete(index, key, type)}
                            onWishlistClick={() =>
                              handleCartToWishlist(index, key, type)
                            }
                            optionType={type}
                            uncategorized={true}
                          />
                          {/* <Actions key={`${key}-${index}`} data={item} onDeleteClick={() => showDeleteModal(index, key, type)} onWishlistClick={() => handleCartToWishlist(index, key, type)} /> */}
                        </div>
                      )
                    );
                    return (
                      <Accordion
                        title="Other Items"
                        contentBlock={cards}
                        key={index}
                      />
                    );
                  })}
                </div>
              </div>

              <div className="col-md-4">
                <Cartsubtotal cart={cart} />
              </div>
            </div>
          </div>
          {selectedwishListItems.length > 0 && <section className="cart-wishlist">
            <div className="cart-wishlist__header d-flex align-items-center">
              <i className="pi pi-bookmark"></i>
              <h3 className="mb-0">
                Saved for Later ({selectedwishListItems.length}
                &nbsp;items)
              </h3>
            </div>
            <div className="cart-wishlist__content">
              <ProductCard
                products={selectedwishListItems}
                prem={[]}
                showSavedtoCart={false}
                wishlist={true}
              />
            </div>
          </section>}
        </div>
      ) : (
        <div className="d-flex justify-content-center">
          <img
            src={emptyCartImg}
            alt=""
            style={{ width: "400px", height: "400px" }}
          />
        </div>
      )}
      <div></div>
    </div>
  );
};

const mapStateToProps = (state) => {
  return {
    wishlistItems: state.wishlistItems.wishlistItems,
    flight: state.cart.cart.flight,
    pickupDrop: state.cart.cart.pickupDrop,
    inspiration: state.cart.cart.inspiration,
    uncategorized: state.cart.cart.uncategorized,
    flightListData: state.flight.flightList,
    pickupDropData: state.pickupDrop,
    inspirationData: state.inspiration,
    userInfoData: state.auth,
    cart: state.cart.cart,
  };
};

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(Displaycart);
