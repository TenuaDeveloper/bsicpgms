import React, { useState, useEffect } from "react";
import { unwrapResult } from "@reduxjs/toolkit";
// import cartimg from "../../../assets/params/images/productimage/prdt1.png";
// import wishlst from "../../../assets/params/images/icon/wishlist.png";
// import addcart from "../../../assets/params/images/icon/addcart.png";
import { useSelector, useDispatch } from "react-redux";
import { getcartOffer } from "../../../redux/features/cartoffer/cartofferAction";
import "./styles.css";

const Recommendeditem = () => {
  const [serviceId, setserviceId] = useState([]);
  const [respItems, setRespItem] = useState([]);
  const dispatch = useDispatch();

  const flightInCart = useSelector((state) => state.cart.cart.flight);
  const uncategorizedInCart = useSelector((state) => state.cart.cart.uncategorized);

  useEffect(() => {
    const updateServiceId = () => {
      let uniqueServiceIdSet = new Set();

      Object.keys(flightInCart).forEach((key) => {
        flightInCart[key].forEach((item) => {
          uniqueServiceIdSet.add(item.id);
        });
      });

      Object.keys(uncategorizedInCart).forEach((key) => {
        uncategorizedInCart[key].forEach((item) => {
          uniqueServiceIdSet.add(item.id);
        });
      });

      setserviceId([...uniqueServiceIdSet]);
    };

    updateServiceId();
  }, [flightInCart, uncategorizedInCart]);

  useEffect(() => {
    const fetchOffers = async () => {
      const offers = [];

      for (const id of serviceId) {
        try {
          const actionResult = await dispatch(getcartOffer(id));
          const responseData = unwrapResult(actionResult);
          offers.push(responseData);
        } catch (error) {
          console.error("Error fetching offer:", error);
        }
      }

      setRespItem(offers);
    };

    if (serviceId.length > 0) {
      fetchOffers();
    }
  }, [serviceId, dispatch]);

  // console.log("Items from API response", respItems);
  const isEmpty = respItems.every((subArray) => subArray.length === 0);

  const filteredRespItems = respItems.map((innerArray) =>
    innerArray.filter((item) => !serviceId.includes(item.id))
  );

  return (
    <>
      {!isEmpty && (
        <>
          <span className="d-flex recommend-box" style={{ width: "250px" }}>
            Recommended:
          </span>
          {filteredRespItems.map((innerArray) =>
            innerArray.map((item) => (
              <div className="d-flex recommend-box">
                <div>
                  <img src={item.images[0]} alt="" className="recommend-img" />
                </div>
                <div>
                  <span className="recomm-title">{item.serviceName}</span>
                </div>
                <div>
                  <img className="" src={wishlst} alt="" />
                </div>
                <div>
                  <img className="" src={addcart} alt="" />
                </div>
              </div>
            ))
          )}
        </>
      )}
    </>
  );
};

export default Recommendeditem;
