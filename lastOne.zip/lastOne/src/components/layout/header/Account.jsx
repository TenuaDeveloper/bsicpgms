import { Avatar } from 'primereact/avatar';
import { Button } from "primereact/button";
import { Dialog } from 'primereact/dialog';
import { Divider } from "primereact/divider";
import { OverlayPanel } from "primereact/overlaypanel";
import { classNames } from 'primereact/utils';
import { useEffect, useRef, useState } from "react";
import Navbar from "react-bootstrap/Navbar";
import { connect, useDispatch, useSelector } from "react-redux";
import { NavLink, useNavigate } from "react-router-dom";
import { clearInspMessages } from "../../../redux/features/Notification/inspirationNotificationslice";
import { clearMessages } from "../../../redux/features/Notification/messagesSlice";
import { clearPickMessages } from "../../../redux/features/Notification/pickNotificationSlice";
import { logout, updateProfile } from "../../../redux/features/auth/authSlice";
import { resetCart } from "../../../redux/features/cart/cartslice";
import { arrivalActions } from "../../../redux/features/newArrivalsFilter/newarrivalSlice";
import { preferenceActions , deletePreference, fetchPreference, storeUserPreference } from "../../../redux/features/preference/preferenceAction";
import { resetBookingId } from "../../../redux/features/purchasedItem/purchasedItemAction";
import { recommendedCategoriesActions } from "redux/features/recommendedCategories/recommendedCategoriesSlice";
import { personalizedServicesAndOffersActions } from "../../../redux/features/newPersonalizedServices/newPersonalizedServicesSlice";
import { resetSearchCategoryResults } from "../../../redux/features/search/searchaction";
import { servicesAndOffersTerminalSliceAction } from "../../../redux/features/terminal/selectedTerminalSlice";
import { useGetDetailsQuery } from "../../../redux/services/auth/authService";
import userIcon from "../images/image.png";
import "./styles.css";

const Account = ({resetnewArrivals, resetservicesAndOffersTerminal,fetchPreference, fetchExistingPreference,userpreference, fetchRecommendedCategories, recommendedCategories,}) => {
  const { userInfo } = useSelector((state) => state.auth);
  const preferenceList = useSelector((state) => state.preference.preference.preference);
  const userpreferenceList = useSelector((state) => state.preference.userpreference.userpreference);
  const [visiblePreference, setDialogVisible] = useState(false);
  const [selectedPreferences, setSelectedPreferences] = useState([]);
  const [storePreferenceResponseData, setPreferenceResponseData ] = useState([]);
  const [storeExistingPreferenceData, setExistingPreferenceResponseData ] = useState([]);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  let accountIcon = userIcon;
  if (userInfo) {
    const initials = userInfo.username.substr(0, 2).toUpperCase();
    accountIcon = `https://ui-avatars.com/api/?name=${initials}&background=1980DE&color=ffff&bold=true&font-size=0.5`;
  }


  useEffect(() => {
    // Call fetchPreference on component initialization or login
    fetchPreference();
    console.log("preferenceList",preferenceList)
    if (userInfo){
      fetchExistingPreference({ token: userInfo.accessToken });
      console.log("userpreferenceList",userpreferenceList)
    }
  }, [fetchPreference,fetchExistingPreference]);
  
  const handleLogout = () => {
    dispatch(logout());
    dispatch(resetCart());
    dispatch(resetSearchCategoryResults());
    dispatch(clearMessages());
    dispatch(resetBookingId());
    dispatch(resetnewArrivals());
    dispatch(resetservicesAndOffersTerminal());
    dispatch(clearPickMessages());
    dispatch(clearInspMessages());
    navigate("/");
    dispatch(personalizedServicesAndOffersActions.fetchPersonalizedServicesAndOffers({"filter": `filterType=`, "selectedPageNo": 1, "req":{"productCategories" : []}, "filterType": ""}));
  };
  const op = useRef(null);

  // automatically authenticate user if token is found
  const { data, isFetching } = useGetDetailsQuery("userDetails", {
    pollingInterval: 900000, // 15mins
  });
  function redirectToFavorites() {
    // Specify the URL of the favorites page
    const favoritesPageUrl = "/favourites";
  
    // Redirect the user to the favorites page
    window.location.href = favoritesPageUrl;
  }
  useEffect(() => {
    if (data) dispatch(updateProfile(data));
    if(userInfo && userInfo.memberId!==0 && recommendedCategories && recommendedCategories.items) {
      dispatch(personalizedServicesAndOffersActions.fetchPersonalizedServicesAndOffers({"filter": `filterType=`, "selectedPageNo": 1, "req":{"productCategories" : Object.keys(recommendedCategories.items)}, "filterType": ""}));     
    }
    else if(userInfo && userInfo.memberId===0 && userpreference && userpreference.userpreference) {
      dispatch(personalizedServicesAndOffersActions.fetchPersonalizedServicesAndOffers({ "filter": `filterType=`, "selectedPageNo": 1, "req": { "productCategories": userpreference.userpreference }, "filterType": "" }));
    }
  }, [data, dispatch,userpreference]);
  const redirectToOrders = ()=>{
  navigate("/Orderhistory")
  }

  const showPreferenceDialog = () => {
    setDialogVisible(true);
  };

  const hidePreferenceDialog = () => {
    setDialogVisible(false);
  };

  const handlePreferenceSelection = async (item) => {
    fetchExistingPreference({ token: userInfo.accessToken });
    let inputData = { 'category': item, 'token': userInfo.accessToken};
      if (userpreferenceList.includes(item)) {
        setSelectedPreferences(userpreferenceList.filter((selectedItem) => selectedItem !== item));
        await dispatch(deletePreference(inputData))
        fetchExistingPreference({ token: userInfo.accessToken });
        // Item to be removed
      } else {
        setSelectedPreferences([...userpreferenceList, item]);
        console.log("Item will added to preference")
        await dispatch(storeUserPreference(inputData));
        fetchExistingPreference({ token: userInfo.accessToken });
      }
  };


  return (
        <Navbar.Collapse className="justify-content-end">
          {userInfo ? (
            <>
              <div className="account-icon-container">
              <Avatar
                icon="pi pi-user"
                size="large"
                shape="circle"
                style={{ backgroundColor: 'rgba(0, 65, 100, 1)', color: '#ffffff' }}
                onClick={(e) => op.current.toggle(e)}
              />
              </div>
              <OverlayPanel ref={op} className="account-overlay">
                <div className="account-options">
                <div className="account-option">
                    Hi {userInfo.username}, Your Account
                  </div>
                  <Divider className="profile-divider"/>
                  <div className="account-option" onClick={redirectToOrders}>
                    My Orders
                  </div>
                  <Divider className="profile-divider"/>
                  <div className="account-option" onClick={showPreferenceDialog}>
                   My Preferences
                  </div>
                  <Divider className="profile-divider"/>
                  <div className="account-option" onClick={redirectToFavorites}>
                    My Favourites
                  </div>
                  <Divider className="profile-divider"/>
                  <div className="account-option" onClick={handleLogout}>
                    Logout
                  </div>
                </div>
              </OverlayPanel>
            </>
          ) : (
            <NavLink className="nav-link" to="/login">
              <Avatar icon="pi pi-user" size="large" shape="circle" />
            </NavLink>
          )}
          <Dialog visible={visiblePreference} onHide={hidePreferenceDialog} header="Preference" className="preference-dialog">
            <p>{preferenceList? <>Please select your preferences:</>:<>Unexpected Error!</> }</p>
            <div className="preference-buttons">
            {preferenceList ? (
                preferenceList.map((item) => (
                  <Button
                    key={item}
                    label={item}
                    className={classNames('p-button-rounded p-button-outlined p-button-sm', {
                      'p-button-secondary': !userpreferenceList || !userpreferenceList.includes(item),
                      'p-button-primary': userpreferenceList && userpreferenceList.includes(item),
                    })}
                    onClick={() => handlePreferenceSelection(item)}
                  />
                ))
              ) : (
                <></>
              )}
            </div>
          </Dialog>
        </Navbar.Collapse>
  );
};

const mapStateToProps = (state) => {
  return {
    resetnewArrivals: arrivalActions.resetnewArrivals,
    resetservicesAndOffersTerminal: servicesAndOffersTerminalSliceAction.resetservicesAndOffersTerminal,
    fetchPreference: preferenceActions.fetchPreference,
    userpreference: state.preference.userpreference,
    recommendedCategories: state.recommendedCategories.recommendedCategories,
  };
};

const mapDispatchToProps = {
  fetchPreference, // Add fetchPreference to mapDispatchToProps
  fetchExistingPreference: preferenceActions.fetchExistingPreference,
  fetchRecommendedCategories: recommendedCategoriesActions.fetchRecommendedCategories,
};

export default connect(mapStateToProps, mapDispatchToProps)(Account);