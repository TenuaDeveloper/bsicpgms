import Container from 'react-bootstrap/Container';
import { useNavigate } from 'react-router-dom';
import { useSelector ,useDispatch} from 'react-redux';
import Navbar from 'react-bootstrap/Navbar';
import cartimg from "../images/Vector.png"
import { useCallback, useState } from 'react';
import './styles.css';
import { getTotalCartCount,totTalPrice } from "../../../redux/features/cart/selector"
import Hovercart from '../cartitems/Hovercart';
import crtimg from './cart_img.jpg';
import {useLocation} from 'react-router-dom';
import {getItemInCartAPI} from "../../../redux/features/cart/cartAction"
import { useEffect } from 'react';


const Cart = ()=> {
  const { userInfo } = useSelector((state) => state.auth);
   const dispatch = useDispatch()
    useEffect(() => {
      if (userInfo?.accessToken) {
        dispatch(getItemInCartAPI({token: userInfo?.accessToken}))
      }
      
    }, [])
  let location = useLocation();
  const cartCount = getTotalCartCount()
  const totalCartValue = totTalPrice
  const prdData =  useSelector(state => state.cart.cart);
  const cart = useSelector(state => state.cart);
  // console.log("Product Data in Cart ======>",cart)
  const navigate = useNavigate();

  const data = Object.entries(prdData).map(item=>Object.values(item[1])).flat(2)
  //let totalPrice = 0;
  // console.log("Total Cart Valuation +++++====>",totalCartValue,data)
  return (
    <Navbar>
      <Container  onClick={()=> navigate('/cart')}>
      <Container>
      </Container>
        <Navbar.Collapse className="justify-content-end hoverClass">
          <Navbar.Text>
             <img className='imgDimension' src={cartimg} alt=""  />
             {
               cartCount?<span>
                 <span className='total-cart'>{cartCount}</span>
                 </span>:''
             }
          </Navbar.Text>
          { location.pathname !== '/cart' && location.pathname != '/jurneyplan'&& 
          location.pathname != '/wishlist' && location.pathname != '/signup' &&
          cartCount?<div className='hove scrollbar-width-none'>
            
            {  data.map((item) => {
                    //console.log("abcd=>",item)
                    // totalPrice = totalPrice + (item.unitPrice * item.unitAdded)
                   let qty = item.quantity === undefined ? item.unitAdded : item.quantity
                    return(<>
                    
                    <div >
                      <div>
                        <img src={item.images[0]} className='hovImage' alt="" />
                      </div>
                      <div >
                        <p className='title-txt-hov fs-6'>{item.name} </p>
                      </div>
                      <div className="d-flex w-25">
                        <div >
                          <p className='prd-price-hov fs-6'>Qty : {qty}</p>
                        </div>
                        <div >
                          <p className='prd-price-hov fs-6'>$ : {item.unitPrice * (qty)}</p>
                        </div></div>
                    </div>
                    <hr className='hrizontal-line' />
                    <div >
                      </div>
                      
      
                    </>)
                  })
                }
                  <div className='row'>
                      <p className=' total-txt-hov fs-6 '>Total : $ {totalCartValue}</p>
                    </div>
                              </div>:''
          }
                    
        </Navbar.Collapse>
      </Container>
      
    </Navbar>
  );
}

export default Cart;
