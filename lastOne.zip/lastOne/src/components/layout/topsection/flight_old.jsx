import { Container } from 'react-bootstrap';
import React, { useState, useEffect } from 'react';
import Nav from 'react-bootstrap/Nav';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPlaneDeparture, faCar, faLightbulb } from '@fortawesome/free-solid-svg-icons';
import { Dropdown } from 'primereact/dropdown';
import './styles.css'
import { Menu } from 'primereact/menu';
import 'primereact/resources/themes/saga-blue/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import icon_1 from '../images/icon_1.svg'
import icon_3 from '../images/icon_3.svg'
import icon_2 from '../images/icon_2.svg'
import Popup from '../../popup/popup'
import options from './data.js'
import inspOptions from './insp_data.js'
import { useNavigate } from 'react-router-dom'
import { Typeahead } from 'react-bootstrap-typeahead';
import 'react-bootstrap-typeahead/css/Typeahead.css';
import { connect } from 'react-redux';
import { useDispatch, useSelector } from 'react-redux'
import { addFlight, deleteFlight, selectPinFlights, unSelectPinFlights } from '../../../redux/features/pingFlight/pingflightSlice'
import { addInspiration, deleteInspiration, selectInspiration, unSelectInspiration } from '../../../redux/features/pinInspiration/pinInspirationSlice'
import { addPickupDrop, deletePickupDrop, editPickupDrop, selectPinPickupDrop, unSelectPinPickupDrop } from '../../../redux/features/pinPickupDrop/pinPickupDropSlice'
import { terminalListActions } from '../../../redux/features/pinPickupDrop/terminalListSlice'
import {useLocation} from 'react-router-dom';
import { locationActions } from '../../../redux/features/pinInspiration/locationListSlice';
import { flightActions } from '../../../redux/features/pingFlight/flightListSlice';
import {removeCartItemByPin, moveCartItemByPin} from '../../../redux/features/cart/cartslice';
import {selectServices} from '../../../redux/features/common/commonSlice';
import DeletePinConfirmation from '../../popup/deletePinConfirmation';
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { addPinFlight, addPinInspiration, deletePinFlight, deletePinInspiration, addPinPickupDrop, deletePinPickupDrop, getPinFlight, getPinPickupDrop, getPinInspiration } from '../../../redux/features/pingFlight/pinAction';
import { deleteAllItemInCartAPI, getItemInCartAPI, moveAllItemToUncategorizedCartAPI } from '../../../redux/features/cart/cartAction';
import { DropdownButton } from "react-bootstrap";
import { useRef } from 'react';
import DebouncedDropdown from '../../../redux/features/pingFlight/DebouncedDropdown';
import { addMessage } from "../../../redux/features/Notification/messagesSlice";
import  { servicesAndOffersTerminalSliceAction } from '../../../redux/features/terminal/selectedTerminalSlice';
import {selectedTerminalValue} from '../../../redux/features/terminal/selectedTerminal';
import flighticon from '../images/plane.svg'

const Flight = ({locations, flights, fetchLocations, fetchFlights, terminals, setFlightValue, setDropdownValue, setInspirationValue, userInfo}) => {
    let location = useLocation();
    const[isFlightPlan, SetIsFlightPlan] =useState(false);
    const[isInspPlan, SetIsInspPlan] =useState(false);
    const[isPickupPlan, SetIsPickupPlan] =useState(false);
    const navigate = useNavigate();
    // const [option, handleSelectOption] = useState('flight');
    const [flightDate, setFlightDate] = useState('');
    const [pickupDate, setPickupDate] = useState('');
    const [inspirationDate, setInspirationDate] = useState('');
    const [flightData, setFlightData] = useState([]);
    const [locationData, setLocationData] = useState([]);
    const [data, setData] = useState([]);
    const [selectedFlight, setSelectedFlight] = useState({});
    const[showAlert, setShowAlert] =useState(false);
    const dispatch = useDispatch()
    const [itemType, setItemType] = useState(null);
    const [itemKey, setItemKey] = useState(null);
    const [id, setId] = useState(null);
    const [basicSelected, setBasicSelected] = useState([]);
    const [selected, setSelected] = useState([]);
    const { flightList, flightError } = useSelector((state) => state.flight)
    const { inspirationList, inspirationError } = useSelector((state) => state.inspiration)
    const { pickupDropList, pickupError } = useSelector((state) => state.pickupDrop)
    const cart  = useSelector((state) => state.cart)
    const option = useSelector(state => state.common.option)
    const flightDataRed = useSelector(state => state.flights.flights)
    const locationDataRead = useSelector(state => state.locations.locations)
    const flightInCart = useSelector(state => state.cart.cart.flight);
    const pickupInCart = useSelector(state => state.cart.cart.pickupDrop);
    const inspirationInCart = useSelector(state => state.cart.cart.inspiration);
    
    const [terminalData, setTerminalData] = useState([]);
    const terminalDataRed = useSelector(state => state.terminallist.terminallist);
    const [selectedTerminal, setSelectedTerminal] = useState({});

    
    const [isActiveFlight, setIsActiveFlight] = useState(false);
    const [isActivePickup, setIsActivePickup] = useState(false);
    const [isActiveInspiration, setIsActiveInspiration] = useState(false);
    const [flightterminal, setflightTerminal] = useState("");
    const [pinnedFlightSelected, setpinnedFlightSelected]= useState(false)
    const [terminaltitle, setTerminalTitle] = useState("Choose a Terminal...")
    const [ prevItem, setPrevItem] = useState(null)
    const menu = useRef(null);
    const [selectedOption, setSelectedOption] = useState('flight');
    const [messages, setMessages] = useState([]);

    useEffect(() => {
        setFlightData(flightDataRed);
        setLocationData(locationDataRead)
        setTerminalData(terminalDataRed);
        if (userInfo){
            dispatch(getItemInCartAPI({token: userInfo?.accessToken}))
          }
    }, [flightDataRed,locationDataRead,userInfo,dispatch, terminalDataRed])

    useEffect(() => {
        const selectedFlight = flightList.find(item => item.selected === true);
        if (selectedFlight) {
          setflightTerminal(selectedFlight.terminal);
          setpinnedFlightSelected(true);
        } else {
          setpinnedFlightSelected(false);
        }
      }, [flightList]);
      

    const checkActiveFlight = () => {
        const activeFlight = flightList.find((item) => item.active);
        return !!activeFlight;
    };

    const checkActivePickupDrop = () => {
        const activePickupDrop = pickupDropList.find((item) => item.active);
        return !!activePickupDrop;
    };

    const checkActiveInspiration = () => {
        const activeInspiration = inspirationList.find((item) => item.active);
        return !!activeInspiration;
    };

    const handleAddFlight = async (e) => {
        if (!flightDate) {
            toast.error("Please select a date", {
            position: toast.POSITION.TOP_CENTER
          });
            return;
        }
        
        let inputData = { 'flightNo': e.value.flightNo, "scheduleDate":e.value.scheduleDate, "time":e.value.scheduleTime, "source": e.value.source,"destination": e.value.destination,"terminal": e.value.terminal,"gate": e.value.gate, "flightId": e.value.id ,"flightDepartArrivalStatus": e.value.flightDepartArrivalStatus,"flightType":e.value.flightType,"zone":e.value.zone, "boardingTime":e.value.boardingTime };
        if(flightList.length > 0 && flightList.some(item => item.flightNo === e.value.flightNo && item.scheduleDate === e.value.scheduleDate && item.time === e.value.scheduleTime) ){
            toast.error("Selected flight is already pinned", {
                position: toast.POSITION.TOP_CENTER
              });
        }
        else{
            setShowAlert(true)
            if(location.pathname === '/jurneyplan'){
                SetIsFlightPlan(true);
            }
            if(userInfo){
                await dispatch(addPinFlight(inputData));
                dispatch(getPinFlight({token: userInfo?.accessToken}))
            }
            dispatch(addFlight(inputData));
        }
        setMessages((messages) => [
            ...messages,
            {
              message: `You have pinned flight ${e.value.flightNo}. We will send you updates about this flight.`,
              timestamp: new Date().toISOString(),
            },
          ]);
          dispatch(
            addMessage({
              message: `You have pinned flight ${e.value.flightNo}. We will send you updates about this flight.`,
              timestamp: new Date().toISOString(),
              imageIconUrl: flighticon,
            })
          );

    }

    const handleAddPickupDrop = async (e) => {
        if (!pickupDate) {
            toast.error("Please select a date", {
            position: toast.POSITION.TOP_CENTER
          });
            return;
        }
        // console.log(e, "selected", selected,"pickupDropList",pickupDropList)
        let data = { "terminal": e.value.label, "scheduleDate":pickupDate, "time":"02:50:45", "terminalName":e.value.label }
        if(pickupDropList.length > 0 && pickupDropList.includes(e.terminal)){
            toast.error("Selected pickup/drop is already pinned", {
                position: toast.POSITION.TOP_CENTER
              });
        }
        else {
            dispatch(addPickupDrop(data));
            // setShowAlert(true)
            if(location.pathname === '/jurneyplan'){
                SetIsPickupPlan(true);
            }
            if(userInfo){
                await dispatch(addPinPickupDrop(data));
                dispatch(getPinPickupDrop({token: userInfo?.accessToken}))
            }
        }
        // dispatch(cartError())
    }
    
    const handleAddInspiration = async (e) => {
        if (!inspirationDate) {
            toast.error("Please select a month", {
            position: toast.POSITION.TOP_CENTER
          });
            return;
        }
        // console.log(e, "selected", selected)
        let locList = e.value.split(", ")
		let data = { "place": e.value,"location": locList[0], scheduleMonth: inspirationDate }
        let inputData = { "place": e.value, 'location': locList[0], "scheduleMonth":inspirationDate };
        if(inspirationList.length > 0 && inspirationList.some(item => item.place === e.value && item.location === locList[0] && item.scheduleMonth === inspirationDate) ){
            toast.error("Selected location is already pinned", {
                position: toast.POSITION.TOP_CENTER
              });
        }
        else{
            dispatch(addInspiration(data));
            // setShowAlert(true)
            if(location.pathname === '/jurneyplan'){
                SetIsInspPlan(true);
            }
            if(userInfo){
                await dispatch(addPinInspiration(inputData));
                dispatch(getPinInspiration({token: userInfo?.accessToken}))
            }
        }
    }
    
    const handleFetchLocationByDate = (date) => {
        dispatch(locationActions.fetchLocations(date));
        setLocationData(locations);
      }
    const  handleFetchFlightByDate = (date) => {
        dispatch(flightActions.fetchFlights(date))
      }

    const handleMove = (itemIndex,itemKey,type,details) => {
        let data = { "id": details }
        if(option ==='flight'){
            dispatch(deleteFlight(data));
            if(userInfo){
                dispatch(deletePinFlight(itemKey));
                const flight = flightList.find(ele => ele.flightNo === itemKey);
                const flightId = flight.flightId;
                const cartPayload = {
                  "flightId": flightId,
                  "location": "",
                  "flightType": type,
                  "terminal": 0,
                  "token": userInfo.accessToken
                }
                dispatch(moveAllItemToUncategorizedCartAPI(cartPayload));
            }
        }
        else if(option === 'pickupDrop'){
            dispatch(deletePickupDrop(data));
			if(userInfo){
                dispatch(deletePinPickupDrop(itemKey));
                const pickup = pickupDropList.find(ele => ele.terminal === itemKey);
                const terminal = pickup.terminal;
                const cartPayload = {
                  "flightId": 0,
                  "location": "",
                  "flightType": type,
                  "terminal": terminal,
                  "token": userInfo.accessToken
                }
                dispatch(moveAllItemToUncategorizedCartAPI(cartPayload));
            }
        }
        else if(option === 'inspiration'){
            dispatch(deleteInspiration(data));
            if(userInfo){
                dispatch(deletePinInspiration(itemKey));
                const location = itemKey;
                const cartPayload = {
                    "flightId": 0,
                    "location": location,
                    "flightType": type,
                    "terminal": 0,
                    "token": userInfo.accessToken
                }
                dispatch(moveAllItemToUncategorizedCartAPI(cartPayload));
			}
        }
        dispatch(moveCartItemByPin({itemKey,type}))
        dispatch(removeCartItemByPin({itemKey,type}))
        setDisplayConfirmationModal(false);
    }
	
    const handleDelete = (itemIndex,itemKey,type,details) => {
        let data = { "id": details }
        if(option ==='flight'){
            if(userInfo){
                const flight = flightList.find(ele => ele.flightNo === itemKey);
                const flightId = flight.flightId;
                dispatch(deletePinFlight(itemKey));
                const cartPayload = {
                  "flightId": flightId,
                  "location": "",
                  "flightType": type,
                  "terminal": 0,
                  "token": userInfo.accessToken
                }
                dispatch(deleteAllItemInCartAPI(cartPayload));
            }
            dispatch(deleteFlight(data));
        }
        else if(option === 'pickupDrop'){
			if(userInfo){
                console.log("itemKey************"+itemKey);
                const pickup = pickupDropList.find(ele => ele.terminal === itemKey);
                const terminal = pickup.terminal;
                dispatch(deletePinPickupDrop(itemKey));
                const cartPayload = {
                  "flightId": 0,
                  "location": "",
                  "flightType": type,
                  "terminal": terminal,
                  "token": userInfo.accessToken
                }
                dispatch(deleteAllItemInCartAPI(cartPayload));
            }
            dispatch(deletePickupDrop(data));
        }
        else if(option === 'inspiration'){
            if(userInfo){
                dispatch(deletePinInspiration(itemKey));
                // const insp = inspirationList.find(ele => ele.location === itemKey);
                const location = itemKey;
                const cartPayload = {
                    "flightId": 0,
                    "location": location,
                    "flightType": type,
                    "terminal": 0,
                    "token": userInfo.accessToken
                }
                dispatch(deleteAllItemInCartAPI(cartPayload));
			}
            dispatch(deleteInspiration(data));
        }
        dispatch(removeCartItemByPin({itemKey,type}))
        setDisplayConfirmationModal(false);
    }
	
    const handleSelectFlight = (item, index) => {
        // Check if the index is provided
        if (index !== undefined) {
          // Make a copy of the flightList array
          const updatedFlightList = [...flightList];
          // Remove the selected flight from the current position
          const selectedFlight = updatedFlightList.splice(index, 1)[0];
          // Insert the selected flight at the front of the flightList array
          dispatch(addFlight(selectedFlight));
        }
      
        if (!item.selected) {
            dispatch(selectPinFlights({ id: item.id }));
            // console.log("setting flight pinned inside flight page ==>",item.terminal)
            setFlightValue(item.terminal);
        } else {
            dispatch(unSelectPinFlights({ id: item.id }));
            // console.log("setting inside flight page ==> empty")
            setFlightValue(null);
        }
      
        if (location.pathname === "/jurneyplan" && isFlightPlan && !flightInCart[item.flightNo]) {
          navigate("/");
        }
      };
         

    const handleSelectPickupDrop = (item) => {
        if (!item.selected) {
            dispatch(selectPinPickupDrop({id: item.id}))
            // console.log("setting pickupdrop pinned inside flight page ==>",item.terminal)
            setFlightValue(item.terminal);
        }else {
            dispatch(unSelectPinPickupDrop({id: item.id}))
            // console.log("setting pickupdrop pinned inside flight page ==> empty")
            setFlightValue(null);
        }
        if(location.pathname === '/jurneyplan' && isPickupPlan && !pickupInCart[item.flightNo]){
            navigate("/");
        }
    }
	
    const handleSelectInspiration = (item) => {
        if (!item.selected) {
            dispatch(selectInspiration({id: item.id}))
        } else {
            dispatch(unSelectInspiration({id: item.id}))
        }
        if(location.pathname === '/jurneyplan' && isInspPlan && !inspirationInCart[item.location]){
            navigate("/");
        }        
    }
    const handleFlightSearch = (input) => {
        if (input !== '') {
            setFlightData(flights.filter((flight) => {
                return flight.flightNo.search(`/${input}/`)
                    || flight.destination.search(`/${input}/`)
                    || flight.source.search(`/${input}/`);
            })
            );
        } else {
            setFlightData([]);
        }
    }

    const handleLocationSearch = (input) => {
        if (input !== '') {
            setLocationData(locations.filter((location) => {
                return location.search(`/${input}/`);
            })
            );
        } else {
        }
    }

    const [displayConfirmationModal, setDisplayConfirmationModal] = useState(false);
    const [deleteMessage, setDeleteMessage] = useState(null);
    const showDeleteModal = (type, details,itemKey) => {
        setId(details)
        setItemKey(itemKey)
        if (type === "flight") {
          setDeleteMessage("Are you sure you want to delete the flight ");
        } else if (type === "pickupDrop") {
          setDeleteMessage("Are you sure you want to delete the pickup/drop ");
        } else if (type === "inspiration") {
          setDeleteMessage("Are you sure you want to delete the destination ");
        }
     
        setDisplayConfirmationModal(true);
      };

      const clearAll = async (item) => {
        flights.forEach(async (flight) => {
          let data = flight.flightNo 
          let data1=flight.flightType
          dispatch(removeCartItemByPin({data,data1}));
        });
      };
      
     
      // Hide the modal
      const hideConfirmationModal = () => {
        setDisplayConfirmationModal(false);
      };

    const getSelectedClass = (selected) => selected ?"selected-pinned-flight":"";

    const handleSelectOption = (str) => {
        // somethig
        dispatch(selectServices({option:str}))
        setSelectedOption(str);
    }

    const handleSelectedFlight = (item) =>{
        setPrevItem(item.flightNo)
        if (!pinnedFlightSelected || prevItem !== item.flightNo){
            // dispatch(servicesAndOffersTerminalSliceAction.fetchServicesAndOffersTerminal(item.terminal))
            dispatch(selectedTerminalValue({option: item.terminal}))
            setTerminalTitle(item.terminal ? "Terminal "+item.terminal : "Choose a Terminal")
            // console.log("onclick select terminal")
        } else {
            dispatch(selectedTerminalValue({option: ""}));
            setTerminalTitle("Choose a Terminal")
            // console.log("onclick select terminal-restet")
        }

    }

    const handleSelectTerminal = (key, event) => {
        setSelectedTerminal({ key, value: event.target.value });
        if(key !== "") {
            // console.log("Terminal Data ===========>",terminalData)
            const selectedTerminalNo = terminalData.find(item=> item.terminalName == key);
            // dispatch(servicesAndOffersTerminalSliceAction.fetchServicesAndOffersTerminal(selectedTerminalNo.terminalNumber))
            dispatch(selectedTerminalValue({option: selectedTerminalNo ? selectedTerminalNo.terminalNumber : ""}))
            setTerminalTitle(selectedTerminalNo ? "Terminal "+selectedTerminalNo.terminalNumber : "Choose a Terminal")
        } else {
            dispatch(selectedTerminalValue({option: ""}));
            setTerminalTitle("Choose a Terminal")
        }   
    };

    const getTerminalbyDate = (date) => {
        dispatch(terminalListActions.fetchPickDropTerminalData(date))
          .then((res) => {
            // console.log("Response from API:", res.payload);
            setTerminalData(res.payload);
          })
          .catch((error) => {
            console.error("Error fetching terminal data:", error);
          });
      };

    return (
        <div className='container-s'>
            <Nav as="ul" className='leftFlight w-auto p-3' >
            
                <Nav className="itemBox" >
                    <Nav.Item as="li" >
                        <div className="pinned-flight-font-heading">Find</div>
                    </Nav.Item>

                    <Nav.Item as="li" className={`icon-container ${selectedOption === 'flight' ? 'active' : ''}`} onClick={() => handleSelectOption('flight')} data-count={flightList.length}>
                        <Nav.Link>
                            <img src={icon_1} width="40px" height="25px" className='align-inherit' style={{ marginLeft: "6px", marginTop: "10px" }} onMouseOver={(e) => {e.currentTarget.style.filter = "invert(1)"}} onMouseOut={(e) => {e.currentTarget.style.filter = "none"}} />
                            <div className='text'></div>
                        </Nav.Link>
                    </Nav.Item>


                    <Nav.Item as="li" className={`icon-container ${selectedOption === 'pickupDrop' ? 'active' : ''}`} onClick={() => handleSelectOption('pickupDrop')} data-count={pickupDropList.length}>
                        <Nav.Link>
                        <img src={icon_2} width="35px" height="20px" style={{ marginLeft: "6px", marginTop: "10px" }} className='align-inherit' onClick={() => handleSelectOption('pickupDrop')} onMouseOver={(e) => {e.currentTarget.style.filter = "invert(1)"}} onMouseOut={(e) => {e.currentTarget.style.filter = "none"}} />
                        <div className='text'></div>{(selectedOption === 'pickupDrop') && <div style={{ "width": "50px" }}></div>}
                        </Nav.Link>
                    </Nav.Item>

                    <Nav.Item as="li" className={`icon-container ${selectedOption === 'inspiration' ? 'active' : ''}`} onClick={() => handleSelectOption('inspiration')} data-count={inspirationList.length}>
                        <Nav.Link>
                        <img src={icon_3} width="35px" height="20px" style={{ marginLeft: "6px", marginTop: "10px" }} className='align-inherit' onClick={() => handleSelectOption('inspiration')} onMouseOver={(e) => {e.currentTarget.style.filter = "invert(1)"}} onMouseOut={(e) => {e.currentTarget.style.filter = "none"}} />
                        <div className='text'></div>{(selectedOption === 'inspiration') && <div style={{ "width": "50px" }}></div>}
                        </Nav.Link>
                    </Nav.Item>`
                    
                    {cart.error?.type === "pin-flight" &&<span>{cart.error.msg}</span>}
                    {option === 'flight' &&  <div id="textbox" className="textbox">
                        <div id="description" className="pinned-flight-font">
                            Date</div>
                        <div id="frame72" >
                            <input className="frame72" type="date" min={new Date().toISOString().split("T")[0]}  
                            onChange={async (e) => { 
                                const selectedDate = e.target.value;
                                if (selectedDate === "") {
                                    setFlightDate(''); // or set it to an initial value
                                  } 
                                else {
                                    const [year, month, day] = selectedDate.split('-');
                                    const formattedDate = `${day}-${month}-${year}`;
                                    await handleFetchFlightByDate(formattedDate);
                                    setFlightDate(formattedDate);
                                }
                            }} />
                        </div>
                    </div>}
                    {option === 'flight' && 
                    <div id="textbox" className="textbox2">
                        <div id="description2" className="pinned-flight-font" style={{ "marginLeft": '10px' }}>
                            Flight</div>
                        <div id="rectangle75" >

                        <Dropdown
                            id="basic-example"
                            value={selected}
                            options={flightData}
                            onChange={handleAddFlight}
                            filter={true}
                            filterPlaceholder="Search"
                            filterBy="label" // change this to the name of the field you want to filter by
                            placeholder="Choose a flight..."
                            minLength={1}
                            style={{ border: 'none' }}
                            scrollHeight="200px"
                        />
                        <ToastContainer />

                        </div>  
                    </div>}
                    {/* Terminal position has to be changed */}
                    {/* {option === 'flight' && <div id="textbox1" className="textbox4">
                        <div id="description2" className="description" style={{ "marginLeft": '10px', left: '700px' }}>
                            Terminal</div>
                        <div id="rectangle75" >

                        <DropdownButton
                            id="dropdown-basic-button"
                            variant="info"
                            className="btn-info"
                            style={{ left: '700px' }}
                            onSelect={handleSelectTerminal}
                            title={terminaltitle}
                        >
                            <Dropdown.Item key="" eventKey="">{"Choose a Terminal..."}</Dropdown.Item>
                            {terminalData.map((item, idx) =>
                                    <Dropdown.Item key={idx} eventKey={item.terminalName}>{item.terminalName}</Dropdown.Item>
                            )}
                        </DropdownButton>
                        </div>  
                    </div>} */}
                    {option === 'pickupDrop' &&  <div id="textbox" className="textbox">
                        <div id="description" className="pinned-flight-font">
                            Date</div>
                        <div id="frame72" >
                            <input className="frame72" type="date" min={new Date().toISOString().split("T")[0]}
                            onChange={async (e) => { 
                                const selectedDate = e.target.value;
                                if (selectedDate === "") {
                                    setPickupDate(''); // or set it to an initial value
                                  } 
                                else {
                                    const [year, month, day] = selectedDate.split('-');
                                    const formattedDate = `${day}-${month}-${year}`;
                                    await getTerminalbyDate(formattedDate);
                                    setPickupDate(formattedDate);
                                }
                            }} />
                        </div>
                    </div>}
                    {option === 'pickupDrop' && <div id="textbox" className="textbox2">
                        <div id="description2" className="pinned-flight-font" style={{ "marginLeft": '10px' }}>
                            Terminal</div>
                        <div id="rectangle75" >

                        <Dropdown
                            value={selected}
                            options={terminalData}
                            onChange={handleAddPickupDrop}
                            placeholder="Choose a Terminal..."
                            id="basic-example"
                            filter={true}
                            filterPlaceholder="Search"
                            minLength={1}
                            style={{ border: 'none' }}
                            scrollHeight="200px"
                            />
                            <ToastContainer />

                        </div>
                    </div>}
                    {/* Terminal position has to be changed */}
                    {/* {option === 'pickupDrop' && <div id="textbox1" className="textbox4">
                        <div id="description2" className="description" style={{ "marginLeft": '10px', left: '700px' }}>
                            Terminal</div>
                        <div id="rectangle75" >

                        <DropdownButton
                            id="dropdown-basic-button"
                            variant="info"
                            className="btn-info"
                            onSelect={handleSelectTerminal}
                            style={{ left: '700px' }}
                            title={terminaltitle}
                        >
                            <Dropdown.Item key="" eventKey="">{"Choose a Terminal..."}</Dropdown.Item>
                            {terminalData.map((item, idx) =>
                                    <Dropdown.Item key={idx} eventKey={item.terminalName}>{item.terminalName}</Dropdown.Item>
                            )}
                        </DropdownButton>
                        </div>  
                    </div>} */}
                    {option === 'inspiration' && <div id="textbox" className="textbox">
                            <div id="description" className="pinned-flight-font">
                                Date</div>
                            <div id="frame72" htmlFor="monthInput">
                                <input id="monthInput" 
                                className="frame72" 
                                type="month" 
                                min={new Date().toISOString().slice(0, 7)} 
                                onChange={async (e) => { 
                                    const targetdate = e.target.value;
                                    if (targetdate === "") {
                                        setInspirationDate(''); // or set it to an initial value
                                      } 
                                    else {
                                        const [year, month] = targetdate.split('-');
                                        const monthName = new Date(`${month}-01-01`).toLocaleString('default', { month: 'short' });
                                        const formattedDate = `${monthName}-${year}`;
                                        await handleFetchLocationByDate(formattedDate)
                                        setInspirationDate(formattedDate);
                                    }
                                }}/>
                            </div>
                        </div> }
                    {option === 'inspiration' && <div id="textbox" className="textbox2">
                        <div id="description2" className="pinned-flight-font" style={{ "marginLeft": '10px' }}>
                            Location</div>
                        <div id="rectangle75" >
                            <Dropdown
                                id="basic-example"
                                value={selected}
                                options={locationData}
                                onChange={handleAddInspiration}
                                onKeyUp={handleLocationSearch}
                                filter={true}
                                filterPlaceholder="Search locations"
                                placeholder="Choose a Location..."
                                style={{ border: 'none' }}
                                scrollHeight="200px"
                                />
                                <ToastContainer />
                        </div>
                    </div>}
                    { showAlert && <Popup showPopup={setShowAlert} /> }
                    
                    {option === 'flight' && (
                    <div id="textbox" className="frame67 row pinned1-frame">
                        {flightList.length > 0 && checkActiveFlight() && (
                        <span className="pinned1-text">Saved Flights</span>
                        )}

                        {flightList.slice(0, 3).map((item, index) =>
                        item.active ? (
                            <div
                            id="frame56"
                            key={index}
                            className={`frame56 col-4 ${getSelectedClass(item.selected)}`}
                            onClick={() => handleSelectFlight(item)}
                            >
                            <div
                                id=""
                                className="e234|12-10-2023 "
                                onClick={() => handleSelectedFlight(item)}
                            >
                                {item.flightNo} | {item.scheduleDate} : {item.time.substr(0, 5)}
                            </div>
                            <img
                                alt="del"
                                id="ic:baseline-remove-circle"
                                className="ic:baseline-remove-circle"
                                onClick={() => showDeleteModal(option, item.id, item.flightNo)}
                                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAQCAYAAADJViUEAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAEbSURBVHgBrZLNUcMwEIXfyppccQEeRh3gEpKrh0M6SOgAKiBUwFABKSEHxtdAB6YDwZi7z0HWIv9gROJknEnebbXv09PuCDhBtK+h1FTBGAW2hf5Ks0HwZZTcM9EtmEPPpYmx/MzTh17YJYXGbNbuIMYeMZBJOZpovSqqWvw2yvL78RDYJsWl2Tx7NRBF12OCXWOgAoiJzl9eRRNvpzhCpvVL1LPQVT1R85YlLN52CMFjMM0aC1QTWldUwJ+sV4I9z0WXTGw/ug7z3PHzHZb/WAa/d8kWYoUjJFt/Deducy5t2AVuJ9WmO7hSEIxuCJQd5pA5351X/1cUJQtBmLkRVWdyC7XMT3meLrYu65dSSWyMCKWU2n1HjXPrB9kYYaOEs/QMAAAAAElFTkSuQmCC"
                            />
                            </div>
                        ) : null
                        )}

                        {flightList.length > 3 && (
                        <div className="dropdown frame51 col-6" id="frame56">
                        <Menu
                            model={flightList.slice(3).map((item, index) => ({
                                label: `${item.flightNo} | ${item.scheduleDate} : ${item.time.substr(0, 5)}`,
                                command: () => {
                                  handleSelectFlight(item, index + 3); // Add 3 to the index to account for the items before the slice
                                },
                              }))}                              
                            popup
                            ref={menu}
                            id="popup_menu"
                            className="custom-menu"
                            />
                            <button
                                className="frame51 dropdown-toggle col-6"
                                type="button"
                                id="dropdownMenuButton"
                                aria-haspopup="true"
                                aria-expanded="false"
                                onClick={(event) => menu.current.toggle(event)}
                                >
                            ...
                            </button>
                            <div className="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            {flightList.slice(3).map((item, index) =>
                                item.active ? (
                                <a
                                    key={index}
                                    className={`dropdown-item ${getSelectedClass(item.selected)}`}
                                    onClick={() => handleSelectFlight(item)}
                                >
                                    </a>
                            ) : null
                        )}
                        </div>
                    </div>
                    )}
                    </div>
                    )}

					{/* {<h6 className="clear-button" onClick={() => {clearAll(flightList)}}>
                                    Clear All
                            </h6>} */}
                    { showAlert && <Popup showPopup={setShowAlert} /> }
					{pickupDropList && option === 'pickupDrop' && <div id="textbox" className="frame67 row pinned1-frame">
                        {
                            pickupDropList.length > 0 && checkActivePickupDrop() && <span className='pinned1-text'>Pinned Pickup/Drop</span>
                        }

                        {(option === 'pickupDrop' && pickupDropList.length > 0 && location.pathname === '/') }

                        {pickupDropList.slice(0, 3).map((item, index) =>
                        item.active ? (
                            <div
                            id="frame56"
                            key={index}
                            className={`frame56 col-4 ${getSelectedClass(item.selected)}`}
                            onClick={() => handleSelectPickupDrop(item)}
                            >
                            <div id="" className="e234|12-10-2023 ">
                                {item.terminal} | {item.scheduleDate}
                            </div>
                            <img
                                id="ic:baseline-remove-circle"
                                className="ic:baseline-remove-circle"
                                onClick={() => showDeleteModal(option, item.id, item.terminal)}
                                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAQCAYAAADJViUEAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAEbSURBVHgBrZLNUcMwEIXfyppccQEeRh3gEpKrh0M6SOgAKiBUwFABKSEHxtdAB6YDwZi7z0HWIv9gROJknEnebbXv09PuCDhBtK+h1FTBGAW2hf5Ks0HwZZTcM9EtmEPPpYmx/MzTh17YJYXGbNbuIMYeMZBJOZpovSqqWvw2yvL78RDYJsWl2Tx7NRBF12OCXWOgAoiJzl9eRRNvpzhCpvVL1LPQVT1R85YlLN52CMFjMM0aC1QTWldUwJ+sV4I9z0WXTGw/ug7z3PHzHZb/WAa/d8kWYoUjJFt/Deducy5t2AVuJ9WmO7hSEIxuCJQd5pA5351X/1cUJQtBmLkRVWdyC7XMT3meLrYu65dSSWyMCKWU2n1HjXPrB9kYYaOEs/QMAAAAAElFTkSuQmCC"
                            />
                            </div>
                        ) : null
                        )}

                        {pickupDropList.length > 3 && (
                        <div className="dropdown frame51 col-6" id="frame56">
                            <Menu
                            model={pickupDropList.slice(3).map((item, index) => ({
                                label: `${item.terminal} | ${item.scheduleDate}`,
                                command: () => {
                                handleSelectPickupDrop(item, index + 3); // Add 3 to the index to account for the items before the slice
                                },
                            }))}
                            popup
                            ref={menu}
                            id="popup_menu"
                            className="custom-menu"
                            />
                            <button
                            className="frame51 dropdown-toggle col-6"
                            type="button"
                            id="dropdownMenuButton"
                            aria-haspopup="true"
                            aria-expanded="false"
                            onClick={(event) => menu.current.toggle(event)}
                            >
                            ...
                            </button>
                        </div>
                        )}
                    </div>}
					
                    { showAlert && <Popup showPopup={setShowAlert} /> }
                    {option === 'inspiration' && <div id="textbox" className="frame67 row pinned1-frame">
                        {
                            inspirationList.length > 0 && checkActiveInspiration() && <span className='pinned1-text'>Pinned Inspiration</span>
                        }
                        {inspirationList.slice(0, 3).map((item, index) =>
                        item.active ? (
                            <div
                            id="frame59"
                            key={index}
                            className={`frame59 col-4 ${getSelectedClass(item.selected)}`}
                            onClick={() => handleSelectInspiration(item)}
                            >
                            <div id="" className="e234|12-10-2023">
                                {item.location} | {item.scheduleMonth}
                            </div>
                            <img
                                id="ic:baseline-remove-circle"
                                className="ic:baseline-remove-circle"
                                onClick={() => showDeleteModal(option, item.id, item.location)}
                                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAQCAYAAADJViUEAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAEbSURBVHgBrZLNUcMwEIXfyppccQEeRh3gEpKrh0M6SOgAKiBUwFABKSEHxtdAB6YDwZi7z0HWIv9gROJknEnebbXv09PuCDhBtK+h1FTBGAW2hf5Ks0HwZZTcM9EtmEPPpYmx/MzTh17YJYXGbNbuIMYeMZBJOZpovSqqWvw2yvL78RDYJsWl2Tx7NRBF12OCXWOgAoiJzl9eRRNvpzhCpvVL1LPQVT1R85YlLN52CMFjMM0aC1QTWldUwJ+sV4I9z0WXTGw/ug7z3PHzHZb/WAa/d8kWYoUjJFt/Deducy5t2AVuJ9WmO7hSEIxuCJQd5pA5351X/1cUJQtBmLkRVWdyC7XMT3meLrYu65dSSWyMCKWU2n1HjXPrB9kYYaOEs/QMAAAAAElFTkSuQmCC"
                            />
                            </div>
                        ) : null
                        )}

                        {inspirationList.length > 3 && (
                        <div className="dropdown frame51 col-6" id="frame56">
                            <Menu
                            model={inspirationList.slice(3).map((item, index) => ({
                                label: `${item.location} | ${item.scheduleMonth}`,
                                command: () => {
                                handleSelectInspiration(item, index + 3); // Add 3 to the index to account for the items before the slice
                                },
                            }))}
                            popup
                            ref={menu}
                            id="popup_menu"
                            className="custom-menu"
                            />
                            <button
                            className="frame51 dropdown-toggle col-6"
                            type="button"
                            id="dropdownMenuButton"
                            aria-haspopup="true"
                            aria-expanded="false"
                            onClick={(event) => menu.current.toggle(event)}
                            >
                            ...
                            </button>
                        </div>
                        )}
                    </div>}

                </Nav>

                <DeletePinConfirmation showModal={displayConfirmationModal} confirmModal={handleDelete} onCancel={handleMove} hideModal={hideConfirmationModal} itemKey={itemKey} type={option} details={id} message={deleteMessage}  />
    
            </Nav>


        </div>

    );
}

const mapStateToProps = (state) => {
    return {
      locations: state.locations.locations,
      flights: state.flights.flights,
      terminals: state.terminals.terminals,
      userInfo: state.auth.userInfo,
    };
  };

export default connect(mapStateToProps)(Flight);
