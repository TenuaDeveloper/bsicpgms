import React from 'react';
import "./flight-ticket.scss";
import { useDispatch, useSelector } from 'react-redux';
import { useEffect, useState } from 'react'
import caartLogo from '../../../components/layout/images/flightcartlogo.png'

const FlightTicket = () => {
  const flightList = useSelector((state) => state.flight.flightList);
    const [isShow, setShow] = useState();
    const[ticketDetail,setTicketDetails] =useState()
    const dispatch = useDispatch();
  const findFlightDetails = useSelector((state)=>state.flight.flightList)
  // console.log("findFlightDetails",findFlightDetails)
  
  useEffect(() => {
    const flightSelected =  flightList.find((item) => item.selected)
    setTicketDetails(flightList?.filter((item) => item.selected))
    // setTicketDetails(findFlightDetails?.filter((item)=>item?.flightNo===flightSelected?.flightNo))
      if (flightSelected) {
        setShow(true)
      } else {
        setShow(false)
      }
      // console.log("ticketDetails",ticketDetail)
     },[flightList])
  
    if (!isShow) {
       return null;
    }
  return (
    <div className="flight-ticket">
      <div className="flight-ticket__shape"></div>
      <ul className='flight-ticket__details'>
        {
          ticketDetail?.map((item)=>
          {
            return (<>
              <li className="flight-ticket__carrier" key={item.id}>
          <img src={item.airlineLogo}  width={30} />
          <strong>{item.airline}</strong>
          </li>
        <li className="flight-ticket__loc">{item.source} - {item.destination}</li>
        <li className="flight-ticket__info"><label>Flight No</label><strong>{item.flightNo}</strong></li>
        <li className="flight-ticket__info"><label>Scheduled At</label><strong>{item.time.includes(':') ? item.time.split(':')[0] + ':' + item.time.split(':')[1] : item.time} {item.scheduleDate}</strong></li>
        <li className="flight-ticket__info"><strong>{item.flightDepartArrivalStatus}</strong></li>
        <li className="flight-ticket__info"><label>Status</label><strong>Scheduled</strong></li>
        <li className="flight-ticket__info"><label>Terminal</label><strong>{item.terminal}</strong></li>
        {item.flightDepartArrivalStatus === 'Departure'?
        <li className="flight-ticket__info"><label>Gate</label><strong>{item.gate?item.gate:'--'}</strong></li>
        :
        <li className="flight-ticket__info"><label>Baggage</label><strong>--</strong></li>
        }
        {item.flightDepartArrivalStatus === 'Departure'?
         <li className="flight-ticket__info"><label>Boarding Time</label><strong>{item.boardingTime ? item.boardingTime.replace(/(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):\d{2}/, '$4:$5 $3-$2-$1'):"--"}</strong></li>
        :
        null
        }  
       
        </>
            )
          }
          )
        }
      </ul>
      <div className="flight-ticket__shape flight-ticket__shape--right"></div>
    </div>
  );
};

export default FlightTicket;
