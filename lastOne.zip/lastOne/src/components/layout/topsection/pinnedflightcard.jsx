import React, { useEffect, useState } from 'react'
import flightcartlogo from 'assets/images/icons/flightcartlogo.png';
import flightdetailscard from 'assets/images/icons/flightdetailscard.svg'
import { useDispatch, useSelector } from 'react-redux';
import { flightActions } from 'redux/features/pingFlight/flightListSlice';

const Pinnedflightcard = () => {

  const { flightList, flightError } = useSelector((state) => state.flight);
  const [isShow, setShow] = useState();
  const dispatch = useDispatch();

  useEffect(() => {
    const flightSelected =  flightList.find((item) => item.selected)
    if (flightSelected) {
      dispatch(flightActions.fetchFlights()).then(res=> {
        setShow(true)
      }).catch(err=> {
      })
    } else {
      setShow(false)
    }
    
  },[flightList])

  if (!isShow) {
    return null;
  }
  
  return (

    <div>
      <div style={{
        backgroundImage: `url(${flightdetailscard})` ,
        width: "1168px",
        height: "80px"
      }} className='d-flex' >
        <div className='d-flex align-items-center gap-2 px-md-5'>
          <div >
            <img src={flightcartlogo} style={{ width: '30px', height: '34px' }} />
          </div>
          <div>
            <p>Emirates EK 043</p>
          </div>
          <div>
            DXB - FRA
          </div>
        </div>
        <div>
          International/Domestic
          <p>Domestic</p>
        </div>
        <div>
          Scheduled date
        </div>
        <div>
          airport code
        </div>
        <div>
          Terminal number
        </div>
        <div>
          <p>Zone</p>
          <p>1</p>
        </div>
        <div>
          <p>Gate</p>
          <p>--</p>
        </div>
        <div>
          Boarding time
        </div>
        <div>
          Check-in queue
        </div>
        <div>
          security queue time
        </div>
        <div>
          immigration queue time
        </div>
      </div>

      <div>

      </div>
    </div>


  )
}


export default Pinnedflightcard
