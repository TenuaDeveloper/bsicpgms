import "./choose-widget.scss";
import { TabView, TabPanel } from 'primereact/tabview';
import { Calendar } from 'primereact/calendar';
import { AutoComplete } from 'primereact/autocomplete';
import SvgIcon from "../../shared/svg-icon/SvgIcon";
import { Container } from 'react-bootstrap';
import React, { useState, useEffect } from 'react';
import Nav from 'react-bootstrap/Nav';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPlaneDeparture, faCar, faLightbulb } from '@fortawesome/free-solid-svg-icons';
import { Dropdown } from 'primereact/dropdown';
import './styles.css'
import { Menu } from 'primereact/menu';
import 'primereact/resources/themes/saga-blue/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import icon_1 from '../images/icon_1.svg'
import icon_3 from '../images/icon_3.svg'
import icon_2 from '../images/icon_2.svg'
import Popup from '../../popup/popup'
import options from './data.js'
import inspOptions from './insp_data.js'
import { useNavigate } from 'react-router-dom'
import { Typeahead } from 'react-bootstrap-typeahead';
import 'react-bootstrap-typeahead/css/Typeahead.css';
import { connect } from 'react-redux';
import { useDispatch, useSelector } from 'react-redux'
import { addFlight, deleteFlight, selectPinFlights, unSelectPinFlights } from '../../../redux/features/pingFlight/pingflightSlice'
import { addInspiration, deleteInspiration, selectInspiration, unSelectInspiration } from '../../../redux/features/pinInspiration/pinInspirationSlice'
import { addPickupDrop, deletePickupDrop, editPickupDrop, selectPinPickupDrop, unSelectPinPickupDrop } from '../../../redux/features/pinPickupDrop/pinPickupDropSlice'
import { terminalListActions } from '../../../redux/features/pinPickupDrop/terminalListSlice'
import { useLocation } from 'react-router-dom';
import { locationActions } from '../../../redux/features/pinInspiration/locationListSlice';
import { flightActions } from '../../../redux/features/pingFlight/flightListSlice';
import { removeCartItemByPin, moveCartItemByPin } from '../../../redux/features/cart/cartslice';
import { selectServices } from '../../../redux/features/common/commonSlice';
import DeletePinConfirmation from '../../popup/deletePinConfirmation';
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { addPinFlight, addPinInspiration, deletePinFlight, deletePinInspiration, addPinPickupDrop, deletePinPickupDrop, getPinFlight, getPinPickupDrop, getPinInspiration } from '../../../redux/features/pingFlight/pinAction';
import { deleteAllItemInCartAPI, getItemInCartAPI, moveAllItemToUncategorizedCartAPI } from '../../../redux/features/cart/cartAction';
import { DropdownButton } from "react-bootstrap";
import { useRef } from 'react';
import DebouncedDropdown from '../../../redux/features/pingFlight/DebouncedDropdown';
import { addMessage, clearMessages, removeMessage } from "../../../redux/features/Notification/messagesSlice";
import { servicesAndOffersTerminalSliceAction } from '../../../redux/features/terminal/selectedTerminalSlice';
import { selectedTerminalValue } from '../../../redux/features/terminal/selectedTerminal';
import flighticon from '../images/plane.svg'
import { personalizedServicesAndOffersActions } from "redux/features/newPersonalizedServices/newPersonalizedServicesSlice";
import moment from "moment";
import { addPickMessage, clearPickMessages, removePickMessage } from "../../../redux/features/Notification/pickNotificationSlice";
import { addInspMessage, removeInspMessage, clearInspMessages } from "../../../redux/features/Notification/inspirationNotificationslice";
import inspireicon from '../../layout/images/icon_3.svg'
import pickupdropicon from '../../layout/images/icon_2.svg'

const Flight = ({ locations, flights, fetchLocations, fetchFlights, terminals, setFlightValue, setDropdownValue, setInspirationValue2, userInfo, setFilterParams, recommendedCategories, setselectedArrivals }) => {
  let location = useLocation();
  const [isFlightPlan, SetIsFlightPlan] = useState(false);
  const [isInspPlan, SetIsInspPlan] = useState(false);
  const [isPickupPlan, SetIsPickupPlan] = useState(false);
  const navigate = useNavigate();
  // const [option, handleSelectOption] = useState('flight');
  const [flightDate, setFlightDate] = useState('');
  const [pickupDate, setPickupDate] = useState('');
  const [inspirationDate, setInspirationDate] = useState('');
  const [flightData, setFlightData] = useState([]);
  const [locationData, setLocationData] = useState([]);
  const [data, setData] = useState([]);
  const [selectedFlight, setSelectedFlight] = useState({});
  const [showAlert, setShowAlert] = useState(false);
  const dispatch = useDispatch()
  const [itemType, setItemType] = useState(null);
  const [itemKey, setItemKey] = useState(null);
  const [id, setId] = useState(null);
  const [basicSelected, setBasicSelected] = useState([]);
  const [selected, setSelected] = useState([]);
  const { flightList, flightError } = useSelector((state) => state.flight)
  const { inspirationList, inspirationError } = useSelector((state) => state.inspiration)
  const { pickupDropList, pickupError } = useSelector((state) => state.pickupDrop)
  const cart = useSelector((state) => state.cart)
  const option = useSelector(state => state.common.option)
  const flightDataRed = useSelector(state => state.flights.flights)
  const locationDataRead = useSelector(state => state.locations.locations)
  const flightInCart = useSelector(state => state.cart.cart.flight);
  const pickupInCart = useSelector(state => state.cart.cart.pickupDrop);
  const inspirationInCart = useSelector(state => state.cart.cart.inspiration);

  const [terminalData, setTerminalData] = useState([]);
  const terminalDataRed = useSelector(state => state.terminallist.terminallist);
  const [selectedTerminal, setSelectedTerminal] = useState({});


  const [isActiveFlight, setIsActiveFlight] = useState(false);
  const [isActivePickup, setIsActivePickup] = useState(false);
  const [isActiveInspiration, setIsActiveInspiration] = useState(false);
  const [flightterminal, setflightTerminal] = useState("");
  const [pinnedFlightSelected, setpinnedFlightSelected] = useState(false)
  const [terminaltitle, setTerminalTitle] = useState("Choose a Terminal...")
  const [prevItem, setPrevItem] = useState(null)
  const menu = useRef(null);
  const [selectedOption, setSelectedOption] = useState('flight');
  const [messages, setMessages] = useState([]);
  const [date, setDate] = useState(null);

  const [value, setValue] = useState('');
  const [items, setItems] = useState([]);
  const [pickMessages, setPickMessages] = useState([]);
  const [inspirationMessages, setInspirationMessages] = useState([]);

  const prefrencesList = recommendedCategories && recommendedCategories.items ? Object.keys(recommendedCategories.items) : [];
  const currentDate = new Date();

  const pickupDropData = [
    { label: 'Pickup', value: 'Pickup' },
    { label: 'Drop', value: 'Drop' },
  ];

  const tab1HeaderTemplate = (options) => {
    const handleClick = () => {
      handleSelectOption('flight');
      if (options.onClick) {
        options.onClick();
      }
    };
    return (
      <button type="button" onClick={handleClick} className={options.className}>
        <SvgIcon icon="plane" width="28" height="28" />
        {options.titleElement}
      </button>
    );
  };
  const tab2HeaderTemplate = (options) => {
    const handleClick = () => {
      handleSelectOption('pickupDrop');
      if (options.onClick) {
        options.onClick();
      }
    };
    return (
      <button type="button" onClick={handleClick} className={options.className}>
        <i className="pi pi-car" />
        {options.titleElement}
      </button>
    );
  };
  const tab3HeaderTemplate = (options) => {
    const handleClick = () => {
      handleSelectOption('inspiration');
      if (options.onClick) {
        options.onClick();
      }
    };
    return (
      <button type="button" onClick={handleClick} className={options.className}>
        <SvgIcon icon="bulb" width="28" height="28" />
        {options.titleElement}
      </button>
    );
  };

  useEffect(() => {
    setFlightData(flightDataRed);
    setLocationData(locationDataRead)
    setTerminalData(terminalDataRed);
    if (userInfo) {
      dispatch(getItemInCartAPI({ token: userInfo?.accessToken }))
    }
  }, [flightDataRed, locationDataRead, userInfo, dispatch, terminalDataRed])

  useEffect(() => {
    const selectedFlight = flightList.find(item => item.selected === true);
    if (selectedFlight) {
      setflightTerminal(selectedFlight.terminal);
      setpinnedFlightSelected(true);
    } else {
      setpinnedFlightSelected(false);
    }
  }, [flightList]);


  const checkActiveFlight = () => {
    const activeFlight = flightList.find((item) => item.active);
    return !!activeFlight;
  };

  const checkActivePickupDrop = () => {
    const activePickupDrop = pickupDropList.find((item) => item.active);
    return !!activePickupDrop;
  };

  const checkActiveInspiration = () => {
    const activeInspiration = inspirationList.find((item) => item.active);
    return !!activeInspiration;
  };

  const handleAddFlight = async (e) => {
    dispatch(clearPickMessages());
    dispatch(clearInspMessages());
    if (!flightDate) {
      toast.error("Please select a date", {
        position: toast.POSITION.TOP_CENTER
      });
      return;
    }

    let inputData = { 'token': userInfo?.accessToken, 'flightNo': e.value.flightNo, "scheduleDate": e.value.scheduleDate, "time": e.value.scheduleTime, "source": e.value.source, "destination": e.value.destination, "terminal": e.value.terminal, "gate": e.value.gate, "flightId": e.value.id, "flightDepartArrivalStatus": e.value.flightDepartArrivalStatus, "flightType": e.value.flightType, "zone": e.value.zone, "boardingTime": e.value.boardingTime };
    let inputDataNonLoggedIn = { 'flightNo': e.value.flightNo, "scheduleDate": e.value.scheduleDate, "time": e.value.scheduleTime, "source": e.value.source, "destination": e.value.destination, "terminal": e.value.terminal, "gate": e.value.gate, "flightId": e.value.id, "flightDepartArrivalStatus": e.value.flightDepartArrivalStatus, "flightType": e.value.flightType, "zone": e.value.zone, "boardingTime": e.value.boardingTime, "airlineLogo": e.value.airlineLogo };
    if (flightList.length > 0 && flightList.some(item => item.flightNo === e.value.flightNo && item.scheduleDate === e.value.scheduleDate && item.time === e.value.scheduleTime)) {
      toast.error("Selected flight is already pinned", {
        position: toast.POSITION.TOP_CENTER
      });
    }
    else {
      setShowAlert(true)
      if (location.pathname === '/jurneyplan') {
        SetIsFlightPlan(true);
      }
      if (flightList.length == 0) {
        dispatch(personalizedServicesAndOffersActions.fetchPersonalizedServicesAndOffers({ "filter": `flightNo=${e.value.flightNo}&flightDate=${moment(e.value.scheduleDate, 'DD-MM-YYYY').format('YYYY-MM-DD')}`, "selectedPageNo": 1, "req": { "productCategories": prefrencesList }, "filterType": "" }))
        setFilterParams(`&flightNo=${e.value.flightNo}&flightDate=${moment(e.value.scheduleDate, 'DD-MM-YYYY').format('YYYY-MM-DD')}`)
        setselectedArrivals("");
      }
      if (userInfo) {
        await dispatch(addPinFlight(inputData));
        dispatch(getPinFlight({ token: userInfo?.accessToken }))
      }
      dispatch(addFlight(inputDataNonLoggedIn));
    }
    setMessages((messages) => [
      ...messages,
      {
        message: `You have pinned flight ${e.value.flightNo}. We will send you updates about this flight.`,
        timestamp: new Date().toISOString(),
      },
    ]);
    dispatch(
      addMessage({
        message: `You have pinned flight ${e.value.flightNo}. We will send you updates about this flight.`,
        timestamp: new Date().toISOString(),
        imageIconUrl: flighticon,
      })
    );

  }

  const handleAddPickupDrop = async (e) => {
    dispatch(clearMessages());
    dispatch(clearInspMessages());
    if (!pickupDate) {
      toast.error("Please select a date", {
        position: toast.POSITION.TOP_CENTER
      });
      return;
    }
    // console.log(e, "selected", selected,"pickupDropList",pickupDropList)
    let data = { 'token': userInfo?.accessToken, "terminal": e.value, "scheduleDate": pickupDate, "time": "02:20" }
    if (pickupDropList.length > 0 && pickupDropList.some(item => item.terminal === e.value && item.scheduleDate === pickupDate)) {
      toast.error("Selected pickup/drop is already pinned", {
        position: toast.POSITION.TOP_CENTER
      });
    }
    else {
      dispatch(addPickupDrop(data));
      if (pickupDropList.length == 0) {
        dispatch(personalizedServicesAndOffersActions.fetchPersonalizedServicesAndOffers({ "filter": `pickupAndDrop=${e.value.slice(0, 1)}`, "selectedPageNo": 1, "req": { "productCategories": prefrencesList }, "filterType": "" }))
        setFilterParams(`&pickupAndDrop=${e.value.slice(0, 1)}`);
        setselectedArrivals("");
      }
      // setShowAlert(true)
      if (location.pathname === '/jurneyplan') {
        SetIsPickupPlan(true);
      }
      if (userInfo) {
        await dispatch(addPinPickupDrop(data));
        dispatch(getPinPickupDrop({ token: userInfo?.accessToken }))
      }
    }
    // dispatch(cartError())
    setPickMessages((pickMessages) => [
      ...pickMessages,
      {
        message: `You have pinned a ${e.value} for ${pickupDate}. We will send you updates about this ${e.value}.`,
        timestamp: new Date().toISOString(),
      },
    ]);
    dispatch(
      addPickMessage({
        message: `You have pinned a ${e.value} for ${pickupDate}. We will send you updates about this ${e.value}.`,
        timestamp: new Date().toISOString(),
        imageIconUrl: pickupdropicon,
      })
    );
  }

  const handleAddInspiration = async (e) => {
    dispatch(clearMessages());
    dispatch(clearPickMessages());
    if (!inspirationDate) {
      toast.error("Please select a month", {
        position: toast.POSITION.TOP_CENTER
      });
      return;
    }
    // console.log(e, "selected", selected)
    let locList = e.value.split(", ")
    let inputData = { 'token': userInfo?.accessToken, "place": e.value, 'location': locList[0], "scheduleMonth": inspirationDate };
    if (inspirationList.length > 0 && inspirationList.some(item => item.place === e.value && item.location === locList[0] && item.scheduleMonth === inspirationDate)) {
      toast.error("Selected location is already pinned", {
        position: toast.POSITION.TOP_CENTER
      });
    }
    else {
      dispatch(addInspiration(inputData));
      if (inspirationList.length == 0) {
        dispatch(personalizedServicesAndOffersActions.fetchPersonalizedServicesAndOffers({ "filter": `location=${locList[0]}&monthYear=${inspirationDate}`, "selectedPageNo": 1, "req": { "productCategories": prefrencesList }, "filterType": "" }))
        setFilterParams(`&location=${locList[0]}&monthYear=${inspirationDate}`);
        setselectedArrivals("");
      }
      // setShowAlert(true)
      if (location.pathname === '/jurneyplan') {
        SetIsInspPlan(true);
      }
      if (userInfo) {
        await dispatch(addPinInspiration(inputData));
        dispatch(getPinInspiration({ token: userInfo?.accessToken }))
      }
    }
    setInspirationMessages((inspirationMessages) => [
      ...inspirationMessages,
      {
        message: `You have pinned an inspiration to ${locList[0]} on ${inspirationDate}. We will send you updates about this inspiration.`,
        timestamp: new Date().toISOString(),
      },
    ]);
    dispatch(
      addInspMessage({
        message: `You have pinned an inspiration to ${locList[0]} on ${inspirationDate}. We will send you updates about this inspiration.`,
        timestamp: new Date().toISOString(),
        imageIconUrl: inspireicon,
      })
    );
  }

  const handleFetchLocationByDate = (date) => {
    dispatch(locationActions.fetchLocations(date));
    setLocationData(locations);
  }
  const handleFetchFlightByDate = (date) => {
    dispatch(flightActions.fetchFlights(date))
  }

  const handleMove = (itemIndex, itemKey, type, details) => {
    let data = { "id": details }
    if (option === 'flight') {
      if (userInfo) {
        const inputdata = {
          "flightNo": itemKey,
          "token": userInfo.accessToken
        }
        dispatch(deletePinFlight(inputdata));
        const flight = flightList.find(ele => ele.flightNo === itemKey);
        const flightId = flight.flightId;
        const cartPayload = {
          "flightId": flightId,
          "location": "",
          "flightType": type,
          "terminal": "",
          "token": userInfo.accessToken
        }
        dispatch(moveAllItemToUncategorizedCartAPI(cartPayload));
      }
      dispatch(deleteFlight(data));
    }
    else if (option === 'pickupDrop') {
      if (userInfo) {
        const inputdata = {
          "id": details,
          "terminal": itemKey,
          "token": userInfo.accessToken
        }
        dispatch(deletePinPickupDrop(inputdata));
        const pickup = pickupDropList.find(ele => ele.terminal === itemKey);
        const terminal = pickup.terminal;
        const cartPayload = {
          "flightId": 0,
          "location": "",
          "flightType": type,
          "terminal": terminal,
          "token": userInfo.accessToken
        }
        dispatch(moveAllItemToUncategorizedCartAPI(cartPayload));
      }
       dispatch(deletePickupDrop(data));
    }
    else if (option === 'inspiration') {
      if (userInfo) {
        const inputdata = {
          "id": details,
          "location": itemKey,
          "token": userInfo.accessToken
        }
        dispatch(deletePinInspiration(inputdata));
        const location = itemKey;
        const cartPayload = {
          "flightId": 0,
          "location": location,
          "flightType": type,
          "terminal": "",
          "token": userInfo.accessToken
        }
        dispatch(moveAllItemToUncategorizedCartAPI(cartPayload));
      }
      dispatch(deleteInspiration(data));
    }
    dispatch(moveCartItemByPin({ itemKey, type }))
    dispatch(removeCartItemByPin({ itemKey, type }))
    setDisplayConfirmationModal(false);
  }

  const handleDelete = (itemIndex, itemKey, type, details) => {
    let data = { "id": details }
    if (option === 'flight') {
      if (userInfo) {
        const inputdata = {
          "flightNo": itemKey,
          "token": userInfo.accessToken
        }
        dispatch(deletePinFlight(inputdata));
        const flight = flightList.find(ele => ele.flightNo === itemKey);
        const flightId = flight.flightId;
        const cartPayload = {
          "flightId": flightId,
          "location": "",
          "flightType": type,
          "terminal": "",
          "token": userInfo.accessToken
        }
        dispatch(deleteAllItemInCartAPI(cartPayload));
      }
      dispatch(deleteFlight(data));
    }
    else if (option === 'pickupDrop') {
      if (userInfo) {
        const inputdata = {
          "id": details,
          "terminal": itemKey,
          "token": userInfo.accessToken
        }
        dispatch(deletePinPickupDrop(inputdata));
        const pickup = pickupDropList.find(ele => ele.terminal === itemKey);
        const terminal = pickup.terminal;
        const cartPayload = {
          "flightId": 0,
          "location": "",
          "flightType": type,
          "terminal": terminal,
          "token": userInfo.accessToken
        }
        dispatch(deleteAllItemInCartAPI(cartPayload));
      }
      dispatch(deletePickupDrop(data));
    }
    else if (option === 'inspiration') {
      if (userInfo) {
        const inputdata = {
          "id": details,
          "location": itemKey,
          "token": userInfo.accessToken
        }
        dispatch(deletePinInspiration(inputdata));
        // const insp = inspirationList.find(ele => ele.location === itemKey);
        const location = itemKey;
        const cartPayload = {
          "flightId": 0,
          "location": location,
          "flightType": type,
          "terminal": "",
          "token": userInfo.accessToken
        }
        dispatch(deleteAllItemInCartAPI(cartPayload));
      }
      dispatch(deleteInspiration(data));
    }
    dispatch(removeCartItemByPin({ itemKey, type }))
    setDisplayConfirmationModal(false);
    dispatch(personalizedServicesAndOffersActions.fetchPersonalizedServicesAndOffers({ "filter": `filterType=`, "selectedPageNo": 1, "req": { "productCategories": prefrencesList }, "filterType": "" }));
  }

  const handleSelectFlight = (item, index) => {

    // Check if the index is provided
    if (index !== undefined) {
      // Make a copy of the flightList array
      const updatedFlightList = [...flightList];
      // Remove the selected flight from the current position
      const selectedFlight = updatedFlightList.splice(index, 1)[0];
      // Insert the selected flight at the front of the flightList array
      dispatch(addFlight(selectedFlight));
    }

    if (!item.selected) {
      dispatch(personalizedServicesAndOffersActions.fetchPersonalizedServicesAndOffers({ "filter": `flightNo=${item.flightNo}&flightDate=${moment(item.scheduleDate, 'DD-MM-YYYY').format('YYYY-MM-DD')}`, "selectedPageNo": 1, "req": { "productCategories": prefrencesList }, "filterType": "" }))
      setFilterParams(`&flightNo=${item.flightNo}&flightDate=${moment(item.scheduleDate, 'DD-MM-YYYY').format('YYYY-MM-DD')}`)
      dispatch(selectPinFlights({ id: item.id }));
      // console.log("setting flight pinned inside flight page ==>",item.terminal)
      setFlightValue(item.terminal);
    } else {
      dispatch(personalizedServicesAndOffersActions.fetchPersonalizedServicesAndOffers({ "filter": `filterType=`, "selectedPageNo": 1, "req": { "productCategories": prefrencesList }, "filterType": "" }));
      setFilterParams("");
      setselectedArrivals("");
      dispatch(unSelectPinFlights({ id: item.id }));
      // console.log("setting inside flight page ==> empty")
      setFlightValue(null);
    }

    if (location.pathname === "/jurneyplan" && isFlightPlan && !flightInCart[item.flightNo]) {
      navigate("/");
    }
  };


  const handleSelectPickupDrop = (item) => {
    if (!item.selected) {
      dispatch(personalizedServicesAndOffersActions.fetchPersonalizedServicesAndOffers({ "filter": `pickupAndDrop=${item.terminal.slice(0, 1)}`, "selectedPageNo": 1, "req": { "productCategories": prefrencesList }, "filterType": "" }))
      setFilterParams(`&pickupAndDrop=${item.terminal.slice(0, 1)}`);
      dispatch(selectPinPickupDrop({ id: item.id }))
      // console.log("setting pickupdrop pinned inside flight page ==>",item.terminal)
      setFlightValue(item.terminal);
    } else {
      dispatch(personalizedServicesAndOffersActions.fetchPersonalizedServicesAndOffers({ "filter": `filterType=`, "selectedPageNo": 1, "req": { "productCategories": prefrencesList }, "filterType": "" }));
      setFilterParams("");
      setselectedArrivals("");
      dispatch(unSelectPinPickupDrop({ id: item.id }))
      // console.log("setting pickupdrop pinned inside flight page ==> empty")
      setFlightValue(null);
    }
    if (location.pathname === '/jurneyplan' && isPickupPlan && !pickupInCart[item.flightNo]) {
      navigate("/");
    }
  }

  const handleSelectInspiration = (item) => {
    if (!item.selected) {
      dispatch(personalizedServicesAndOffersActions.fetchPersonalizedServicesAndOffers({ "filter": `location=${item.location}&monthYear=${item.scheduleMonth}`, "selectedPageNo": 1, "req": { "productCategories": prefrencesList }, "filterType": "" }))
      setFilterParams(`&location=${item.location}&monthYear=${item.scheduleMonth}`);
      dispatch(selectInspiration({ id: item.id }))
    } else {
      dispatch(personalizedServicesAndOffersActions.fetchPersonalizedServicesAndOffers({ "filter": `filterType=`, "selectedPageNo": 1, "req": { "productCategories": prefrencesList }, "filterType": "" }));
      setFilterParams("");
      setselectedArrivals("");
      dispatch(unSelectInspiration({ id: item.id }))
    }
    if (location.pathname === '/jurneyplan' && isInspPlan && !inspirationInCart[item.location]) {
      navigate("/");
    }
  }
  const handleFlightSearch = (input) => {
    if (input !== '') {
      const regex = new RegExp(input, 'i');
      setFlightData(flights.filter((flight) => {
        return regex.test(flight.flightNo) || regex.test(flight.destination) || regex.test(flight.source);
      }));
    } else {
      setFlightData([]);
    }
  };


  const handleLocationSearch = (input) => {
    if (input !== '') {
      setLocationData(locations.filter((location) => {
        return location.search(`/${input}/`);
      })
      );
    } else {
    }
  }

  const [displayConfirmationModal, setDisplayConfirmationModal] = useState(false);
  const [deleteMessage, setDeleteMessage] = useState(null);
  const showDeleteModal = (type, details, itemKey) => {
    // console.log(type, details,itemKey,"det")console.log(details,"det00000000000000000000")
    setId(details)
    setItemKey(itemKey)
    if (type === "flight") {
      setDeleteMessage("Are you sure you want to delete the flight ");
    } else if (type === "pickupDrop") {
      setDeleteMessage("Are you sure you want to delete the pickup/drop ");
    } else if (type === "inspiration") {
      setDeleteMessage("Are you sure you want to delete the destination ");
    }

    setDisplayConfirmationModal(true);
  };

  const clearAll = async (item) => {
    flights.forEach(async (flight) => {
      let data = flight.flightNo
      let data1 = flight.flightType
      dispatch(removeCartItemByPin({ data, data1 }));
    });
  };


  // Hide the modal
  const hideConfirmationModal = () => {
    setDisplayConfirmationModal(false);
  };

  const getSelectedClass = (selected) => selected ? "selected-pinned-flight" : "";

  const handleSelectOption = (str) => {
    // somethig
    dispatch(selectServices({ option: str }))
    setSelectedOption(str);
  }

  const handleSelectedFlight = (item) => {
    setPrevItem(item.flightNo)
    if (!pinnedFlightSelected || prevItem !== item.flightNo) {
      // console.log("addd")
      // dispatch(personalizedServicesAndOffersActions.fetchPersonalizedServicesAndOffers({"filter": `flightNo=${item.flightNo}&flightDate=${moment(item.scheduleDate, 'DD-MM-YYYY').format('YYYY-MM-DD')}`, "selectedPageNo": 1, "req":{"productCategories" : []}}))

      // dispatch(servicesAndOffersTerminalSliceAction.fetchServicesAndOffersTerminal(item.terminal))
      // dispatch(selectedTerminalValue({option: item.terminal}))
      // setTerminalTitle(item.terminal ? "Terminal "+item.terminal : "Choose a Terminal")
      // console.log("onclick select terminal")

      // dispatch(personalizedServicesAndOffersActions.fetchPersonalizedServicesAndOffers({"filter": `flightNo=${item.flightNo}&flightDate=${item.scheduleDate}`, "selectedPageNo": 1, "req":{"productCategories" : []}}))
      // fetchPersonalizedServicesAndOffers({"filter": `filterType=`, "selectedPageNo": selectedPageNo, "req":{"productCategories" : []}});

    } else {
      // dispatch(selectedTerminalValue({option: ""}));
      // setTerminalTitle("Choose a Terminal")
      // console.log("onclick select terminal-restet")
      // dispatch(personalizedServicesAndOffersActions.fetchPersonalizedServicesAndOffers({"filter": `filterType=`, "selectedPageNo": 1, "req":{"productCategories" : []}}))

    }

  }

  const handleSelectTerminal = (key, event) => {
    setSelectedTerminal({ key, value: event.target.value });
    if (key !== "") {
      // console.log("Terminal Data ===========>",terminalData)
      const selectedTerminalNo = terminalData.find(item => item.terminalName == key);
      dispatch(servicesAndOffersTerminalSliceAction.fetchServicesAndOffersTerminal(selectedTerminalNo.terminalNumber))
      dispatch(selectedTerminalValue({ option: selectedTerminalNo ? selectedTerminalNo.terminalNumber : "" }))
      setTerminalTitle(selectedTerminalNo ? "Terminal " + selectedTerminalNo.terminalNumber : "Choose a Terminal")
    } else {
      dispatch(selectedTerminalValue({ option: "" }));
      setTerminalTitle("Choose a Terminal")
    }
  };

  const getTerminalbyDate = (date) => {
    dispatch(terminalListActions.fetchPickDropTerminalData(date))
      .then((res) => {
        // console.log("Response from API:", res.payload);
        setTerminalData(res.payload);
      })
      .catch((error) => {
        // console.error("Error fetching terminal data:", error);
      });
  };

  const search = (event) => {
    setItems([...Array(10).keys()].map(item => event.query + '-' + item));
  }

  return (
    <div className="choose-widget">
      <div className="container">
        <div className="d-flex align-items-center choose-widget__tab">
          <h4 className='mb-0'>Choose</h4>
          <TabView>
            <TabPanel onClick={() => handleSelectOption('flight')} headerTemplate={tab1HeaderTemplate} >
              <div className="row">
                <div className="form-group col-md-5">
                  <label className="form-label mb-0">Date</label>
                  <Calendar
                    onChange={async (e) => {
                    setDate(e.value);
                    const selectedDate = new Date(e.target.value);
                    // console.log("selectedDate", moment(selectedDate).format('DD-MM-YYYY'));
                    if (isNaN(selectedDate)) {
                    setFlightDate('');
                    } else {
                    const formattedDate = moment(selectedDate).format('DD-MM-YYYY');
                    // console.log("formattedDate", formattedDate);
                    await handleFetchFlightByDate(moment(selectedDate).format('DD-MM-YYYY'));
                    setFlightDate(formattedDate);
                    }
                  }}
                  placeholder="Select"
                  dateFormat="dd-mm-yy"
                  minDate={currentDate}
                  />
                  <i className="pi pi-calendar"></i>
                </div>
                <div className="form-group col-md-7">
                  <label className="form-label mb-0">Search Flights</label>
                  <Dropdown
                    id="basic-example"
                    value={selected}
                    options={flightData}
                    onChange={handleAddFlight}
                    filter={true}
                    filterPlaceholder="Search"
                    filterBy="label" // change this to the name of the field you want to filter by
                    placeholder="Choose a flight..."
                    minLength={1}
                    style={{ border: 'none' }}
                    scrollHeight="200px"
                  />
                  <ToastContainer />
                  <SvgIcon icon="plane" width="24" height="24" />
                </div>
              </div>
            </TabPanel>
            <TabPanel headerTemplate={tab2HeaderTemplate} onClick={() => handleSelectOption('pickupDrop')} headerClassName="flex align-items-center">
              <div className="row">
                <div className="form-group col-md-5">
                  <label className="form-label mb-0">Date</label>
                  <Calendar onChange={async (e) => {
                    // console.log(e.target.value);
                    const selectedDate = e.target.value;
                    const newFormattedDate = moment(selectedDate).format('DD-MM-YYYY');
                    // console.log(newFormattedDate);
                    if (newFormattedDate === "") {
                    setPickupDate("");
                    } else {;
                    await getTerminalbyDate(newFormattedDate);
                    setPickupDate(newFormattedDate);
                    }
                  }}
                  placeholder="Select"
                  dateFormat="dd-mm-yy"
                  minDate={currentDate}
                  />
                  <i className="pi pi-calendar"></i>
                </div>
                <div className="form-group col-md-7">
                  <label className="form-label mb-0">Pick & Drop</label>
                  <Dropdown
                    value={selected}
                    options={pickupDropData}
                    onChange={handleAddPickupDrop}
                    placeholder="Select"
                    id="basic-example"
                    filter={true}
                    filterPlaceholder="Search"
                    minLength={1}
                    style={{ border: 'none' }}
                    scrollHeight="200px"
                  />
                  <ToastContainer />
                  <i className="pi pi-car"></i>
                </div>
              </div>
            </TabPanel>
            <TabPanel headerTemplate={tab3HeaderTemplate} onClick={() => handleSelectOption('inspiration')} headerClassName="flex align-items-center">
              <div className="row">
                <div className="form-group col-md-5">
                  <label className="form-label mb-0">Month & Year</label>
                  <Calendar
                    onChange={async (e) => {
                    const targetdate = e.target.value;
                    if (targetdate === "") {
                      setInspirationDate(""); // or set it to an initial value
                    } else {
                      const formattedDate = moment(targetdate).format('MMM-YYYY');
                      console.log(formattedDate)
                      await handleFetchLocationByDate(formattedDate);
                      setInspirationDate(formattedDate);
                    }
                    }}
                    placeholder="Select"
                    dateFormat="mm-yy"
                    view="month"
                    monthNavigator={true}
                    yearNavigator={true}
                    yearRange="2000:2030"
                  />

                  <i className="pi pi-calendar"></i>
                </div>
                <div className="form-group col-md-7">
                  <label className="form-label mb-0">Location</label>
                  <Dropdown
                    id="basic-example"
                    value={selected}
                    options={locationData}
                    onChange={handleAddInspiration}
                    onKeyUp={handleLocationSearch}
                    filter={true}
                    filterPlaceholder="Search locations"
                    placeholder="Choose a Location..."
                    style={{ border: 'none' }}
                    scrollHeight="200px"
                  />
                  <ToastContainer />
                  <i className="pi pi-map-marker"></i>
                </div>
              </div>
            </TabPanel>
          </TabView>
          {/* {console.log(option)} */}
          {option === 'flight' && (
            <div id="textbox" className="frame67 row pinned1-frame">
              {flightList.length > 0 && checkActiveFlight() && (
                <span className="pinned1-text">Pinned Flights</span>
              )}

              {flightList.slice(0, 3).map((item, index) =>
                item.active ? (
                  <div
                    id="frame56"
                    key={index}
                    className={`frame56 col-4 ${getSelectedClass(item.selected)}`}
                    onClick={() => handleSelectFlight(item)}
                  >
                    <div
                      id=""
                      className="e234|12-10-2023 "
                      onClick={() => handleSelectedFlight(item)}
                    >

                      {item.flightNo} | {item.time.substr(0, 5)} {item.scheduleDate}
                    </div>
                    <img
                      alt="del"
                      id="ic:baseline-remove-circle"
                      className="ic:baseline-remove-circle"
                      onClick={() => showDeleteModal(option, item.id, item.flightNo)}
                      src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAQCAYAAADJViUEAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAEbSURBVHgBrZLNUcMwEIXfyppccQEeRh3gEpKrh0M6SOgAKiBUwFABKSEHxtdAB6YDwZi7z0HWIv9gROJknEnebbXv09PuCDhBtK+h1FTBGAW2hf5Ks0HwZZTcM9EtmEPPpYmx/MzTh17YJYXGbNbuIMYeMZBJOZpovSqqWvw2yvL78RDYJsWl2Tx7NRBF12OCXWOgAoiJzl9eRRNvpzhCpvVL1LPQVT1R85YlLN52CMFjMM0aC1QTWldUwJ+sV4I9z0WXTGw/ug7z3PHzHZb/WAa/d8kWYoUjJFt/Deducy5t2AVuJ9WmO7hSEIxuCJQd5pA5351X/1cUJQtBmLkRVWdyC7XMT3meLrYu65dSSWyMCKWU2n1HjXPrB9kYYaOEs/QMAAAAAElFTkSuQmCC"
                    />
                  </div>
                ) : null
              )}

              {flightList.length > 3 && (
                <div className="dropdown frame51 col-6" id="frame56">
                  <Menu
                    model={flightList.slice(3).map((item, index) => ({
                      label: `${item.flightNo} | ${item.time.substr(0, 5)} ${item.scheduleDate}`,
                      command: () => {
                        handleSelectFlight(item, index + 3); // Add 3 to the index to account for the items before the slice
                      },
                    }))}
                    popup
                    ref={menu}
                    id="popup_menu"
                    className="custom-menu"
                  />
                  <button
                    className="frame51 dropdown-toggle col-6"
                    type="button"
                    id="dropdownMenuButton"
                    aria-haspopup="true"
                    aria-expanded="false"
                    onClick={(event) => menu.current.toggle(event)}
                  >
                    ...
                  </button>
                  <div className="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    {flightList.slice(3).map((item, index) =>
                      item.active ? (
                        <a
                          key={index}
                          className={`dropdown-item ${getSelectedClass(item.selected)}`}
                          onClick={() => handleSelectFlight(item)}
                        >
                        </a>
                      ) : null
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {showAlert && <Popup showPopup={setShowAlert} />}
          {pickupDropList && option === 'pickupDrop' && <div id="textbox" className="frame67 row pinned1-frame">
            {
              pickupDropList.length > 0 && checkActivePickupDrop() && <span className='pinned1-text'>Pinned Pickup/Drop</span>
            }

            {(option === 'pickupDrop' && pickupDropList.length > 0 && location.pathname === '/')}

            {pickupDropList.slice(0, 3).map((item, index) =>
              item.active ? (
                <div
                  id="frame56"
                  key={index}
                  className={`frame56 col-4 ${getSelectedClass(item.selected)}`}
                  onClick={() => handleSelectPickupDrop(item)}
                >
                  <div id="" className="e234|12-10-2023 ">
                    {item.terminal} | {item.scheduleDate}
                  </div>
                  <img
                    id="ic:baseline-remove-circle"
                    className="ic:baseline-remove-circle"
                    onClick={() => showDeleteModal(option, item.id, item.terminal)}
                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAQCAYAAADJViUEAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAEbSURBVHgBrZLNUcMwEIXfyppccQEeRh3gEpKrh0M6SOgAKiBUwFABKSEHxtdAB6YDwZi7z0HWIv9gROJknEnebbXv09PuCDhBtK+h1FTBGAW2hf5Ks0HwZZTcM9EtmEPPpYmx/MzTh17YJYXGbNbuIMYeMZBJOZpovSqqWvw2yvL78RDYJsWl2Tx7NRBF12OCXWOgAoiJzl9eRRNvpzhCpvVL1LPQVT1R85YlLN52CMFjMM0aC1QTWldUwJ+sV4I9z0WXTGw/ug7z3PHzHZb/WAa/d8kWYoUjJFt/Deducy5t2AVuJ9WmO7hSEIxuCJQd5pA5351X/1cUJQtBmLkRVWdyC7XMT3meLrYu65dSSWyMCKWU2n1HjXPrB9kYYaOEs/QMAAAAAElFTkSuQmCC"
                  />
                </div>
              ) : null
            )}

            {pickupDropList.length > 3 && (
              <div className="dropdown frame51 col-6" id="frame56">
                <Menu
                  model={pickupDropList.slice(3).map((item, index) => ({
                    label: `${item.terminal} | ${item.scheduleDate}`,
                    command: () => {
                      handleSelectPickupDrop(item, index + 3); // Add 3 to the index to account for the items before the slice
                    },
                  }))}
                  popup
                  ref={menu}
                  id="popup_menu"
                  className="custom-menu"
                />
                <button
                  className="frame51 dropdown-toggle col-6"
                  type="button"
                  id="dropdownMenuButton"
                  aria-haspopup="true"
                  aria-expanded="false"
                  onClick={(event) => menu.current.toggle(event)}
                >
                  ...
                </button>
              </div>
            )}
          </div>}

          {showAlert && <Popup showPopup={setShowAlert} />}
          {inspirationList && option === 'inspiration' && <div id="textbox" className="frame67 row pinned1-frame">
            {
              inspirationList.length > 0 && <span className='pinned1-text'>Pinned Inspiration</span>
            }
            {inspirationList.slice(0, 3).map((item, index) =>
              (
                <div
                  id="frame59"
                  key={index}
                  className={`frame59 col-4 ${getSelectedClass(item.selected)}`}
                  onClick={() => handleSelectInspiration(item)}
                >
                  <div id="" className="e234|12-10-2023">
                    {item.location} | {item.scheduleMonth}
                  </div>
                  <img
                    id="ic:baseline-remove-circle"
                    className="ic:baseline-remove-circle"
                    onClick={() => showDeleteModal(option, item.id, item.location)}
                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAQCAYAAADJViUEAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAEbSURBVHgBrZLNUcMwEIXfyppccQEeRh3gEpKrh0M6SOgAKiBUwFABKSEHxtdAB6YDwZi7z0HWIv9gROJknEnebbXv09PuCDhBtK+h1FTBGAW2hf5Ks0HwZZTcM9EtmEPPpYmx/MzTh17YJYXGbNbuIMYeMZBJOZpovSqqWvw2yvL78RDYJsWl2Tx7NRBF12OCXWOgAoiJzl9eRRNvpzhCpvVL1LPQVT1R85YlLN52CMFjMM0aC1QTWldUwJ+sV4I9z0WXTGw/ug7z3PHzHZb/WAa/d8kWYoUjJFt/Deducy5t2AVuJ9WmO7hSEIxuCJQd5pA5351X/1cUJQtBmLkRVWdyC7XMT3meLrYu65dSSWyMCKWU2n1HjXPrB9kYYaOEs/QMAAAAAElFTkSuQmCC"
                  />
                </div>
              )
            )}

            {inspirationList.length > 3 && (
              <div className="dropdown frame51 col-6" id="frame56">
                <Menu
                  model={inspirationList.slice(3).map((item, index) => ({
                    label: `${item.location} | ${item.scheduleMonth}`,
                    command: () => {
                      handleSelectInspiration(item, index + 3); // Add 3 to the index to account for the items before the slice
                    },
                  }))}
                  popup
                  ref={menu}
                  id="popup_menu"
                  className="custom-menu"
                />
                <button
                  className="frame51 dropdown-toggle col-6"
                  type="button"
                  id="dropdownMenuButton"
                  aria-haspopup="true"
                  aria-expanded="false"
                  onClick={(event) => menu.current.toggle(event)}
                >
                  ...
                </button>
              </div>
            )}
          </div>}
          <DeletePinConfirmation showModal={displayConfirmationModal} confirmModal={handleDelete} onCancel={handleMove} hideModal={hideConfirmationModal} itemKey={itemKey} type={option} details={id} message={deleteMessage} />
        </div>
      </div>
    </div>
  );
};

const mapStateToProps = (state) => {
  return {
    locations: state.locations.locations,
    flights: state.flights.flights,
    terminals: state.terminals.terminals,
    userInfo: state.auth.userInfo,
    recommendedCategories: state.recommendedCategories.recommendedCategories,
  };
};

export default connect(mapStateToProps)(Flight);
