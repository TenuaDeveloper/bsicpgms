import { Navbar } from 'react-bootstrap';
import Form from 'react-bootstrap/Form';

const  DatePicker = () =>{
  return (
    <>
     <div className="date-picker">
         Date<div>
             <input type="date" />
             </div>
         
     </div>
    </>
  );
}

export default DatePicker;