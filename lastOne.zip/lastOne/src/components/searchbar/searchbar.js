import React, { useState } from "react";
import { useDispatch } from "react-redux";
import './searchbar.css';
import { fetchSearchCategoryResults, resetSearchCategoryResults } from "../../redux/features/search/searchaction";
import { Dropdown } from 'primereact/dropdown';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { connect } from "react-redux";
import { arrivalActions } from "../../redux/features/newArrivalsFilter/newarrivalSlice";
import {servicesAndOffersTerminalSliceAction} from "../../redux/features/terminal/selectedTerminalSlice";

const SearchBar = ({resetnewArrivals, resetservicesAndOffersTerminal}) => {
  const dispatch = useDispatch();
  const [tag, setTag] = useState('');
  const categories = [
    { name: 'All Categories', code: 'All Categories' },
    { name: 'Bags', code: 'Bags' },
    { name: 'Cosmetics', code: 'Cosmetics' },
    { name: 'Chocolates', code: 'Chocolates' },
    { name: 'Electronics', code: 'Electronics' },
    { name: 'Fashion', code: 'Fashion' },
    { name: 'Food and Beverages', code: 'Food and Beverages' },
    { name: 'Fragrances', code: 'Fragrances' },
    { name: 'Flight Ticket', code: 'Flight Ticket' },
    { name: 'Hotel', code: 'Hotel' },
    { name: 'Lounge', code: 'Lounge' },
    { name: 'Liquor', code: 'Liquor' },
    { name: 'Parking', code: 'Parking' },
    { name: 'Passenger Service', code: 'Passenger Service' },
    { name: 'Restaurant', code: 'Resturant' },
    { name: 'Toys', code: 'Toys' },
    { name: 'Watches', code: 'Watches' }

  ];
  const [category, setCategory] = useState(categories[0]);
  const handleSearch = () => {
    dispatch(fetchSearchCategoryResults({ tag, category: category.code }));
    dispatch(resetnewArrivals());
    dispatch(resetservicesAndOffersTerminal());
  };

  const handleSearchChange = (event) => {
    setTag(event.target.value);
  };
  const handleSelectChange = (event) => {
    setCategory(event.target.value);
  };

  const handleclear = () => {
    setCategory(categories[0]);
    setTag('');
    dispatch(resetSearchCategoryResults());
  }

  return (
    <>
      <div className="searchBoxContainer">
        <div className="searchBoxbox">
          <div className="selectBox" id="search-bar">
            <Dropdown value={category} onChange={(e) => handleSelectChange(e)} options={categories} optionLabel="name" className="selectRight" />
          </div>
          <div className="me-2 bg searchRight">
            <InputText placeholder="Search by keyword..." value={tag} onChange={handleSearchChange} />
          </div>
          <button className="search-Button" variant="primary" onClick={handleSearch}>Search</button>
          <button className="clear-Button" variant="primary" onClick={handleclear}>Clear</button>
          <p className="search-shopping">Shopping</p>
          <p className="search-dining">Dining</p>
          <p className="search-relax"> Relax</p>
          <p className="search-services">Services</p>
          <p className="search-sale-deal">Sale & Deals</p>
        </div>
      </div>
    </>
  );


}

const mapStateToProps = (state) => {
  return {
    resetnewArrivals: arrivalActions.resetnewArrivals,
    resetservicesAndOffersTerminal: servicesAndOffersTerminalSliceAction.resetservicesAndOffersTerminal
  };
};
export default connect(mapStateToProps) (SearchBar);