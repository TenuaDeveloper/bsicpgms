
import React, { useState, useEffect } from 'react';
import "./spotlight.scss";
import { Carousel } from 'primereact/carousel';
import { SpotlightData } from './SpotlightData';



const Spotlight = () => {
  const [images, setImages] = useState([]);

  useEffect(() => {
    SpotlightData.getSpotlight().then((data) => setImages(data));
  }, []);

  const spotlightTemplate = (images) => {
    return (
      <div className="spotlight-slider">
        <div className="spotlight-slider__thumb">
          <img src={`/images/temp/${images.image}`} alt={images.name} />
        </div>
        <div className="spotlight-slider__details">
          <h3>{images.tagline}</h3>
          <h1>{images.title}</h1>
        </div>
      </div>
    );
  };

  return (
    <div className="spotlight">
      <div className="container">
        <Carousel value={images} numVisible={1} numScroll={1} itemTemplate={spotlightTemplate} />
      </div>
    </div>
  );

};

export default Spotlight;

