export const SpotlightData = {
  getSpotlightData() {
    return [
      {
        id: '1',
        title: 'Now at your fingertip',
        tagline: 'Airport Shopping',
        image: 'spotlight.png',
      },
      {
        id: '2',
        title: 'Now at your fingertip',
        tagline: 'Airport Shopping',
        image: 'spotlight.png',
      },
      {
        id: '3',
        title: 'Now at your fingertip',
        tagline: 'Airport Shopping',
        image: 'spotlight.png',
      },
    ]
  },
  getSpotlight() {
    return Promise.resolve(this.getSpotlightData());
  },

};

