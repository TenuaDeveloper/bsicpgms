import React, { Suspense } from 'react';
import { Routes, Route } from "react-router-dom";
import HomePage from '../../pages/HomePage';
import NotFoundPage from '../../pages/NotFoundPage';
import PrivateRoute from '../privateroute';

const Login = React.lazy(() => import('../login/login'));
const Signup = React.lazy(() => import('../signup/signup'));
const OtpScreen  = React.lazy(()=>import('../signup/Otpscreen'))
const CartPage = React.lazy(() => import('../../pages/cartPage/index'));
const Ordersummary = React.lazy(()=>import('../order-details/ordersummary'))
const Orderhistory = React.lazy(()=>import('../order-details/Orderhistory'))
const Payment = React.lazy(()=>import('../layout/payment/Payment'))
const AddtoFav = React.lazy(() => import('../favourites/favourites'));
const Popup = React.lazy(() => import('../popupcomponent/MyPopup'));
const AppRouting = () => { 

  
    return (
      <Routes>
        <Route index element={<HomePage />} />        
        <Route path="home/*" element={<HomePage />} />
        <Route path="*" element={<NotFoundPage />} />
        <Route path="login/*" element={<Suspense fallback={<>...</>}><Login /></Suspense>} />
        <Route path="signup/*" element={<Suspense fallback={<>...</>}><Signup /></Suspense>} />
        <Route path="/otpscreen" element={<Suspense fallback={<>...</>}><OtpScreen/></Suspense>} />
        <Route path="/cart" element={<Suspense fallback={<>...</>}><CartPage /></Suspense>} />        
        <Route path="/ordersummary" element={<Suspense fallback={<>...</>}><Ordersummary/></Suspense>} />
        <Route path="/Orderhistory" element={<Suspense fallback={<>...</>}><Orderhistory/></Suspense>} />
        <Route path="/payment/*" element={<Suspense fallback={<>...</>}><Payment/></Suspense>} />
        <Route path="/favourites" element={<Suspense fallback={<>...</>}><PrivateRoute><AddtoFav /></PrivateRoute></Suspense>} />
        <Route path="/home/service/:serviceId/*" element={<HomePage />} />
      </Routes>
    )
  

}

export default AppRouting;