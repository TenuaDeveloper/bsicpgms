import React from 'react'
import qrImg from "../../assets/images/temp/qrcode.png";
import dwnInvoice from "../../assets/images/temp/dwnInvoice.svg";
import cartImg from "../../components/layout/images/cart-img.svg";
import parkImg from "../../components/layout/images/park-img.svg";
import deliverdSign from "../../components/layout/images/deliver-sign.svg";
import "./ordersummary.scss";
import SearchBar from "components/searchbar/searchbar";
import { useState } from "react";
import { Dropdown } from 'primereact/dropdown';

import orderData from "./orderdetailsdata.json"

// console.log(orderData)
const Orderhistory = () => {
  const orderKeys = ["flight", "inspiration", "pickupDrop", "uncategorized"];
  const [selectedOrderStatus, setOrderStatus] = useState(null);
  const [orderTimeSpan, setOrderTimeSpan] = useState(null);
  const orderStatus = [
    { name: 'All Orders' },
    { name: 'Delivered' },
    { name: 'Not yet shipped' },
    { name: 'Cancelled' },
  ];
  const orderSpan = [
    { name: 'Past 3 Months' },
    { name: '2020' },
    { name: '2021' },
    { name: '2022' },
    { name: '2023' }
  ];

  const orderActionOptions = data => {
    return (
      <>
        <div class="d-flex flex-column bd-highlight mb-3 toDoWithOrders ">
          {data.order.status === "Delivery by" && (
            <>
              <div class="p-1 bd-highlight" style={{ color: '#D9001B' }}>Cancel Order</div>
              <div class="p-1 bd-highlight">Track</div>

              <div class="p-1 bd-highlight">Raise a Complaint</div>
              <div class="p-1 bd-highlight">Rate and Review</div>
            </>
          )}
          {data.order.status === "Delivered On" && (
            <div class="d-flex flex-column bd-highlight mb-3 toDoWithOrders" style={{ marginTop: '30px' }}>
              <div class="p-1 bd-highlight">Raise a Complaint</div>
              <div class="p-1 bd-highlight">Rate and Review</div>
            </div>
          )}
        </div>
      </>
    )
  }

  const renderStatus = (data) => {
    return (
      <>
        <div className="d-flex flex-row row-04">
          <div>
            <img
              src={data.order.qrimg}
              style={{ width: "101px", height: "101px" }}
            />
          </div>
          <div className="d-flex flex-column bd-highlight paddTop-7 ">
            <div className="padd-10">
              <span>
                ORDER #  {data.order.orderId}
              </span>
            </div>
            <div className="bd-highlight">
              <span style={{ color: '#003399' }}>INVOICE# {data.order.invoiceNo}</span>
              <span>
                <img src={dwnInvoice} />
              </span>
            </div>
            <div className="p-2"></div>
            <div className="bd-highlight">
              {data.order.status === "Delivered On" &&
                <img src={data.order.img} />
              }
              &nbsp;&nbsp;<span>{data.order.status} {data.order.date}</span>
            </div>
            {data.order.status === "Delivered On" &&
              (
                <div className="bd-highlight">
                  <span style={{ marginLeft: '25px' }}>at Terminal {data.order.terminal}, Gate No. {data.order.gateNo}</span>
                </div>
              )
            }
            {
              data.order.status === "Delivery by" && (
                <div className="bd-highlight">
                  &nbsp;&nbsp;<span>at Terminal {data.order.terminal}, Gate No. {data.order.gateNo}</span>
                </div>
              )
            }
          </div>
        </div>
      </>
    )
  }

  const renderProduct = (data) => {
    return (
      <>
        <div className='d-flex flex-row row-04'>
          <div className='p-2'>
            <img src={data.product.img} style={{ width: '121px', height: '84px' }} />
          </div>
          <div className="d-flex flex-column bd-highlight mb-3">
            <div className="bd-highlight service-name">
              <span>{data.product.title}</span>
            </div>
            {
              data.order.orderType === "parking" && (
                <>
                  <div className=" bd-highlight service-name ">
                    <span>{data.product.parkingTitle}</span>
                  </div>
                  <div className=" p-1 bd-highlight">
                    <span>
                      {data.product.parkingType}
                    </span>
                  </div>
                  <div className=" bd-highlight">
                    <span style={{ fontSize: '12px' }}>
                      &nbsp;&nbsp;{data.product.timingFrom} to {data.product.timingTo}
                    </span>
                  </div></>
              )
            }
            {/* {
                let sellingPrice = data.product.price
              } */}
            <div>
              <span className='prd-price-1'>INR {data.product.price}{" "}</span>
              <span className='save-price '>INR 100 </span>
              <span className='savemsg'>&nbsp;&nbsp;You Save {data.product.discount}%</span>

            </div>
            {data.order.orderType !== "parking" && (
              <div className=" bd-highlight reward-points">
                <span>Earned +{data.product.rewardPoints} Reward Points</span>
              </div>
            )}

          </div>
        </div>
      </>
    )
  }
  const renderList = (data, _index) => {
    console.log("data : ", data.flightInfo)
    return (
      <div className='order-history-box' key={`order-${_index}`}>
        <div className='d-flex flex-row'>
          <div className="p-2 prd-title">
            <span>{data.flightInfo.flightNo}</span>
            <span>• </span>
            <span>{data.flightInfo.date}</span>
          </div>
          <div className="p-2 prd-title">{data.flightInfo.sourceDestination}</div>
          <div className="p-2 prd-title">Terminal{data.flightInfo.TerminalNo}</div>
        </div>
        <div className='d-flex flex-row '>
          {renderProduct(data)}

          {renderStatus(data)}

          {
            orderActionOptions(data)
          }
        </div>
      </div>
    )
  }

  return (
    <div className="container">
      <div className="searchbar-payment">
        <SearchBar />
      </div>
      <div className="d-flex flex-row justify-content-between ur-order">
        <div>
          Your Orders
        </div>
        <div className="card flex justify-content-center">
          <Dropdown value={selectedOrderStatus} onChange={(e) => setOrderStatus(e.value)} options={orderStatus} optionLabel="name"
            placeholder="All Orders" className="w-full md:w-14rem" />
          &nbsp;&nbsp;<Dropdown value={orderTimeSpan} onChange={(e) => setOrderTimeSpan(e.value)} options={orderSpan} optionLabel="name"
            placeholder="Past 3 Months" className="w-full md:w-14rem" />
        </div>
      </div>
      {orderData.map((data, index) => renderList(data, index))}

    </div>

  )
}

export default Orderhistory
