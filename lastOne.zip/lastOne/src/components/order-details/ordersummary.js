import React from "react";
import cartImg from "../../components/layout/header/cart_img.jpg";
import qrImg from "../../assets/images/temp/qrcode.png";
import dwnInvoice from "../../assets/images/temp/dwnInvoice.svg";
import ordersuccess from "../../assets/images/icons/ordersuccess.svg";
import "./ordersummary.scss";
import { useSelector } from "react-redux";
import PriceSummary from "./pricesummary";
import { useNavigate } from "react-router-dom";
import SearchBar from "components/searchbar/searchbar";
// const getArrayToObj = (data) => {
//   return data.reduce((a, v) => ({ ...a, [v.flightId]: v }), {});
// };

// const modifyCart = (cart, key, obj) => {
//   Object.keys(cart[key]).forEach((item) =>
//     cart[key][item].forEach((it, index) => {
//       cart[key][item][index] = { ...cart[key][item][index], ...obj[item] };
//     })
//   );
// };

// const parseCartData = (cart) => {
// let list = []
// Object.keys(cart).map(key=>{
//     console.log("keys :", key);
//     let item = {

//     }
//   })
// }

const Ordersummary = () => {
  const cartData = useSelector(state => state.cart.cart);
  const cart = JSON.parse(JSON.stringify(cartData))
  // const _orderData = parseCartData(cart)
  // const orderData = useSelector(state => state.orders.ordersData);
  const orderData = useSelector(state => state.purchases?.orderDetails);
  console.log("orderData ", orderData)
  // console.log("orderRes ", orderRes)
  const findCartFlight = useSelector(state=>state.flight.flightList);
  const inspirationFlight = useSelector(state=>state.inspiration.inspirationList);
  // const findPickupDrop = useSelector(state=>state.pickupDrop.pickupDropList);
  const { bookingId } = useSelector(state => state.purchasedItem);
  // const flightToObj = getArrayToObj(findCartFlight)
  // const inspirationToObj = getArrayToObj(findInspirationFlight);
  // const pickDropToObj = getArrayToObj(findPickupDrop)
  // modifyCart(cart,'flight',flightToObj);
  // modifyCart(cart,'pickupDrop',pickDropToObj)
  // modifyCart(cart,'inspiration',inspirationToObj)
  // Object.keys(cart.flight).forEach(item=>cart.flight[item].forEach((it,index)=> {
  //   cart.flight[item][index] = {...cart.flight[item][index],...flightToObj[item]}
  // }))
  const currentDate = new Date();
  const options = { month: 'long', day: 'numeric', year: 'numeric' };
  const formattedDate = currentDate.toLocaleDateString('en-US', options);
  const mapData = ["flight", "pickupDrop", "inspiration", "uncategorized"]
  // console.log("cart=>",cart);
  // const orderData = Object.keys(cart).map(it => Object.values(cart[it]).flat().map(yt=>({...yt,type:it}))).flat();
  // console.log("orderData=>",orderData)
  const navigate = useNavigate();
  const goToHome = () => {
    navigate("/");
  }

  const getInsprationList = id => inspirationFlight.find(item => item.location == id )

  const getFlightInfo = (flightId) => findCartFlight.find(item => item.flightId == flightId )

  const offerAmountCal = (data) => {
    let offerAmmount = 0;
    if (data.offer) {
      if (data.offerType == "Percentage") {
        offerAmmount = data.unitPrice - (data.offerPrice / 100) * data.unitPrice;
        // console.log("^^^^^^^^^^",data, offerAmmount)
      }
      if (data.offerType == "Flat") {
        offerAmmount = data.unitPrice - data.offerPrice;
      }
      if (data.offerType == "Others") {
        offerAmmount = data.unitPrice;
      }
    }
    return offerAmmount.toFixed(2);
  }


  const renderItem = (item) => {
    return (
      <div className="d-flex flex-row justify-content-between">
        <div className="d-flex flex-row">
          <div className="p-2">
            <img
              src={item?.service?.images}
              style={{ width: "121px", height: "84px" }}
            />
          </div>
          <div className="d-flex flex-column bd-highlight mb-3">
            <div className="p-1 bd-highlight service-name">
              <span>{item?.service?.serviceName.slice(0, 30)}</span>
            </div>
            <div className=" p-1 bd-highlight prd-price">
              {item.offer ? <>
                <span>
                  {item?.service?.currency}
                  <span>&nbsp;</span>
                  {item?.purchasedPrice}
                  {/*  <span className='save-price'>$150 </span> */}
                  {/* <span className='savemsg'>You Save 21%</span> */}
                </span></> : <><span>
                  {item?.service?.currency}
                  <span>&nbsp;</span>
                  {item.purchasedPrice}
                  {/*  <span className='save-price'>$150 </span> */}
                  {/* <span className='savemsg'>You Save 21%</span> */}
                </span></>}

            </div>
            <div className=" bd-highlight reward-points">
              <span>Earned +{item?.service?.loyaltyPoints} Reward Points</span>
            </div>
          </div>
        </div>
        <div className="d-flex flex-row">
          <div>
            <img
              src={qrImg}
              style={{ width: "101px", height: "101px" }}
            />
          </div>
          <div className="d-flex flex-column bd-highlight paddTop-7 ">
            <div className="padd-10">
              <span>
                ORDER #{" "}
                {item.orderNumber
                  ? item.orderNumber
                  : "171-3577898-2601920"}
              </span>
            </div>
            <div className="bd-highlight">
              <span>DOWNLOAD INVOICE</span>
              <span>
                <img src={dwnInvoice} />
              </span>
            </div>
            <div className="p-2"></div>
            <div className="bd-highlight">
              <span>Delivery by 11 May 2023</span>
            </div>
            <div className="bd-highlight">
              <span>at HIA Gate</span>
              {/* {item.gate ? `Gate No ${item.gate}` : "--"} */}
              {/* <span>
                    at Terminal {item?.terminal}, Gate No. 22
                  </span> */}
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="container">
      <div className="searchbar-payment">
        <SearchBar />
      </div>
      <div className="d-flex flex-row justify-content-between ur-order mb-3">
        Your Order
      </div>
      <div className="d-flex flex-row order-msg justify-content-center">
        <img src={ordersuccess} style={{ width: "32px", height: "32px" }} />
        <span style={{ marginLeft: "10px", fontSize: "20px" }}>
          Order Created Successfully!
        </span>
      </div>
      <div className="d-flex flex-row gap-3">
        <div className="order-box">
          <div className="d-flex">
            <h4>ORDER PLACED</h4>
            <span className="ms-3" style={{ fontSize: "16px" }}>
              On {formattedDate}
            </span>
          </div>
          <div className="d-flex flex-column">
            {mapData.map((key, index) => {

        
              return (
                <>
                  <div className="d-flex flex-column">
                    
                    {
                      Object.keys(orderData[key]).map((_k, _index) => {
                    console.log("KEY : ",index, _index)
                        const _flight = getFlightInfo(_k);
                        const _ins = getInsprationList(_k)
                        return (
                          <> { index !== 0 && (
                            <div style={{ padding: "0px 10px" }}>
                            <hr />
                          </div>
                          )

                          }
                            <div className="d-flex flex-column">
                              <div className="d-flex flex-row">
                                {
                                  key === "flight" && (
                                    <>
                                      <div className="p-2 prd-title">{
                                        `Flight : ${_flight.flightNo} | ${_flight.scheduleDate} | ${_flight?.source}-${_flight?.destination}`
                                      }</div>
                                      <div className="p-2 prd-title">| HIA</div></>
                                  )}

                                 { key === "inspiration" && (
                                    <>
                                      <div className="p-2 prd-title">{
                                        `Inspiration : ${_k} | ${_ins.scheduleMonth}`
                                      }</div>
                                      
                                      <div className="p-2 prd-title">| HIA</div></>
                                  )
                                }
                                
                              </div>

                              <div className="d-flex flex-column">
                             
                                {orderData[key][_k].map(item => renderItem(item))}
                              </div>
                            </div>

                           
                          </>
                        )
                      }

                      )}
                    {/* {item.type === "pickupDrop" && (
                    <>
                      <span>{item?.scheduleDate}</span>
                      <div className="p-2">{`Terminal ${item?.terminal}`}</div>
                    </>
                  )}
                  {item.type === "inspiration" && (
                    <>
                      <div className="p-2">{`Terminal ${item?.location}`}</div>
                      <div className="p-2">{`Location ${item?.scheduleMonth}`}</div>
                    </>
                  )} */}
                  </div>
                  {/* {renderItem(item)} */}
                  {/* {orderData.length - 1 !== index && (
                    <div style={{ padding: "0px 10px" }}>
                      <hr />
                    </div>
                  )} */}
                </>
              )
            })}
            {/* <div className='d-flex flex-row'>
            <div className="p-2">
              <span>EK043</span>
              <span>• </span>
              <span>18 Oct 2023</span>
            </div>
            <div className="p-2">DXB-FRA</div>
            <div className="p-2">Terminal3</div>
          </div> */}

            {/* <div className='d-flex flex-row justify-content-between'>
            <div className='d-flex flex-row'>
              <div className='p-2'>
                <img src={cartImg} style={{ width: '121px', height: '84px' }} />
              </div>
              <div className="d-flex flex-column bd-highlight mb-3">
                <div className="p-1 bd-highlight">
                  <strong>Valet Parking</strong>
                </div>
                <div className=" p-1 bd-highlight">
                  <span>
                    Self Parking
                  </span>
                </div>
                <div className=" bd-highlight">
                  <span style={{fontSize:'12px'}}>
                    05-04-2023 10:00am to 06-04-2023 03.30pm
                  </span>
                </div>
                <div>
                $80  <span className='save-price'>$100 </span>
                    <span className='savemsg'>You Save 20%</span> 
                  
                </div>
              </div>
            </div>
             <div className='d-flex flex-row'>
              <div>
                <img src={qrImg} style={{ width: '101px', height: '101px' }} />
              </div>
              <div className="d-flex flex-column bd-highlight">
                <div className="bd-highlight px-2">
                  <span>ORDER    # 171-3577898-2601920</span>
                </div>
                <div className="bd-highlight">
                  <span>
                    INVOICE #  189463231
                  </span>
                  <span>
                    <img src={dwnInvoice} />
                  </span>
                </div>
                <div className="bd-highlight">
                  <span>
                    Delivery by 12-Oct-2023
                  </span>
                </div>
                <div className="bd-highlight">
                  <span>
                    at Terminal 3, Gate No. 22
                  </span>
                </div>
              </div>
            </div>
          </div> */}
          </div>
        </div>
        <PriceSummary data={orderData}/>
      </div>
      <div className="d-flex gap-3 mt-2 mb-4">
        <button
          type="button"
          className="l-btn l-btn--outline"
          onClick={goToHome}
        >
          Continue Shopping
        </button>
        <button type="button" className="l-btn l-btn--outline">
          Manage Order
        </button>
      </div>
      {/* <PriceSummary orderData={orderData}/> */}
    </div>
  );
};

export default Ordersummary;
