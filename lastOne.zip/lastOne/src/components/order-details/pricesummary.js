import React, { useState } from 'react'
import './ordersummary.scss'
import {getTotalSelectedItemPrice, 
        getUnitSelectedItemPrice,
        getOfferDiscountPrice,
        getOfferDiscount,
        getTotalCartCount} from '../../redux/features/cart/selector'
import { useSelector } from 'react-redux';

const POINTS_PER_DOLLAR = 20000;
const REDEMPTION_RATE = 100;

function calculateRedemptionAmount(pointsToRedeem) {
  const dollarsToRedeem = pointsToRedeem / POINTS_PER_DOLLAR;
  const redemptionAmount = dollarsToRedeem * REDEMPTION_RATE;
  return redemptionAmount.toFixed(2);
}


const Pricesummary = ({orderData, data})=> {
    const subtotal = data.sumAmount
    const unitPrice = useSelector(state => getUnitSelectedItemPrice(state));
    const discountPrice = useSelector(state => getOfferDiscountPrice(state));
    const discountPercentage = data.offeredDiscountPercent;
    const qty = useSelector((state)=>getTotalCartCount(state));
    const burnedPointsInfo = useSelector(state=>state.cart.reedemInfo)
    // console.log("Cupon and redeem points",getDiscountPrice)
    const totalDiscountPrice = burnedPointsInfo.couponAmount+burnedPointsInfo.pointsAmount
    let points = 0
    orderData && orderData.length > 0 && orderData.forEach(item=>{
      points+=item.loyaltyPoints
     // console.log("data in order price summary======",data)
    })
  return (
    <>
      <div className="summary-box">
        <div className="d-flex flex-row price-summary px-3">
          <span style={{ fontSize: "18px" }}>Price Summary</span>
        </div>
        <div className="summary-box__content">
          <ul className="l-datalist">
            <li className="l-datalist__item">
              <label>Original Product Price ({data.totalQuantity} Item)</label>
              <span>INR {data.sumAmount}</span>
            </li>
            <li className="l-datalist__item">
              <label>You Saved ({Math.round(discountPercentage)}%)</label>
              <span>INR {discountPrice}</span>
            </li>
            <li className="l-datalist__item">
              <label>Price After Discount</label>
              <span>INR {data.totalAmount}</span>
            </li>
            
            <li className="l-datalist__item">
              <label>Delivery Charges</label>
              <span>{data.deliveryCharge}</span>
            </li>
            {/* <li className="l-datalist__item">
              <label>Coupon Discount</label>
              <span>INR {burnedPointsInfo && burnedPointsInfo.couponAmount && parseInt(burnedPointsInfo.couponAmount) > 0 ? burnedPointsInfo.couponAmount : 0}</span>
            </li> */}
          </ul>
          <ul className="l-datalist">
            <li className="l-datalist__item">
              <label>Points redeemed ({data.redeemedPoints})</label>
               <span>INR {data.redeemedPointsAmount}
              {/*{burnedPointsInfo && burnedPointsInfo.pointsAmount && 
              parseInt(burnedPointsInfo.pointsAmount) > 0 ? burnedPointsInfo.pointsAmount : 0} */}
              </span>
            </li>
          </ul>
          <ul className="l-datalist mb-4">
            <li className="l-datalist__item">
              <label>Total amount paid</label>
              <span>INR&nbsp;{data.totalAmount+data.deliveryCharge}
              {/* // (burnedPointsInfo && burnedPointsInfo.pointsAmount && 
              //   parseInt(burnedPointsInfo.pointsAmount) > 0 ? 
              //   burnedPointsInfo.pointsAmount : 0)
              // -(burnedPointsInfo && burnedPointsInfo.couponAmount && 
              // parseInt(burnedPointsInfo.couponAmount) > 0 
              // ? burnedPointsInfo.couponAmount : 0)} */}
              </span>
            </li>
          </ul>
          <span
            style={{
              fontWeight: "400",
              fontStyle: "normal",
              fontSize: "12px",
              color: " #7F7F7F",
            }}
          >
            Mode of payment - Credit Card
          </span>
        </div>
        {/* 
        <div className="d-flex flex-row justify-content-between px-4">
          <div className="d-flex flex-column bd-highlight mb-3">
            <div className="p-2 bd-highlight">
              <span>Product Price </span>
              <span>({qty} Item)</span>
            </div>
            <div className="p-2 bd-highlight">
              <span>Offer Discount ({Math.round(discountPercentage)}%)</span>
            </div>
          </div>
          <div className="d-flex flex-column bd-highlight mb-3">
            <div className="p-2 bd-highlight">INR {unitPrice}</div>
            <div className="p-2 bd-highlight d-flex justify-content-end">
              -INR {discountPrice}
            </div>
          </div>
        </div>
        <div style={{ padding: "0px 10px" }}>
          <hr />
        </div>

        <div className="d-flex flex-row justify-content-between px-4">
          <div className="d-flex flex-column bd-highlight mb-3">
            <div className="p-2 bd-highlight">
              <span>Points redeemed (2000 points)</span>
            </div>
           </div>
           <div className="d-flex flex-column bd-highlight mb-3">
            <div className="p-2 bd-highlight"><span>+INR&nbsp;{calculateRedemptionAmount(points)}</span></div>
            </div>
        </div>
        <div style={{ padding: "0px 10px" }}>
          <hr />
        </div>
        <div className="d-flex flex-row justify-content-between px-4">
          <div className="d-flex flex-column bd-highlight mb-3">
            <div className="p-2 bd-highlight">
              <span>Total amount paid</span>
            </div>
            <div className="p-2">
              <span
                style={{
                  fontWeight: "400",
                  fontStyle: "normal",
                  fontSize: "12px",
                  color: " #7F7F7F",
                }}
              >
                Mode of payment - Credit Card
              </span>
            </div>
          </div>
          <div className="d-flex flex-column bd-highlight mb-3">
            <div className="p-2 bd-highlight">
              INR&nbsp;{subtotal - discountPrice}
            </div>
          </div>
        </div> */}
      </div>
    </>
  );
};

export default Pricesummary;
