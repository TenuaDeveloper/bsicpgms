import React,{useState} from 'react'
import './signup.css'
function Mobilenofield() {
    const [value, setValue] = useState()
  return (
    <>
    {/* <PhoneInput
      placeholder="Enter phone number"
      className='text-style'
      value={value}
      onChange={setValue}/> */}
    </>
  )
}

export default Mobilenofield
