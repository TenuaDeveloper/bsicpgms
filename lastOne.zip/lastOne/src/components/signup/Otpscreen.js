import React, { useState, useRef } from 'react'
import { useNavigate } from 'react-router-dom';
import './signup.css'
import { useDispatch, useSelector } from 'react-redux'
// import mobile from '../../assets/params/images/icon/mobile.png'
import { userLogin } from '../../redux/features/auth/authActions'
import { ToastContainer, toast } from "react-toastify";

function Otpscreen() {
    const navigate = useNavigate()
    const dispatch = useDispatch();
    const OTP = 12345;
    const [otpVal, setOtpVal] = useState([])
    const handleOtp = (e) => {
        let val = e.target.value
        setOtpVal([...otpVal, val])
    }
    const userInfo = useSelector(state => state.auth.userSignUpInfo)
    const [userOtp, setUserOtp] = useState({ otp1: "", otp2: "", otp3: "", otp4: "", otp5: "" })

    const handleChange = (value1, event) => {
        setUserOtp({ ...userOtp, [value1]: event.target.value });
    }
    const handleSubmit = (event) => {
        event.preventDefault();
        const data = Object.keys(userOtp).map(key => userOtp[key]).join("")
        if (OTP == Number(data)) {
            let loginData = { 'username': userInfo.username, 'password': userInfo.password };
            dispatch(userLogin(loginData));
            toast.success("User has been successfully registered");
            navigate('/login')
        }
    }

    const inputfocus = (elmnt) => {
        if (elmnt.key === "Delete" || elmnt.key === "Backspace") {
            const next = elmnt.target.tabIndex - 2;
            if (next > -1) {

                elmnt.target.form.elements[next].focus()
            }
        }
        else {
            const next = elmnt.target.tabIndex;
            if (next < 5) {
                elmnt.target.form.elements[next].focus()
            }
        }

    }
    return (
        <>
            <div className="otp-main-box">

                <div className="otp-header-box">
                    <h5 className="otp-heading">OTP VERIFICATION</h5>
                    <div>
                        <p>code has been send to ******1258</p>
                    </div>
                </div>
                <form onSubmit={handleSubmit}>
                    <div className="otp-box">
                        <input
                            className="otp-box-1"
                            name="otp1"
                            type="text"
                            autoComplete="off"
                            // className="otpInput"
                            value={userOtp.otp1}
                            onKeyPress={inputfocus}
                            onChange={e => handleChange("otp1", e)}
                            tabIndex="1" maxLength="1" onKeyUp={e => inputfocus(e)} />
                        <input
                            className="otp-box-2"
                            name="otp2"
                            type="text"
                            autoComplete="off"
                            // className="otpInput"
                            value={userOtp.otp2}
                            onChange={e => handleChange("otp2", e)}
                            tabIndex="2" maxLength="1" onKeyUp={e => inputfocus(e)}
                        />
                        <input
                            className="otp-box-3"
                            name="otp3"
                            type="text"
                            autoComplete="off"
                            // className="otpInput"
                            value={userOtp.otp3}
                            onChange={e => handleChange("otp3", e)}
                            tabIndex="3" maxLength="1" onKeyUp={e => inputfocus(e)}
                        />
                        <input
                            className="otp-box-4"
                            name="otp4"
                            type="text"
                            autoComplete="off"
                            // className="otpInput"
                            value={userOtp.otp4}
                            onChange={e => handleChange("otp4", e)}
                            tabIndex="4" maxLength="1" onKeyUp={e => inputfocus(e)}
                        />
                        <input
                            className="otp-box-5"
                            name="otp5"
                            type="text"
                            autoComplete="off"
                            // className="otpInput"
                            value={userOtp.otp5}
                            onChange={e => handleChange("otp5", e)}
                            tabIndex="5" maxLength="1" onKeyUp={e => inputfocus(e)}
                        />
                    </div>

                    <div className='otp-footer-box'>
                        <p className='otp-not-send'>
                            didn't get the otp ?
                            <a href="#" className="">Resend</a>
                        </p>
                    </div>
                    <div className="otp-toast-box">
                        <button className="verify-button" type='submit' onClick={handleSubmit}>Verify</button>
                    </div>
                    <ToastContainer />
                </form>

            </div>
        </>
    )
}

export default Otpscreen
