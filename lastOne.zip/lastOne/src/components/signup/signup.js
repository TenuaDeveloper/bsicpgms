import React, { useState, useEffect } from 'react'
import { Col, Row, Container, Form } from "react-bootstrap";
import './signup.css'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import PhoneInput from 'react-phone-number-input'
import 'react-phone-number-input/style.css'
import { userSignUp } from '../../redux/features/auth/authActions'
import { onRegisterStart } from "../../redux/features/auth/authSlice"
import { useDispatch, useSelector } from 'react-redux'
import { InputText } from 'primereact/inputtext';
import { Card } from 'primereact/card';

function Signup() {
  const initialValues = { username: "", email: "", mobileno: "", password: "" }
  const [userData, setUserData] = useState(initialValues)
  const [formErrors, setFormErrors] = useState({})
  const dispatch = useDispatch();
  const navigate = useNavigate()

  const handleChange = (e) => {
    const { name, value } = e.target
    setUserData({ ...userData, [name]: value })
    // console.log(userData, "userData")
  }

  const userInfo = useSelector(state => state.auth)

  const handleSubmit = (e) => {
    e.preventDefault()
    if (validate(userData)) {
      const data = { username: userData.username, email: userData.email, phone: userData.mobileno, password: userData.password };
      dispatch(userSignUp(data))
    }

    // setIsSubmit(true)
  }

  // DIDMOUNT
  useEffect(() => {
    dispatch(onRegisterStart())
  }, [])

  useEffect(() => {
    // console.log("userInfo ", userInfo)
    if (!userInfo.loading && userInfo.success) {
      navigate('/Otpscreen')
      // console.log(userData)
    }
  }, [userInfo])

  const validate = (values) => {
    const errors = {}
    const regex = /\S+@\S+\.\S+/
    if (!values.username) {
      errors.username = "Please Enter your Name "
    }
    if (!values.email) {
      errors.email = "Please Enter email address !!"
    } else if (!regex.test(values.email)) {
      errors.email = 'This is not a valid Email Format '
    }
    if (!values.mobileno) {
      errors.mobileno = "Please Enter your Mobile No."
    }
    if (!values.password) {
      errors.password = "Password is required"
    } else if (values.password.length < 4) {
      errors.password = "Password must be more than 4 characters"
    } else if (values.password.length > 10) {
      errors.password = "Password cannot exceed more than 10 characters "
    }
    setFormErrors(errors)
    return errors
  }

  const handleMobileInput = data => {
    setUserData({ ...userData, mobileno: data })
  }

  const footer = (
    <div className="register-footer">
      <button className="register-button" variant="primary" onClick={handleSubmit}>Create Account</button>
      <p className="register-login">
        Already have an account?   {" "}
        <Link to="/login" className='link-signin'>
          Sign In
        </Link>
      </p>
    </div>
  );
  return (
    <>
      <Container>
        <Row className="register-row">
          <Card title="Register" footer={footer} className="register-card">
            <label htmlFor="username" className='register-name'>Your Name</label>
            <InputText className="register-text-name" placeholder="Enter Your Name" value={userData.username} name='username' onChange={handleChange} />
            <p className='errors'>{formErrors.username}</p>
            <label htmlFor="username" className='register-name'>Email Address</label>
            <InputText className="register-text-email" placeholder="Enter email" value={userData.email} name='email' onChange={handleChange} />
            <p className='errors'>{formErrors.email}</p>
            <label htmlFor="username" className='register-name'>Mobile Number</label>
            <PhoneInput
              placeholder="Enter phone number"
              className="register-text-phone"
              name='mobileno'
              value={userData.mobileno}
              onChange={handleMobileInput} />
            <p className='errors'>{formErrors.mobileno}</p>
            <label htmlFor="username" className='register-name'>Password</label>
            <InputText className="register-text-password" placeholder="Password" value={userData.password} name='password' onChange={handleChange} />
            <p className='errors'>{formErrors.password}</p>
          </Card>
        </Row>
      </Container>


    </>
  )
}

export default Signup

