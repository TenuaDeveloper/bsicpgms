import React, { useState, useEffect } from 'react'
import './login.css';
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { userLogin } from '../../redux/features/auth/authActions'
import { getItemInCartAPI } from "../../redux/features/cart/cartAction"
import { getPinFlight, getPinPickupDrop, getPinInspiration } from '../../redux/features/pingFlight/pinAction';
import { getWishList } from '../../redux/features/wishlist/wishlistAction';
import { fetchFavourites } from '../../redux/features/fav/favouriteSlice';
import { fetchPurchases,purchageHistory } from '../../redux/features/purchaseList/purchaseListSlice';
import { InputText } from "primereact/inputtext";
import { Card } from 'primereact/card';
// import logo from '../layout/images/QR_Logo.png'
import logo from "assets/images/cial_logo-transformed.png"
import powImg from '../../assets/images/u19.svg'

import { Password } from 'primereact/password';
        

const LoginScreen = ({ history}) => {
  const location = useLocation();
  const navigate = useNavigate();
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const dispatch = useDispatch()
  const { loading, userInfo, error } = useSelector((state) => state.auth)
  const redirect = ((location.state && location.state?.from?.pathname !== '/login') ? location.state.from.pathname : "/");
  const [showLogin, setShowLogin] = useState(true);
  const [formErrors, setFormErrors] = useState({})
  const [showPassword, setShowPassword] = useState(false);

  useEffect(() => {
    if (userInfo) {
      navigate(redirect)
      dispatch(getItemInCartAPI({ token: userInfo?.accessToken }))
      dispatch(getPinFlight({ token: userInfo?.accessToken }))
      dispatch(getPinPickupDrop({ token: userInfo?.accessToken }))
      dispatch(getPinInspiration({ token: userInfo?.accessToken }))
      dispatch(getWishList({ token: userInfo?.accessToken }))
      dispatch(purchageHistory({ token: userInfo?.accessToken }))
    }
  }, [history, userInfo, redirect, dispatch, navigate])

  const submitHandler = (e) => {
    e.preventDefault();
    const errors = validate({ username, password });
    if (Object.keys(errors).length === 0) {
      // console.log("Values->", username, password);
      let data = { username, password };
      dispatch(userLogin(data));
      if (userInfo) {
        dispatch(fetchPurchases({ token: userInfo?.accessToken }));
        // dispatch(fetchFavourites({ token: userInfo?.accessToken }));
        dispatch(getWishList({ token: userInfo?.accessToken }));
      }
    }
  };

  if (!showLogin) {
    return null;
  }

  const validate = (values) => {
    const errors = {}
    if (!values.username) {
      errors.username = "Please Enter your Name "
    }
    if (!values.password) {
      errors.password = "Password is required"
    }
    setFormErrors(errors)
    return errors
  }
  const togglePasswordVisibility = () => {
      setShowPassword(!showPassword);
    };

  const footer = (
    <div className="login-footer">
      <button className="login-button" variant="primary" onClick={submitHandler}>Login</button>
      <p className="login-register">
        <Link to="/signup" className='link-signup'>
          Register
        </Link>
      </p>
      <p className="login-forgot">
        <Link to="/signup" className='link-forgot'>
          Forgot Password?
        </Link>
      </p>
      <p className="login-otp">
        <Link to="" className='link-otp'>
          Receive OTP?
        </Link>
      </p>
      <img alt="card" className='footer-image' src={powImg} />
    </div>
  );
  const header = (
    <div className="login-header">
      <img src={logo} alt="Airport" className='header-image' />
    </div>
  )

  return (
    <body className="login-page">
      <div className="Auth-form-container">
        <Card title="Login" footer={footer} header={header} className="login-card">
          <label htmlFor="username" className='login-name'>Username</label>
          <InputText id="username" className="login-text-name" type='text' value={username} onChange={(e) => setUsername(e.target.value)} />
          <p className='errors-username'>{formErrors.username}</p>
          <label htmlFor="password" className='login-password'>Password</label>
          <div className="login-input-wrapper">
            {/* <InputText id="password" className="login-text-password" type='password' value={password} onChange={(e) => setPassword(e.target.value)} /> */}
            <InputText id="password" className="login-text-password"type={showPassword ? 'text' : 'password'} value={password} onChange={(e) => setPassword(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && submitHandler(e)} />
             {/* <Password  id="password" className="login-text-password" value={password} onChange={(e) => setPassword(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && submitHandler(e)} toggleMask /> */}
            <p className='errors-password'>{formErrors.password}</p>
            <div className="password-icon"></div>
            <span className="show-password" onClick={togglePasswordVisibility}>{showPassword ? 'Hide' : 'Show'}</span>
          </div>
        </Card>
      </div>
    </body>
  )
}

export default LoginScreen




