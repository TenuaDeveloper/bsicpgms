import React, { useState, useEffect } from 'react';
import { Galleria } from 'primereact/galleria';
// import { PhotoService } from './service/PhotoService';
import sliderimg from 'assets/images/temp/sliderimg1.png'

const list = [
    {
        itemImageSrc: sliderimg,
        alt: 'Description for Image 1',
        title: 'Title 1'
    },
    {
        itemImageSrc: 'https://primefaces.org/cdn/primereact/images/galleria/galleria1.jpg',
        alt: 'Description for Image 1',
        title: 'Title 1'
    }
]
const Slider = () => {
    const [images, setImages] = useState(list);

    // useEffect(() => {
    //     PhotoService.getImages().then((data) => setImages(data));
    // }, []); // eslint-disable-line react-hooks/exhaustive-deps

    const itemTemplate = (item) => {
        return <img src={item.itemImageSrc} alt={item.alt} style={{ marginLeft: 'auto', marginRight: '16px',height:'380px ' }} />;
    };

    return (
        <div className="card" style={{ backgroundColor: 'rgba(250, 200, 50, 1)', marginTop: '15px' ,height:'380px'}} >
            {/* <div id="u89" className="ax_default heading_2">
                <div id="u89_div" className=""></div>
                <div id="u89_text" className="text ">
                    <p><span>Airport Shopping</span></p>
                </div>
            </div>
            <div id="u90" class="ax_default heading_2">
        <div id="u90_div" class=""></div>
        <div id="u90_text" class="text ">
          <p><span>Now at your fingertip</span></p>
        </div>
        showIndicators
      </div> */}
            <Galleria value={images} showThumbnails={false}  item={itemTemplate} />
        </div>
    )
}

export default Slider