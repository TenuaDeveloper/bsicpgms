import React from 'react';
import "./header.scss";
import logo from "assets/images/cial_logo.jpg";
import profileImg from "assets/images/temp/userpic.jpg";
import { Menubar } from 'primereact/menubar';
import carticon from 'assets/images/icons/carticon.svg'
import bellicon from 'assets/images/icons/bellicon.svg'
import Account from '../../layout/header/Account';
import {useState} from 'react';
import { Dropdown } from 'primereact/dropdown';
import Notification from './Notification';
import { useNavigate } from 'react-router-dom';  
import { getTotalCartCount } from '../../../redux/features/cart/selector'

const Header = () => {
  const [selectedCurrency, setSelectedCurrency] = useState('INR');
  const [selectedLanguage, setSelectedLanguage] = useState('English');
  const currency = [
    { name: 'QAR'},
      { name: 'INR'},
      { name: 'GBP'},
      { name: 'SGD'},
      { name: 'SAR' },
      { name: 'OMR' },
      { name: 'BHD' },
      { name: 'HKD' },
      { name: 'CAD'},
      { name: 'AUD'},
      { name: 'CHF'},
      { name: 'MYR' },
      { name: 'EUR' },
      { name: 'SCP' },
      { name: 'CNY' },
      { name: 'KWD'},
      { name: 'USD'},
      { name: 'ILS'}
  ];
  const language = [
    { name: 'Arabic' },
    { name: 'Chinese' },
    { name: 'English' }
    
];
  const handletohome = () => {
    navigate('/home');
  };
  const headerMenu = [
    {
      label: 'Home',
      command: handletohome
    },
    {
      label: 'Airport Guide',
      items: [
        {
          label: 'Terminal 1',
        },
        {
          label: 'Terminal 2',
        },
        {
          label: 'Terminal 3',
        },
        {
          label: 'Arrival Guide',
        },
        {
          label: 'Departure Guide',
        },
        {
          label: 'Transiting Guide',
        },
        {
          label: 'Special Assistance',
        },
      ]
    },
    {
      label: 'Discover',
      items:[
        {
          label: 'Parking',
        },
        {
          label: 'Transport',
        },
        {
          label: 'Hotels',
        },
        {
          label: 'Lounges',
        },
        {
          label: 'Facilities and Services',
        },
        {
          label: 'Free Wi-Fi',
        },
        {
          label: 'Attractions',
        },
        {
          label: 'Events',
        }
      ]
    },
    {
      label: 'Shop',
      items:[
        {
          label: 'Great Deals',
        },
        {
          label: 'Duty Free',
        },
        {
          label: 'Shop Online',
        },
        {
          label: 'Explore Shops',
        }
      ]
    },
    {
      label: 'News & Posts',
      items:[
        {
          label: 'News',
        },
        {
          label: 'Blogs',
        },
        {
          label: 'Social media posts',
        }
      ]
    }
  ];
  
  const navigate = useNavigate();

  const handletocart = () => {
    navigate('/cart');
  };
  

  
  const cartTotal = getTotalCartCount()


  return (
    <header className="header">
      <div className="container">
        <div className="header__block">
          <div className="logo">
            <img src={logo} onClick={handletohome} alt="HIA" title="HIA" width={150}  />
          </div>
          <Menubar model={headerMenu} />
          <div className='d-flex align-items-center gap-2'>
          <div className="card flex justify-content-center">
            <Dropdown value={selectedCurrency} onChange={(e) => setSelectedCurrency(e.value)} options={currency} optionLabel="name" 
            placeholder="INR" style={{width:'75px'}}/>
        </div>
        <div className="card flex justify-content-center">
            <Dropdown value={selectedLanguage} onChange={(e) => setSelectedLanguage(e.value)} style={{width:'95px'}}  options={language} optionLabel="name" 
            placeholder="English" />
        </div>
            <div className="header-notification">
              <Notification/>
            </div>
            <div className="header-cart">
              {/* <i className='pi pi-shopping-bag'></i> */}
              <img src={carticon} onClick={handletocart} alt="cart" />
              <span className='header-cart__count'>{cartTotal}</span>
            </div>
            <div className="header-profile" ><Account /></div>
          </div>
        </div>
      </div>
    </header>
  );
}

export default Header;




