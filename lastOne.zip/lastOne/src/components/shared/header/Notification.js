import React, { useEffect, useState, useRef } from "react";
import { connect } from "react-redux";
import { Navbar, Container } from 'react-bootstrap';
import bellicon from 'assets/images/icons/bellicon.svg'
import { useSelector } from "react-redux";
import { OverlayPanel } from "primereact/overlaypanel";
import { Divider } from "primereact/divider";
import "./notification.css";
import { useDispatch } from 'react-redux'
import { addMessage, clearMessages, removeMessage } from "../../../redux/features/Notification/messagesSlice";
import 'primeicons/primeicons.css';
import offericon from '../../layout/images/offer.svg'
import infoicon from '../../layout/images/info.svg'
import flighticon from '../../layout/images/plane.svg'
import { addPickMessage, clearPickMessages, removePickMessage } from "../../../redux/features/Notification/pickNotificationSlice";
import { addInspMessage, removeInspMessage, clearInspMessages } from "../../../redux/features/Notification/inspirationNotificationslice";
import inspireicon from '../../layout/images/inspire.svg'
import pickupdropicon from '../../layout/images/icon_2.svg'

const Notification = ({ notification, inspnotification, picknotification }) => {
    const op = useRef(null);
    const { flightList, error } = useSelector((state) => state.flight);
    const dispatch = useDispatch()
    const [showAll, setShowAll] = useState(false);
    const { inspirationList, inspirationError } = useSelector((state) => state.inspiration)
    const { pickupDropList, pickupError } = useSelector((state) => state.pickupDrop)

    // const renderedMessages = showAll ? notification : notification ? notification.slice(0, 3) : []
    const renderedMessages = showAll
        ? [...notification, ...inspnotification, ...picknotification]
        : [...notification, ...inspnotification, ...picknotification].slice(0, 3);



    useEffect(() => {
        const intervalId = setInterval(() => {
            if (flightList && flightList.length > 0) {
                dispatch(addMessage({
                    message: "New offer launched on selected chocolates and confectionaries, including Lindt, Toblerone, and Ferrero Rocher.",
                    timestamp: new Date().toISOString(),
                    imageIconUrl: offericon,
                }));
                const latestFlight = flightList[flightList.length - 1];
                const today = new Date();
                const newMessage =
                    latestFlight.scheduleDate === today.toISOString().slice(0, 10)
                        ?
                        {
                            message: `Gate Update: The gate for the flight ${latestFlight.flightNo} from ${latestFlight.source} to ${latestFlight.destination}, scheduled to depart on ${latestFlight.scheduleDate}, at ${latestFlight.time}, has been changed to gate B4. Please check the departure board for updated information.`,
                            timestamp: new Date().toISOString(),
                            imageIconUrl: flighticon,
                        }
                        : {
                            message: `Your flight ${latestFlight.flightNo} from ${latestFlight.source} to ${latestFlight.destination} is scheduled to depart at ${latestFlight.time} on ${latestFlight.scheduleDate}. Please arrive at the airport at least two hours before your flight time.`,
                            timestamp: new Date().toISOString(),
                            imageIconUrl: flighticon,
                        };
                dispatch(addMessage(newMessage));
            }

            if (inspirationList && inspirationList.length > 0) {
                dispatch(
                    addInspMessage({
                        message: "New offer launched!!! Get 20% off on all fragrances from popular brands like Chanel, Dior, and Gucci.",
                        timestamp: new Date().toISOString(),
                        imageIconUrl: offericon,
                    })
                );

                const latestInspiration = inspirationList[inspirationList.length - 1];
                const currentMonth = new Date().toLocaleString('default', { month: 'long', year: 'numeric' }); // Get the current month in the format "Month-Year" (e.g., "May-2023")

                const newMessage =
                    latestInspiration.scheduleMonth === currentMonth
                        ? {
                            message: `Your have pinned an inspiration for ${latestInspiration.location} on ${latestInspiration.scheduleMonth}, Some celebrations are taking place in the city center this month. Please plan accordingly.`,
                            timestamp: new Date().toISOString(),
                            imageIconUrl: inspireicon,
                        }
                        : {
                            message: `Your have pinned an inspiration for ${latestInspiration.location} on ${latestInspiration.scheduleMonth}.`,
                            timestamp: new Date().toISOString(),
                            imageIconUrl: inspireicon,
                        };

                dispatch(addInspMessage(newMessage));
            }
            if (pickupDropList && pickupDropList.length > 0) {
                dispatch(
                    addPickMessage({
                        message: "New offer launched!!! Get a free travel-size bottle of your favorite liquor with the purchase of any full-sized bottle from brands like Johnnie Walker, Jack Daniels, and Grey Goose.",
                        timestamp: new Date().toISOString(),
                        imageIconUrl: offericon,
                    })
                );

                const latestpickupDropList = pickupDropList[pickupDropList.length - 1];
                const today = new Date();
                const newMessage =
                    latestpickupDropList.scheduleDate === today.toISOString().slice(0, 10)
                        ? {
                            message: `Your have pinned a ${latestpickupDropList.terminal} on ${latestpickupDropList.scheduleDate} at ${latestpickupDropList.time}. Please plan accordingly.`,
                            timestamp: new Date().toISOString(),
                            imageIconUrl: pickupdropicon,
                        }
                        : {
                            message: `Your have pinned a ${latestpickupDropList.terminal} on ${latestpickupDropList.scheduleDate} at ${latestpickupDropList.time}. Please plan accordingly.`,
                            timestamp: new Date().toISOString(),
                            imageIconUrl: pickupdropicon,
                        };

                dispatch(addPickMessage(newMessage));
            }



        }, 300000);
        return () => clearInterval(intervalId);
    }, [flightList]);

    const renderMessage = (message, index) => {
        const timestamp = new Date(message.timestamp);
        const now = new Date();
        const diffInMs = now - timestamp;
        const diffInMin = Math.floor(diffInMs / 1000 / 60);

        const handleRemoveMessage = () => {
            dispatch(removeMessage(index));
            dispatch(removeInspMessage(index));
            dispatch(removePickMessage(index));
        };

        return (
            <div key={index} className="render-message-notification">
                <div className="message-close">
                    <i className="pi pi-times" onClick={handleRemoveMessage}></i>
                </div>
                <div className="noti-image-text-wrap">
                    <div className="notification-avatar">
                        {message.imageIconUrl && (
                            <img src={message.imageIconUrl} alt="Offer icon" className="message-icon" />
                        )}
                    </div>
                    <div>
                        <p className="message">{message.message}</p>
                        <small className="message-time">{diffInMin} Min ago</small>
                    </div>
                </div>
                {index < (notification.length + inspnotification.length + picknotification.length) - 1 && <Divider />}
            </div>
        );
    };



    const handleShowAll = () => {
        setShowAll(prevState => !prevState);
    };


    const handleCloseOverlay = () => {
        op.current.hide();
        dispatch(clearMessages());
    };
    const totalCount = notification.length + inspnotification.length + picknotification.length;
    return (
        <Navbar>
            <Container>
                <Container>
                </Container>
                <Navbar.Collapse className="justify-content-end hoverClass">
                    <Navbar.Text>
                        <img src={bellicon} alt="Notification" onClick={(e) => op.current.toggle(e)} />
                        <span className='header-cart__count'>{totalCount}</span>


                    </Navbar.Text>
                </Navbar.Collapse>
            </Container>
            <div className="overlay-wrapper">
                <OverlayPanel ref={op} className="notification-overlay">
                    {renderedMessages && renderedMessages.length > 0 && renderedMessages.map(renderMessage)}
                    {(notification.length + inspnotification.length + picknotification.length) > 3 && (
                        <div className="show-all">
                            <a href="#" onClick={handleShowAll}>
                                {showAll ? "Show less" : "All notifications"}
                            </a>
                        </div>
                    )}


                </OverlayPanel>
            </div>
        </Navbar>
    );
};






const mapStateToProps = (state) => {
    return {
        notification: state.messages.notification,
        inspnotification: state.inspirationMessages.inspnotification,
        picknotification: state.pickMessages.picknotification
    };
};

export default connect(mapStateToProps)(Notification);
