import "./footer.scss";
//import logo from "../../layout/images/QR_Logo.png";
import logo from "assets/images/cial_logo-transformed.png"

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer__top">
        <div className="container">
          <div className="row g-4">
            <div className="col-xl-3 col-lg-4 col-md-6">
              <div className="footer__logo mb-2">
                {/* To be changed */}
                <img src={logo} alt="iAirport" title="iAirport" width={120} />
              </div>
              <p>Whether you’re transferring, arriving or departing, Cochin International Airport offers seemingly endless shopping, dining and relaxation. As of 2022, the Cochin International Airport caters to 61.8% of the total air passenger movement in Kerala. </p>
            </div>
            <div className="col-xl-3 col-lg-4 col-md-6">
              <h4>Extra Links</h4>
              <ul className="extra-links">
                <li className="extra-links__item"><a>About Us</a></li>
                <li className="extra-links__item"><a>Contact</a></li>
                <li className="extra-links__item"><a>Services</a></li>
                <li className="extra-links__item"><a>Sitemap</a></li>
                <li className="extra-links__item"><a>Team</a></li>
                <li className="extra-links__item"><a>Privacy Policy</a></li>
                <li className="extra-links__item"><a>News</a></li>
                <li className="extra-links__item"><a>Accessibility statement</a></li>
                <li className="extra-links__item"><a>Our Life</a></li>
                <li className="extra-links__item"><a>FAQs</a></li>
                <li className="extra-links__item"><a>Careers</a></li>
                <li className="extra-links__item"><a>Terms of use</a></li>
              </ul>
            </div>
            <div className="col-xl-3 col-lg-4 col-md-6">
              <h4>Recent News</h4>
              <ul className="news-links">
    <li><a href="https://www.cial.aero/News-Updates/URL">IHCL to invest INR 100 crores in Cochin Airport’s 5-star hotel.</a></li>
    <li><a href="https://www.cial.aero/news-Updates/summerschedule#:~:text=Cochin%20International%20Airport%20Ltd%20(CIAL,for%20the%20ongoing%20winter%20schedule.">CIAL announces summer schedule: 1484 services weekly.</a></li>
    <li><a href="https://www.cial.aero/News-Updates/Kochi-welcomes-Akasa#:~:text=Kochi%20topped%20the%20list%20of,cherishes%20the%20collaboration%20with%20Akasa.">Kochi among Akasa’s priority list of 4 airports.</a></li>
    {/* <li><a href="https://dohahamadairport.com/press-releases/news/hamad-international-airport-and-qatar-duty-free-host-ramadan-festivities">Hamad International Airport and Qatar Duty Free Host Ramadan Festivities.</a></li> */}
  </ul>

            </div>
            <div className="col-xl-3 col-lg-4 col-md-6">
              <h4>Subscribe and Follow</h4>
              <div className="subscribe d-flex mb-3">
                <input type="text" className='form-control' placeholder="Enter your email ID" />
                <button type="button" className="l-btn l-btn--icon"><i className="pi pi-arrow-right"></i></button>
              </div>
              <ul className="d-flex footer-social">
                <li className="footer-social__item"><a href="#"><i className="pi pi-facebook"></i></a></li>
                <li className="footer-social__item"><a href="#"><i className="pi pi-instagram"></i></a></li>
                <li className="footer-social__item"><a href="#"><i className="pi pi-twitter"></i></a></li>
                <li className="footer-social__item"><a href="#"><i className="pi pi-linkedin"></i></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div className="footer__bottom">
        <div className="container">
          <div className="footer__block">
            <div className="footer__copyright">
              © 2023 IBS Software. All Rights Reserved.
            </div>
            <ul className="footer-links">
              <li className="footer-links__item"><a>Privacy Policy</a></li>
              <li className="footer-links__item"><a>Terms of Use</a></li>
              <li className="footer-links__item"><a>Sitemap</a></li>
              <li className="footer-links__item"><a>Cookies Settings</a></li>
              <li className="footer-links__item"><a>Modern Slavery Statement</a></li>
            </ul>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default Footer;