import React, { useState } from 'react';
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import { Checkbox } from 'primereact/checkbox';
import './deleteConfirmation.css';
import { useSelector } from 'react-redux';

const DeletePinConfirmation = ({ showModal, hideModal, confirmModal, onCancel, itemIndex, itemKey, type, details, message }) => {
  const [isChecked, setIsChecked] = useState(false); // state to hold checkbox value

  const handleCheckboxChange = (e) => {
    setIsChecked(e.target.checked);
  };

  const flightInCart = useSelector((state) => state.cart.cart.flight);
  const pickupInCart = useSelector((state) => state.cart.cart.pickupDrop);
  const inspirationInCart = useSelector((state) => state.cart.cart.inspiration);

  let cart = false;

  if (type === 'flight' && flightInCart[itemKey]) {
    cart = true;
  } else if (type === 'pickupDrop' && pickupInCart[itemKey]) {
    cart = true;
  } else if (type === 'inspiration' && inspirationInCart[itemKey]) {
    cart = true;
  }

  const handleConfirm = () => {
    if (cart) {
      if (isChecked) {
        confirmModal(itemIndex, itemKey, type, details); // call handleDelete
      } else {
        onCancel(itemIndex, itemKey, type, details); // call handleMove
      }
    } else {
      confirmModal(itemIndex, itemKey, type, details); // call handleDelete
    }

    hideModal();
  };

  const footer = (
    <>
      <Button label="Cancel" className="p-button-text" onClick={hideModal} />
      <Button label="Delete" className="p-button-danger" onClick={handleConfirm} />
    </>
  );

  return (
    <Dialog header="Delete Confirmation" visible={showModal} onHide={hideModal} footer={footer} modal>
      <div className="alert alert-danger">{message}'{itemKey}'?</div>
      {cart ? (
        <div className="p-d-flex p-ai-center">
          <Checkbox inputId="checkbox" value={isChecked} onChange={handleCheckboxChange} />
          <label htmlFor="checkbox" className="p-checkbox-label">
            Delete items from cart for '{itemKey}'
          </label>
        </div>
      ) : null}
    </Dialog>
  );
};

export default DeletePinConfirmation;
