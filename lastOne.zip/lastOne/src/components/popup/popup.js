import React, { useState, useEffect } from "react";
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import { Checkbox } from 'primereact/checkbox';
import { useDispatch, useSelector } from 'react-redux';
import { getPinFlight, getPinPickupDrop, getPinInspiration } from '../../redux/features/pingFlight/pinAction';
import './popupstyle.css'

const Popup = ({ showPopup }) => {
  const [show, setShow] = useState(true);
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [checked, setChecked] = useState(false);
  const dispatch = useDispatch()

  const handleClose = () => {
    setShow(false);
    showPopup(false);
  }
  const handleSubmit = () => {
    // console.log(`Email: ${email}, Phone: ${phone}`);
    handleClose();
  };
  const { userInfo } = useSelector((state) => state.auth);

  useEffect(() => {
    if (userInfo) {
      setEmail(userInfo.email);
      setPhone(userInfo.phoneNumber);
    }
  }, [userInfo, dispatch]);

  const dialogFooter = (
    <div>
      <Button label="Cancel" icon="pi pi-times" className="p-button-text" onClick={handleClose} />
      <Button label="Submit" icon="pi pi-check" className="p-button-primary" onClick={handleSubmit} />
    </div>
  );

  return (
    <Dialog header="Receive Flight Updates" visible={show} onHide={handleClose} footer={dialogFooter} className="my-custom-dialog">
      <div className="p-fluid">
        <div className="p-field">
          <label htmlFor="email">Email Address</label>
          <InputText id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        </div>
        <br />
        <div className="p-field">
          <label htmlFor="phone">Phone Number</label>
          <InputText id="phone" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} />
        </div>
        <br />
        <div className="p-field-checkbox">
          <Checkbox inputId="confirm-notify" name="confirmnotify" value="confirm" checked={checked} onChange={() => setChecked(!checked)} />
          <label htmlFor="confirm-notify">By clicking submit, I confirm that I have read and accepted the general <a className="terms-of-use" href="#" style={{textDecoration: "underline"}}>terms and conditions</a> in terms of use and Privacy statement.
</label>
        </div>
      </div>
    </Dialog>
  );
};

export default Popup;
