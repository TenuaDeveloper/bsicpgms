import React from 'react';
import { Dialog } from 'primereact/dialog';
import { Dropdown } from 'primereact/dropdown';
import { InputNumber } from 'primereact/inputnumber'; 
import { RadioButton } from 'primereact/radiobutton';
import { Calendar } from 'primereact/calendar';           
import moment from 'moment';
import './popup.css';
import { Button } from 'primereact/button';
import fields from './fields.json';
import additionalFields from './formfields.json'; 
import { useSelector, useDispatch } from 'react-redux';
import { useState, useEffect } from 'react';
import PhoneInput from 'react-phone-number-input';
import 'react-phone-number-input/style.css';
import {dynamicActions} from '../../redux/features/purchasedItem/dynamicPriceAction'
import { CSSTransition } from 'react-transition-group';
import { ToastContainer, toast } from "react-toastify";
import { InputText } from 'primereact/inputtext';
import { fetchWishList, deleteWishList, addToWishList, deleteFromWishList, getWishList } from '../../redux/features/wishlist/wishlistAction';
import { connect } from "react-redux";


const PopupNew = ({ visible,selectedCard, onHide,handleYes, addToCart, changeCartPopupStatus ,showSavedtoCart=true,iswishlisted, userInfo,preStoredData}) => {
  // console.log(selectedCard.category)
  // console.log(selectedCard)
  
  const { id, serviceName, images, description, serviceItemType, currency, unitPrice, offerPrice, quantity } = selectedCard || {};
  //const options = fields.find((field) => field.category === serviceItemType.id)?.fields;//serviceItemType.id
  const options = fields.find((field) => String(field.category).includes(selectedCard.category))?.fields
  const additionalOptions = additionalFields.find((field) => String(field.category).includes(selectedCard.category))?.fields
  //const additionalOptions = additionalFields.find((field) => field.category === serviceItemType.id)?.fields;
  const [totalPrice, setTotalPrice] = useState("offerPrice || unitPrice");
  const [formData, setFormData] = useState(preStoredData ? preStoredData : '' );
  const [formErrors, setFormErrors] = useState({});
  const [errorMessage, setErrorMessage] = useState("");
  const [guestNames, setGuestNames] = useState([]);
  const [childNames, setChildNames] = useState([]);
  const [formState, setFormState] = useState({});
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [name, setName] = useState("");
  const [wishlistSelectedProduct, setWishlistSelectedProduct] = useState([]);
  const [favSelectedProduct, setFavSelectedProduct] = useState([]);
  const [wishicon, setWishicon] = useState(iswishlisted ? true : false);
  
  const dispatch = useDispatch();

  useEffect(() => {
    if (userInfo) {
      // console.log(userInfo)
      setEmail(userInfo.email);
      setPhone(userInfo.phoneNumber);
      setName(userInfo.username);
    }
  }, [userInfo, dispatch]);

  const handleClick = () => {
    handleYes(formData);
    // console.log(formData,"formdta")
    onHide();
  };
  function handleAddToWishList(wishproduct) {
    let data = wishlistSelectedProduct;
    const ifExists = wishlistSelectedProduct.find(item => item == wishproduct.id);
    if (!ifExists) {
      data.push(wishproduct.id)
      setWishlistSelectedProduct(data);
    } else {
      const index = favSelectedProduct.indexOf(wishproduct.id);
      data.splice(index, 1);
      setWishlistSelectedProduct(data)
    }

    //   console.log("wish values : ", wishproduct.id)
    //   console.log("isAdded : ", isAdded)
    // dispatch(getWishList({token: userInfo.accessToken}))
    let inputData = { 'serviceId': wishproduct.id };
    if (!ifExists) {
      if (userInfo) {
        dispatch(fetchWishList(inputData));
        //  console.log("input data of wishlist is", inputData)
        dispatch(getWishList({ token: userInfo.accessToken }))
      }
      else {
        dispatch(addToWishList(wishproduct));
        //  console.log("wishproduct is", wishproduct)
      }
      setWishicon(true)

    } else {
      if (userInfo) {
        dispatch(deleteWishList(wishproduct.id));
        //  console.log("input data of delete wishlist is", wishproduct.id)
        dispatch(getWishList({ token: userInfo.accessToken }))
      } else {
        dispatch(deleteFromWishList(wishproduct.id));
        //  console.log("delete wishlist is", wishproduct.id)
      }
      setWishicon(false)

    }
  }
  const calculatePrice = () => {
    let totalPrice = 0;
    let totalPriceGet
    if (offerPrice) {
       totalPrice = offerPrice;
      } else {
        totalPrice = unitPrice;
       }
     if (selectedCard.category === 'Lounge') {
          //  console.log(formData);
           let numGuests = 0;
           let numChildren = 0;
           options.forEach((option) => {
            if (option.name === "num_guests") {
             numGuests = parseInt(formData[option.name]) || 0;
            } else if (option.name === "num_children") {
             numChildren = parseInt(formData[option.name]) || 0;
            }
           });
           const totalNumGuests = numGuests + numChildren * 0.5;
           totalPrice *= totalNumGuests;
           totalPrice = totalPrice.toFixed(0);
           document.querySelector('.pop-price-total').textContent = ' '+currency + ' '+ totalPrice;
           setFormData({ ...formData, totalPrice: totalPrice,numitems: 1 })
           setFormState({"Sold by":selectedCard.seller, "Date of visit": `${formData.DateofVisit.toLocaleString('en-US', { year: 'numeric', month: '2-digit', day: '2-digit', hour: 'numeric', minute: '2-digit' })}`})
           
          //  console.log(formState)
          }
          else if (selectedCard.category === 'Passenger Service') {
            // console.log(formData);
            let numGuests = 0;
            options.forEach((option) => {
             if (option.name === "num_guests") {
              numGuests = parseInt(formData[option.name]) || 0;
             }
            });
            const totalNumGuests = numGuests ;
            totalPrice *= totalNumGuests;
            totalPrice = totalPrice.toFixed(0);
            document.querySelector('.pop-price-total').textContent = ' '+currency + ' '+ totalPrice;
            setFormData({ ...formData, totalPrice: totalPrice,numitems: 1 })
            setFormState({"Sold by":selectedCard.seller, "Date of visit": `${formData.DateofVisit.toLocaleString('en-US', { year: 'numeric', month: '2-digit', day: '2-digit', hour: 'numeric', minute: '2-digit' })}`})
            
           //  console.log(formState)
           }
          else if (selectedCard.category === 'Parking') {
            let fromTime;
            let toTime;
             options.forEach((option) => {
             if (option.name === "Arrival_Date") {
             var startDateTime = moment(formData[option.name], "YYYY-MM-DDTHH:mm").toDate();
            //  console.log(startDateTime)
              fromTime = startDateTime.getTime();
             } else if (option.name === "Departure_Date") {
             var  endDateTime = moment(formData[option.name], "YYYY-MM-DDTHH:mm").toDate();
              toTime = endDateTime.getTime();
             }
            // console.log(fromTime, toTime, serviceName);
            // const serviceName=serviceName;
             dispatch(dynamicActions.fetchDynamicPrice({ fromTime, toTime, serviceName }))
             .then(result => {
              totalPrice = result.payload.totalPrice;
              // console.log("dynamic price is: ",totalPrice)
             const displayPrice = isNaN(totalPrice) ? (offerPrice ? offerPrice : unitPrice) : totalPrice;
            document.querySelector('.pop-price-total').textContent = ' '+currency + ' '+ displayPrice.toFixed(0);
            setFormData({ ...formData, totalPrice: displayPrice.toFixed(0),numitems: 1 })
            // console.log(formData,"formdata")
             setFormState({ "Sold by":selectedCard.seller, "Date & Time": `${formData.Arrival_Date.toLocaleString('en-US', { year: 'numeric', month: '2-digit', day: '2-digit', hour: 'numeric', minute: '2-digit' })} to ${formData.Departure_Date.toLocaleString('en-US', { year: 'numeric', month: '2-digit', day: '2-digit', hour: 'numeric', minute: '2-digit' })}`})
            // setFormState({ Total : displayPrice.toFixed(0) , "Date & Time": `${startDateTime} to ${endDateTime}`})
           
            // console.log(formState,"formstate")
              })
             .catch((error) => {
             console.error(error);
             });
             });
            
            }
        
          else if (selectedCard.category === 'Services') {
               options.forEach((option) => {          
                var preferredDateTimeString = formData[option.name];          
                var preferredDateTime = new Date(preferredDateTimeString);         
                if (preferredDateTime.getDay() === 0) {
                 totalPrice *= 1.1;
                }
               });
               document.querySelector('.pop-price-total').textContent = ' '+currency + ' '+totalPrice 
               setFormData({ ...formData, totalPrice: totalPrice ,numitems: 1})
              //  console.log(formData.preferred_date_time,"formData.preferred_date_time")
               setFormState({"Sold by":selectedCard.seller, "Date of visit": `${formData.preferred_date_time.toLocaleString('en-US', { year: 'numeric', month: '2-digit', day: '2-digit', hour: 'numeric', minute: '2-digit' })}`})
              //  console.log(formState,"formstate")
               return totalPrice;
              }
              // totalPrice = totalPrice.toFixed(2);  
                       
             };
    
const handleCheckPrice = () => {
              const errors = {};
              const optionsErrors = validateFields(options, formData);
              Object.assign(errors, optionsErrors);
              if (Object.keys(errors).length === 0) {
                const updatedPrice = calculatePrice(totalPrice);
                // console.log(`Total price: ${updatedPrice}`);
                setTotalPrice(updatedPrice);
                //setCurrentScreen(currentScreen + 1);
              } else {
              setFormErrors(errors);
              setCurrentScreen(currentScreen );
              }
             
                };
  
 const validateFields = (options, formData) => {
                  const errors = {};
                  options?.forEach((option) => {
                  const { label, required, validation } = option;
                  const value = formData[option.name];
                  // Check required fields
                  if (required && (!value )) {
                  errors[option.name] = `This field is required`;
                  }
                  // Check validation rules
                  if (value && validation) {
                  switch (validation) {
                  case 'numeric':
                  if (isNaN(value)) {
                  errors[option.name] = `please enter valid${label}`;
                  }
                  break;
                  case 'email':
                  if (!/\S+@\S+\.\S+/.test(value)) {
                  errors[option.name] = `please enter valid${label} address`;
                  }
                  break;
                  case 'mobile':
                  if (!/^\d{10}$/.test(value)) {
                  errors[option.name] = `please enter valid${label}`;
                  }
                  break;
                  case 'alphanumeric':
                  if (!/^[a-zA-Z0-9]*$/.test(value)) {
                  errors[option.name] = `please enter valid${label}`;
                  }
                  break;
                  case 'string':
                  if (!/^[a-zA-Z ]*$/.test(value)) {
                  errors[option.name] = `please enter valid${label}`;
                  }
                  break;
                  default:
                  break;
                  }
                  }
                  });
                  return errors;
                 }
  const handleAddToCart = (event) => {
                  handleCheckPrice();
                  changeCartPopupStatus();
                  const errors = {};
                  const additionalErrors = validateFields(additionalOptions, formData);
                  const optionsErrors = validateFields(options, formData);
                  Object.assign(errors, additionalErrors, optionsErrors);
                  if (Object.keys(errors).length === 0) {
                
                //  setFormState({ ...formData, points: selectedCard.loyaltyPoints})
                     // console.log(formState,"formstate");
                     // console.log(formData,"formdata");
                     const cartdata = JSON.stringify(formState); 
                     // console.log(cartdata,"cartdata")
                 addToCart(formData.numitems,formState);
                 onHide();
                 toast.success(`Added to the cart `);
                 //  sessionStorage.setItem('numItems', parseInt(formData.num_items));
                 //  const passengerName = document.getElementsByName('PassengerName')[0];
                 //  if(passengerName!=null){
                 //  addToCart(parseInt(formData.num_items));
                 //  }
                 //  onHide();
                   } 
                  else {
                  setFormErrors(errors);
                  }
                 };
  const serviceMapping = {
    'Short Term Parking': ['Valet Parking',"INR 50"],
        'Al Mourjan Business Lounge': ['Al Safwa First Lounge',"INR 100"],
      };  
      
  
  const handleMobileInput = data => {
        setFormData({ ...formData, mobileno: data })
        setPhone(data)
        // console.log(formData)
      }
 
      const handleChange = (event) => {
        // handleCheckPrice();
      //   setEmail(event.target.value)
      //   setPhone(event.target.value)
      //   setName(event.target.value)
        const { name, value } = event.target;
        if (event.target.name === 'EmailAddress') { setEmail(event.target.value); }
        if (event.target.name === 'PassengerName') { setName(event.target.value); }
        if (event.target.nodeName === 'SELECT') {
          const selectedOption = event.target.options[event.target.selectedIndex];
          const selectedOptionName = selectedOption.getAttribute('name');
          setFormData((prevData) => ({ ...prevData, [selectedOptionName]: value }));
        //  setFormState({ ...formData, points: selectedCard.loyaltyPoints})
          setFormErrors((prevErrors) => ({ ...prevErrors, [selectedOptionName]: '' }));
          } else {
          setFormData((prevData) => ({ ...prevData, [name]: value }));
          // setFormState({ ...formData, points: selectedCard.loyaltyPoints})
          setFormErrors((prevErrors) => ({ ...prevErrors, [name]: '' }));
          }
          };
   
    const handleCheckPriceButton= () => {
      handleCheckPrice();
            // serviceItemType.serviceType !== "Parking" ?(
            // document.querySelector('.pop-price-total').textContent = currency + totalPrice
            // :  ("")
           }
  const [currentScreen, setCurrentScreen] = useState(1);
  const handleBackButtonClick = () => {
      setCurrentScreen(currentScreen - 1);
  };
  const handleGoButtonClick = () => {
  
  const errors = {};
  const optionsErrors = validateFields(options, formData);
  Object.assign(errors, optionsErrors);
  if (Object.keys(errors).length === 0) {
    const updatedPrice = calculatePrice(totalPrice);
    // console.log(`Total price: ${updatedPrice}`);
    setTotalPrice(updatedPrice);
    setCurrentScreen(currentScreen + 1);
  } else {
  setFormErrors(errors);
  }
  
   };
   

   const renderScreen1 = () => {
    return (
   
    <>
   
   <div className="container-fluid ">
   <div className="row">
   <div className="col-md-5 ">
       <div className='pop-image'>
       <img src={images[0]} className='park-screen-image'></img>
       <div className='booking-details-container'>
       <div className='feedback-header'>Book you visit</div>
       <div className='options-container'>
       
       {options && (
                <div className='cartpopfields-container '>
                  {options.map((option, index) => (
                    <div key={index} className="form-form-group">
                      <label>{option.label}{option.required && <span className="text-danger">*</span>}</label>
                      {option.type === 'select' ? (
                        <Dropdown
                                   name={option.name}                        
                                   options={option.options}                        
                                   value={formData[option.name] || ''}                        
                                   onChange={handleChange}                        
                                   optionLabel="label"                        
                                   placeholder=""
                        
                                  />
                      ) 
                     
                        :option.type === 'number' ? (
                          <InputNumber
               value={formData[option.name]}
               onValueChange={(e) => handleChange({ target: { name: option.name, value: e.value } })}
               min={option.min}
               max={option.max}
               mode="decimal"
               name={option.name}
               showButtons
              />
                          ) : option.type === 'datetime-local' ? (
                            
                            <Calendar                            
                            onChange={(e) =>handleChange({ target: { name: option.name, value: e.value }})}
                                      min={option.min}                            
                                      max={option.max}                            
                                      mode="decimal"                            
                                      name={option.name} 
                                      value={formData[option.name]}
                                      showIcon                            
                                      showTime                            
                                      hourFormat="24"                           
                                     />
                         ) : (
                        <input type={option.type} name={option.name} className="cartpopform-control"  min={option.min} max={option.max} onChange={handleChange} value={formData[option.name] || ''} />
                      )}
                       {formErrors[option.name] && (
   <div className="formfield-errors">{formErrors[option.name]}</div>
   )}
                    </div>
                  ))}
                </div>
              )}
                          <div className='cartpopfields-container-additional'>
              {formData.num_guests && (
<div >
 {[...Array(parseInt(formData.num_guests))].map((_, i) => (
<div key={i} className="form-form-group ">
<label htmlFor={`guest_name_${i}`}>Guest Name {i + 1}:</label>
<input
 type="text"
 className="form-form-control"
 id={`guest_name_${i}`}
 name={`guest_name_${i}`}
 value={guestNames[i]}
 onChange={(e) =>
 setGuestNames((prevNames) =>
 prevNames.map((name, index) =>
 index === i ? e.target.value : name
 )
 )
 }
 />
</div>
 ))}
</div>
)}



{formData.num_children && (
<div>
 {[...Array(parseInt(formData.num_children))].map((_, i) => (
<div key={i} className="form-form-group">
<label htmlFor={`child_name_${i}`}>Child Name {i + 1}:</label>
<input
 type="text"
 className="form-form-control"
 id={`child_name_${i}`}
 name={`child_name_${i}`}
 value={childNames[i]}
 onChange={(e) =>
 setChildNames((prevNames) =>
 prevNames.map((name, index) =>
 index === i ? e.target.value : name
 )
 )
 }
 />
</div>
 ))}
</div>
)}
</div>  
       </div>
       <div className='park-total-container'>
       <button className="cartpopbottom-buttons-price" onClick={handleCheckPriceButton}>
            Get Price
        </button>
        <div className='park-screen1-total'>
      <div className="park-screen1-total-link" > Total : </div>
      {errorMessage ? (
  <div className="error-message">{errorMessage}</div>
) : (<div className="pop-price-total"></div>
)}
      </div></div>
       </div>
       
   </div>
   
   </div>
   <div className="col-md-7">
   <h4 className="cartpop-header">{serviceName}</h4>
   <div className="cartpop-desc-sub">{selectedCard.description}
   {selectedCard.category==="Lounge"&& <p>The Clubhouse features graceful elegance with soothing lighting and luxurious furnishing. Making you feel right at home, indulge in something delicious from the a la carte menu or make your way to the bar for a quick tipple, choose from a range of premium drinks and cocktails. If you’re in a playful mood, head to the entertainment zone for a quick game of pool! Showers available to help freshen you up, luggage storage available, compliments of the house.  
</p>
}
{selectedCard.category==="Parking"&& <p>Parking facilities are covered and provided with professional security and electronic surveillance. The facilities are specifically designed for air travelers in order to ensure comfortable hassle-free and worry-free travel. It is ideally located at HIA at just 500 meters from the airport terminal</p>
}
   </div>
   
   {selectedCard.category==="Lounge"&& <div>
       <div className='screen1-subheader'> LOUNGE FEATURES</div>{selectedCard.features?(<p className="cartpop-desc-sub">{selectedCard.features}</p>):("(Bar (Charges may apply), Charging Station, Draught Beer, Flight Information, Food & Beverage, Lounge Bay, Shower Facilities (Charges may apply), Telephone, Wi-Fi")}
       
       </div>
   }
   {selectedCard.category==="Parking"&& <div>
       <div className='screen1-subheader'> PARKING FEATURES</div>
       {selectedCard.features?(<p className="cartpop-desc-sub">{selectedCard.features}</p>):("Dedicated area for park and fly with enhanced Security Features, Additional signages at multi-level car parking entry for visibility and direction ,No additional documentation and form filling is required.,parking zones are laid out keeping in mind passenger ease and convenience. All parking zones are located between 100 to 200 meters from the passenger terminal building, at a short, walking distance.")}
       </div>
   }
   {selectedCard.category==="Services"&& <div>
       <div className='screen1-subheader'>FEATURES</div>
       {selectedCard.features?(<p className="cartpop-desc-sub">{selectedCard.features}</p>):("Relaxing Atmosphere: Create a serene and calming environment with soothing music, soft lighting, and comfortable seating to help passengers unwind and destress. Offer a variety of massage techniques such as Swedish, deep tissue, or aromatherapy massages to provide relaxation and relieve muscle tension. Provide rejuvenating facial treatments that cleanse, exfoliate, and nourish the skin, leaving passengers feeling refreshed and revitalized. Offer express or full-service nail treatments, including manicures and pedicures, to give passengers well-groomed nails and a pampering experience. Provide quick and targeted treatments such as chair massages, hand or foot massages, or mini facials for passengers with limited time between flights.")}
       </div>
   }
    {selectedCard.category==="Passenger Service"&& <div>
       <div className='screen1-subheader'>FEATURES</div>
       {selectedCard.features?(<p className="cartpop-desc-sub">{selectedCard.features}</p>):("Concierge Services: Provide dedicated concierge services to assist passengers with travel arrangements, including booking accommodations, transportation, and local activities. Offer a help desk or information kiosks where passengers can receive up-to-date flight information, gate assignments, and assistance with itinerary changes or rebookings. Provide priority boarding for passengers with specific needs, such as families with young children, elderly passengers, or passengers with disabilities. Offer travel insurance services to provide passengers with coverage for medical emergencies, trip cancellations, or lost baggage during their journey. Have a dedicated lost and found service to assist passengers in locating and retrieving their lost belongings within the airport premises.")}
       </div>
   }
   {selectedCard.category==="Lounge"&& 
   <div>
       <div className='screen1-subheader'> OPENING HOURS</div>
       <p>0500 - 0800; 1400-2230 daily</p>
       <div className='screen1-subheader'> LOCATION</div>
       <p>A-Concourse, above boarding gates A4 and A5, International Airport</p>
       </div>
   }

<div className='screen1-subheader'> CONTACT</div>
       <p>Email: iairport@network.com</p>
   </div>
  
   
   
   </div>
   </div>
    </>
   
    );
   
    };
   
   
   
    const renderScreen2 = () => {
   
    return (
   
    <>
   
   <div className="container-fluid ">
   <div className="row">
   <div className="col-md-2 ">
      <img src={images[0]} className='screen2-image'></img>
   </div>
   <div className="col-md-10">
   <h4 className="cartpop-header">{serviceName}</h4>
   <h4 className="pop-spec-title">{selectedCard.features}</h4>
    </div>
    <div className='contact-details'>
    Contact Details
    </div>
   
    <div className='cartpopfields-container'>
           {additionalOptions?.map((option, index) => (
           <div key={index} className="form-form-group">
             <label> {option.label}:
             {option.required && <span className="text-danger">*</span>}</label>
             {option.type === 'select' ? (
             <select name={option.name} className="form-form-control" onChange={handleChange}>
               <option value="" disabled selected hidden></option>
               {option.options.map((value, index) => (
               <option key={index} value={value} 
               name={option.name}className="form-form-control" onChange={handleChange} >
                 {value}
                 </option>
                 ))}
                 </select>
                 ) : option.type === 'radio' ? (
                 <div>
                   {option.options.map((value, index) => (
                   <div key={index}>
                     <input type="radio" name={option.name} onChange={handleChange} value={formData[option.name] || value} />
                     <label>{value}</label>
                     </div>
                     ))}
                     {/* {option.type === 'radio' && 
                     ( <div> {option.options.map((value, index) => 
                     ( <div key={index}> 
                     <RadioButton inputId={`${option.name}-${value}`} name={option.name} value={formData[option.name] || value} onChange={handleChange} checked={formData[option.name] === value} /> 
                     <label>{value}</label> 
                     </div> ))} 
                     </div> )} */}
                     </div>
                      ):option.type === 'tel' ? (
                       <PhoneInput
                       
                       className='text-style'
                       name='mobileno'
                     value={phone}
                  
                       onChange={handleMobileInput} />
                       
        
                      ): option.type === 'email' ? (
                        <InputText type={option.type} name={option.name} className="form-form-control" onChange={handleChange} placeholder={userInfo && userInfo.email != null ? userInfo.email : ""} value={email} />
                        
         
                       ): option.name === 'PassengerName' ? (
                        <input type={option.type} name={option.name} className="form-form-control" onChange={handleChange} value={name} />
                        
         
                       ):(
                      <input type={option.type} name={option.name} className="form-form-control" onChange={handleChange} value={formData[option.name] || ''} />
                      )} 
                       {formErrors[option.name] && (
                       <div className="formfield-errors">{formErrors[option.name]}</div>
                       )}
                       </div>))}
                      </div> 
                      {selectedCard.serviceName=== "Short Term Parking" || selectedCard.serviceName==="Al Mourjan Business Lounge"? 
                    <div className='upgarding-status'>
                       <input type="checkbox" className='upgrading-checkbox'/>
                      <p >I would like to pay additional <b >{serviceMapping[selectedCard.serviceName][1]} and upgrade to 
                        
                        {" "}  {serviceMapping[selectedCard.serviceName][0]}
                        </b>
                        .
                      </p>
                      <button type="button"
                        class="upgrading-button"
                        onClick={handleClick}
                      >
                        Yes
                      </button>
                  
                      {/* <button type="button" class="btn-custom btn btn-sm btn-xs btn-secondary" style={{marginLeft: '10px'}}>No</button> */}
                    </div>: <></>
                    }       
   </div>
   </div>
   
    </>
   
    );
   
    };
   
    
    const headerScreen1 = (
      <div className='headerScreen1'>
      <h4 className="cartpop-headerScreen">{serviceName}</h4>
      </div>
       );
  const headerScreen2 = (
      <div className='headerScreen2'>
          {/* <div className='arrow-left' onClick={handleBackButtonClick}><i className="pi pi-arrow-left"></i></div>
          <p className='headerBackButton'onClick={handleBackButtonClick}> Back</p> */}
          {/* <div className='headerBackButton'  onClick={handleBackButtonClick}>
          <Button label='Back' icon="pi pi-arrow-left"/>
          </div> */}
          <div className='headerBackButton'  onClick={handleBackButtonClick}>
        <i className="pi pi-arrow-left" style={{marginTop:'4px',color:'black'}}></i>
        <div className='back-link'> Back</div> 
        </div>
          
      <h4 className="cartpop-headerScreen">Delivery Details</h4>
      </div>
       );     
       const footerScreen1 = (
        <div className='sreen1-footer'>
             <div className='save-button'>
            {/* <Button icon="pi pi-bookmark" label='Save For Later'/> */}

        {showSavedtoCart && <>{wishlistSelectedProduct && wishlistSelectedProduct.length > 0 && wishlistSelectedProduct.find(item => item == selectedCard.id) ?
        <Button label='Saved For Later' key={selectedCard.id}  onClick={() => handleAddToWishList(selectedCard)}icon="pi pi-bookmark-fill"/>:
        <Button label='Save For Later'  key={selectedCard.id} onClick={() => handleAddToWishList(selectedCard)} icon="pi pi-bookmark"/>}
        </>
        }
            </div>
            <div className='pop-cart-button'>
            <Button icon=" pi pi-shopping-bag" label='Add to cart' onClick={handleGoButtonClick}/>
            </div>
            
            
            </div>
        )
        const footerScreen2 = (
          <div className='screen2-footer'>
          <div className='sreen1-footer'>
              <div className='screen1-footer2'>
              <div className='pop-price-total'>
              Total Amount : <div className='pop-price-total'>{currency}&nbsp;{formData.totalPrice}</div>
          </div>
              </div>
          <div className='screen2-buttons'>
          <div className='save-button'>
            {/* <Button icon="pi pi-bookmark" label='Save For Later'/> */}

        {showSavedtoCart && <>{wishlistSelectedProduct && wishlistSelectedProduct.length > 0 && wishlistSelectedProduct.find(item => item == selectedCard.id) ?
        <Button label='Saved For Later' key={selectedCard.id}  onClick={() => handleAddToWishList(selectedCard)}icon="pi pi-bookmark-fill"/>:
        <Button label='Save For Later'  key={selectedCard.id} onClick={() => handleAddToWishList(selectedCard)} icon="pi pi-bookmark"/>}
        </>
        }
            </div>
          <div className='pop-cart-button'>
              <Button icon=" pi pi-shopping-bag" label='Done' onClick={handleAddToCart}/>
              <ToastContainer />
              </div>
              </div>
              
              
          
          </div>
      </div>
        //     <div>
        //     <div className='sreen1-footer'>
        //         <div className='screen1-footer2'>
        //         <div className='pop-price-total'>
        //         Total Amount : <div className='pop-price-total'>&nbsp;{currency}&nbsp;{formData.totalPrice}</div>
        //     </div>
        //         </div>
            
        //         <div className='save-button'>
        //     <Button icon="pi pi-bookmark" label='Save for later'/>
        //     </div>
        //     <div className='pop-cart-button'>
        //         <Button icon=" pi pi-shopping-bag" label='Done' onClick={handleAddToCart}/>
        //         <ToastContainer />
        //         </div>
                
                
            
        //     </div>
        // </div>
           
)

return (

  <Dialog header={currentScreen === 1 ? headerScreen1 : headerScreen2} footer={currentScreen === 1 ? footerScreen1 : footerScreen2} visible={true} style={{ width: '960px', height: '768px' }} className="popup-dialog-box" onHide={onHide}>
  <CSSTransition in={currentScreen === 1} timeout={200} classNames="screen-transition" unmountOnExit>
  <div>{renderScreen1()}</div>
  </CSSTransition>
  <CSSTransition in={currentScreen === 2} timeout={200} classNames="screen-transition" unmountOnExit>
  <div>{renderScreen2()}</div>
  </CSSTransition>
 
  </Dialog>
 
  );
 
 }
 
 
 
 const mapStateToProps = (state) => {
  return {
    userInfo: state.auth.userInfo
  };
};

 
 export default connect(mapStateToProps)(PopupNew);
   
   
        