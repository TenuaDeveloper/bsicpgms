import React from 'react';
import { useState, useEffect } from 'react';
import { Dialog } from 'primereact/dialog';
import { Galleria } from 'primereact/galleria';
import './popup.css';
import { Button } from 'primereact/button';
import { Rating } from 'primereact/rating';
import { SelectButton } from 'primereact/selectbutton';
import { Calendar } from 'primereact/calendar';
import { Dropdown } from 'primereact/dropdown';
import { InputNumber } from 'primereact/inputnumber'; 
import fields from './shoppingFields.json';



const deliveryOptions = [
 { label: 'Airport Terminal Gates', value: 'terminalgate' },
 { label: 'Arrival', value: 'arrival' },
 { label: 'Departure', value: 'departure' },
 { label: 'Pickup at store', value: 'store' }
];


const Pop = ({ product, visible,selectedCard, onHide, content }) => {
  // console.log(selectedCard)

  const { id, serviceName, images, description, serviceItemType, currency, unitPrice, offerPrice, quantity } = selectedCard || {};
const options = fields.find((field) => field.category ===selectedCard.category)?.fields;
const date= new Date(selectedCard.toDate);
const formattedDate = date.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }); // "May 31, 2023"
const [formState, setFormState] = useState(''); 
const handleChange = (event) => { 
    const { name, value } = event.target; 
    setFormState(prevState => ({ ...prevState, [name]: value })); }
    const gimages = images.map((image) => ({
       itemImageSrc: image,
       thumbnailImageSrc: image,
       alt: 'Description for Image',
      }));

 const responsiveOptions = [
     {
         breakpoint: '991px',
         numVisible: 4
     },
     {
         breakpoint: '767px',
         numVisible: 3
     },
     {
         breakpoint: '575px',
         numVisible: 1
     }
 ];


 const itemTemplate = (item) => {
     return <img src={item.itemImageSrc} alt={item.alt} style={{ width: '100%' }} />
 }

 const thumbnailTemplate = (item) => {
     return <img src={item.thumbnailImageSrc} alt={item.alt} />
 }





 const header = (
<div>
<h4 className="cartpop-main-title">{serviceName}</h4>
</div>
 );



 const footer = (
<div>
<button variant="secondary" className="cartpopbottom-buttons-close" onClick={onHide}>
 Close
</button>
<button variant="secondary" className="cartpopbottom-buttons">
 Add to Cart
</button>
</div>
 );





 return (
<Dialog header={header} footer={footer} visible={visible} style={{ width: '80vw', height: '150vw' }} onHide={onHide}>
<div className="container-fluid ">
<div className="row">
<div className="col-md-4 ">
    <div className='pop-image'>
<Galleria value={gimages} responsiveOptions={responsiveOptions} numVisible={5} style={{ maxWidth: '640px' }} 
             item={itemTemplate} thumbnail={thumbnailTemplate}/>
</div>
<div className='pop-terminal-details'>
<div className='pop-shop-header'>
    Merchant Details:<p className='pop-shop-title'>{selectedCard.seller}</p>
</div>
{selectedCard.departure_terminals},  Hamad International Airport
</div>

</div>
<div className="col-md-8">
<h4 className="pop-spec-title">{selectedCard.features}</h4>
                
                  <div className='product-rating'>
                  <Rating stars={4}value={4} readOnly cancel={false} />
                  <span className='total-ratings'>{selectedCard.rating} Ratings</span>                  
                </div>
                  <div className='pop-price-container'>
                  <div className='pop-price-block'>
                    {offerPrice?(<div>
                    <span className="pop-unit-price">{currency}{offerPrice}</span>
                    <span className="original-price">{currency}{unitPrice}</span>
                    {selectedCard.offerType==="percent"?(<span className="offer-percentage">you save 20%</span>):("")}
                    {/* <div className='offer-validity-box'> */}
                      <span className="offer-validity">Offer Valid Till {formattedDate}</span>
                      {/* </div> */}
                    </div>):(<span className="pop-unit-price">{currency}{unitPrice}</span>)
                   }
                    
                    
                  </div>
                  <span className='pop-tax-desc'>inclusive all taxes</span>
                  </div>
                 
                  <p className='pop-spec-title-sub'>Delivery Options</p>
                  <SelectButton
                  options={deliveryOptions}
                  value={formState[deliveryOptions]}
                  onChange={(e) => handleChange({ target: { name: "deliveryOptions", value: e.value } })}
                  optionLabel="label"
                  optionValue="value"
                  className='delivery-option'

                  /> 
                  <p className='pop-spec-title-sub'>Product Highlights</p>  
                   
                  <div className="pop-spec">
                    <ul className='p-list'>
                      {description.map((desc, index) => (
                      <li className='p-list-item' key={index}>
                        {desc}
                        </li>))}
                        </ul>
                        </div>
                    {options && (
                <div className='cartpopfields-container '>
                  {options.map((option, index) => (
                    <div key={index} className="form-form-group pop-option">
                      <label>{option.label}{option.required && <span className="text-danger">*</span>}</label>
                      {option.type === 'select' ? (
                        <Dropdown key={option.name} 
                        name={option.name} 
                        options={option.options} 
                        onChange={(e) => handleChange({ target: { name: option.name, value: e.value } })}
                        placeholder={option.label} 
                        value={formState[option.name]||option.options[0]}
                        />
                      )
                        :option.type === 'number' ? (
                          <InputNumber
                          value={formState[option.name]||1}
                          onChange={(e) => handleChange({ target: { name: option.name, value: e.value } })}
                          min={option.min}
                          max={option.max}
                          mode="decimal"
                          name={option.name}
                          showButtons
              />
                          ) : option.type === 'datetime-local' ? (
                            <Calendar    
                            onChange={(e) => 
                              handleChange({ target: { name: option.name, value: e.value }})}
                            
                                      min={option.min}                            
                                      max={option.max}                            
                                      mode="decimal"                            
                                      name={option.name}                            
                                      showIcon                            
                                      showTime                            
                                      hourFormat="24"                           
                                     />
                         ) : (
                        <input type={option.type} name={option.name} className="cartpopform-control"  min={option.min} max={option.max} onChange={handleChange} />
                      )}
       
                    </div>
                  ))}
                </div>
              )}
</div>
</div>
</div>
</Dialog>
 );
};



export default Pop;