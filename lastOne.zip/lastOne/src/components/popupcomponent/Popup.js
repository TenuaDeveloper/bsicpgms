import React from 'react';
import { Dialog } from 'primereact/dialog';
import { Dropdown } from 'primereact/dropdown';
import { InputNumber } from 'primereact/inputnumber'; 
import { RadioButton } from 'primereact/radiobutton';
import { Calendar } from 'primereact/calendar';           
import moment from 'moment';
import './popup.css';
import { Button } from 'primereact/button';
import fields from './fields.json';
import additionalFields from './formfields.json'; 
import { useSelector, useDispatch } from 'react-redux';
import { useState, useEffect } from 'react';
import PhoneInput from 'react-phone-number-input';
import 'react-phone-number-input/style.css';
import {dynamicActions} from '../../redux/features/purchasedItem/dynamicPriceAction'

const Popup = ({ visible,selectedCard, onHide,handleYes, content }) => {
const { id, serviceName, images, description, serviceItemType, currency, unitPrice, offerPrice, quantity } = selectedCard || {};
const options = fields.find((field) => field.category === serviceItemType.id)?.fields;//serviceItemType.id
const additionalOptions = additionalFields.find((field) => field.category === serviceItemType.id)?.fields;
const [totalPrice, setTotalPrice] = useState("offerPrice || unitPrice");
const [formData, setFormData] = useState('');
const [formErrors, setFormErrors] = useState({});
const [errorMessage, setErrorMessage] = useState("");
const [guestNames, setGuestNames] = useState([]);
const [childNames, setChildNames] = useState([]);
const dispatch = useDispatch();

const handleClick = () => {
  handleYes(formData);
  // console.log(formData);
  onHide();
};

const calculatePrice = () => {
  let totalPrice = 0;
  let totalPriceGet
  if (offerPrice) {
     totalPrice = offerPrice;
    } else {
      totalPrice = unitPrice;
     }
  
     if (serviceItemType.id === 2) {
         options.forEach((option) => {
          const numItems = formData[option.name];
          totalPrice *= numItems;
          totalPrice = totalPrice.toFixed(2);
          document.querySelector('.pop-price-total').textContent = currency + totalPrice
         });
         return totalPrice.toFixed(2);
        }
        else if (serviceItemType.id === 3) {
        //  console.log(formData);
         let numGuests = 0;
         let numChildren = 0;
         options.forEach((option) => {
          if (option.name === "num_guests") {
           numGuests = parseInt(formData[option.name]) || 0;
          } else if (option.name === "num_children") {
           numChildren = parseInt(formData[option.name]) || 0;
          }
         });
         const totalNumGuests = numGuests + numChildren * 0.5;
         totalPrice *= totalNumGuests;
         totalPrice = totalPrice.toFixed(2);
         document.querySelector('.pop-price-total').textContent = currency + totalPrice;
        }
        else if (serviceItemType.id === 1) {
          let fromTime;
          let toTime;
           options.forEach((option) => {
           if (option.name === "Arrival_Date") {
           var startDateTime = moment(formData[option.name], "YYYY-MM-DDTHH:mm").toDate();
          //  console.log(startDateTime)
            fromTime = startDateTime.getTime();
           } else if (option.name === "Departure_Date") {
           var  endDateTime = moment(formData[option.name], "YYYY-MM-DDTHH:mm").toDate();
            toTime = endDateTime.getTime();
           }
          // console.log(fromTime, toTime, serviceName);
          // const serviceName=serviceName;
           dispatch(dynamicActions.fetchDynamicPrice({ fromTime, toTime, serviceName }))
           .then(result => {
            totalPrice = result.payload.totalPrice;
            // console.log("dynamic price is: ",totalPrice)
           const displayPrice = isNaN(totalPrice) ? (offerPrice ? offerPrice : unitPrice) : totalPrice;
          document.querySelector('.pop-price-total').textContent = currency + displayPrice;
            })
           .catch((error) => {
          //  console.error(error);
           });
           });
          
          }
      
        else if (serviceItemType.id === 4) {
             options.forEach((option) => {          
              var preferredDateTimeString = formData[option.name];          
              var preferredDateTime = new Date(preferredDateTimeString);         
              if (preferredDateTime.getDay() === 0) {
               totalPrice *= 1.1;
              }
             });
          
            }
            // totalPrice = totalPrice.toFixed(2);  
            document.querySelector('.pop-price-total').textContent = currency + totalPrice        
            return totalPrice;         
           };
  
const handleCheckPrice = () => {
  const errors = {};
  const optionsErrors = validateFields(options, formData);
  Object.assign(errors, optionsErrors);
  if (Object.keys(errors).length === 0) {
    const updatedPrice = calculatePrice(totalPrice);
    // console.log(`Total price: ${updatedPrice}`);
    setTotalPrice(updatedPrice);
  } else {
  setFormErrors(errors);
  }
 
    };

const validateFields = (options, formData) => {
   const errors = {};
   options?.forEach((option) => {
   const { label, required, validation } = option;
   const value = formData[option.name];
   // Check required fields
   if (required && (!value )) {
   errors[option.name] = `This field is required`;
   }
   // Check validation rules
   if (value && validation) {
   switch (validation) {
   case 'numeric':
   if (isNaN(value)) {
   errors[option.name] = `please enter valid${label}`;
   }
   break;
   case 'email':
   if (!/\S+@\S+\.\S+/.test(value)) {
   errors[option.name] = `please enter valid${label} address`;
   }
   break;
   case 'mobile':
   if (!/^\d{10}$/.test(value)) {
   errors[option.name] = `please enter valid${label}`;
   }
   break;
   case 'alphanumeric':
   if (!/^[a-zA-Z0-9]*$/.test(value)) {
   errors[option.name] = `please enter valid${label}`;
   }
   break;
   case 'string':
   if (!/^[a-zA-Z ]*$/.test(value)) {
   errors[option.name] = `please enter valid${label}`;
   }
   break;
   default:
   break;
   }
   }
   });
   return errors;
  }
const handleAddToCart = (event) => {
   handleCheckPrice();
   const errors = {};
   const additionalErrors = validateFields(additionalOptions, formData);
   const optionsErrors = validateFields(options, formData);
   Object.assign(errors, additionalErrors, optionsErrors);
   if (Object.keys(errors).length === 0) {
   // Handle form submission here by sending formData to server or performing any other action
  //  console.log(formData);
   sessionStorage.setItem('numItems', parseInt(formData.num_items));
   const passengerName = document.getElementsByName('PassengerName')[0];
   if(passengerName!=null){
  //  addToCart(parseInt(formData.num_items));
   }
   onHide();
   } else {
   setFormErrors(errors);
   }
  };
const serviceMapping = {
      'Normal Parking': ['Valet Parking',"$15"],
      'Premium Lounge': ['VIP Lounge',"$50"],
    };  
    

const handleMobileInput = data => {
      setFormData({ ...formData, mobileno: data })
      // console.log(formData)
    }
// useEffect(() => {
//   handleCheckPrice();
//  }, [formData]);
 
 const handleChange = (event) => {
    // handleCheckPrice();
    const { name, value } = event.target;
    if (event.target.nodeName === 'SELECT') {
      const selectedOption = event.target.options[event.target.selectedIndex];
      const selectedOptionName = selectedOption.getAttribute('name');
      setFormData((prevData) => ({ ...prevData, [selectedOptionName]: value }));
      setFormErrors((prevErrors) => ({ ...prevErrors, [selectedOptionName]: '' }));
      } else {
      setFormData((prevData) => ({ ...prevData, [name]: value }));
      setFormErrors((prevErrors) => ({ ...prevErrors, [name]: '' }));
      }
      };

const handleCheckPriceButton= () => {
  handleCheckPrice();
        // serviceItemType.serviceType !== "Parking" ?(
        // document.querySelector('.pop-price-total').textContent = currency + totalPrice
        // :  ("")
       }

      const header= ( <div><h4 className="cartpop-main-title">{serviceName}</h4>
      </div>);
      const footer = ( <div>
        <button className="cartpopbottom-buttons-close" onClick={onHide}>
            Close
          </button>
        <button className="cartpopbottom-buttons-price" onClick={handleCheckPriceButton}>
            Get Price
          </button>
          <button className="cartpopbottom-buttons" onClick={handleAddToCart}>
            Add to Cart
          </button> </div>);




 return (
<Dialog header={header} footer={footer} visible={visible} style={{ width: '70vw',height:'150vw' }} onHide={onHide}>

            <div className="container-fluid ">
              <div className="row">
                <div className="col-md-6">
                  <img src={images[0]} alt= "serviceName" className="cartpopimg-box w-100 mb-3" />
                </div>
                <div className="col-md-6">
                  <h4 className="cartpop-title">{serviceName}</h4>
                  <p className="cartpop-desc-sub">{description[0]} {description[1]} {description[2]} {description[3]}</p>
                  <p className="cartpop-desc-main">{description[0]}</p>
                  <p className='cartpop-filling-header'>Fill the form below to get the price</p>
                 
                </div>
              </div> 
              <div className="">
              {/* <div className='row'> */}
                  {/* <div className="col-md-7"> */}
                  {options && (
                <div className='cartpopfields-container '>
                  {options.map((option, index) => (
                    <div key={index} className="form-form-group">
                      <label>{option.label}{option.required && <span className="text-danger">*</span>}</label>
                      {option.type === 'select' ? (
                        <Dropdown
                                   name={option.name}                        
                                   options={option.options}                        
                                   value={formData[option.name] || ''}                        
                                   onChange={handleChange}                        
                                   optionLabel="label"                        
                                   placeholder=""
                        
                                  />
                      ) 
                     
                        :option.type === 'number' ? (
                          <InputNumber
               value={formData[option.name]}
               onValueChange={(e) => handleChange({ target: { name: option.name, value: e.value } })}
               min={option.min}
               max={option.max}
               mode="decimal"
               name={option.name}
               showButtons
              />
                          ) : option.type === 'datetime-local' ? (
                            <Calendar                            
                            onChange={(e) =>handleChange({ target: { name: option.name, value: e.value }})}
                                      min={option.min}                            
                                      max={option.max}                            
                                      mode="decimal"                            
                                      name={option.name}                            
                                      showIcon                            
                                      showTime                            
                                      hourFormat="24"                           
                                     />
                         ) : (
                        <input type={option.type} name={option.name} className="cartpopform-control"  min={option.min} max={option.max} onChange={handleChange} value={formData[option.name] || ''} />
                      )}
                       {formErrors[option.name] && (
   <div className="formfield-errors">{formErrors[option.name]}</div>
   )}
                    </div>
                  ))}
                </div>
              )}
                  {/* </div> */}

                  

                  {/* </div> */}
                  <div className='additional-header row'>
  Additional details:
</div>

                  <div className='cartpopfields-container-additional'>
              {formData.num_guests && (
<div >
 {[...Array(parseInt(formData.num_guests))].map((_, i) => (
<div key={i} className="form-form-group ">
<label htmlFor={`guest_name_${i}`}>Guest Name {i + 1}:</label>
<input
 type="text"
 className="form-form-control"
 id={`guest_name_${i}`}
 name={`guest_name_${i}`}
 value={guestNames[i]}
 onChange={(e) =>
 setGuestNames((prevNames) =>
 prevNames.map((name, index) =>
 index === i ? e.target.value : name
 )
 )
 }
 />
</div>
 ))}
</div>
)}



{formData.num_children && (
<div>
 {[...Array(parseInt(formData.num_children))].map((_, i) => (
<div key={i} className="form-form-group">
<label htmlFor={`child_name_${i}`}>Child Name {i + 1}:</label>
<input
 type="text"
 className="form-form-control"
 id={`child_name_${i}`}
 name={`child_name_${i}`}
 value={childNames[i]}
 onChange={(e) =>
 setChildNames((prevNames) =>
 prevNames.map((name, index) =>
 index === i ? e.target.value : name
 )
 )
 }
 />
</div>
 ))}
</div>
)}
</div>
<div className='cartpopfields-container'>
        {additionalOptions?.map((option, index) => (
        <div key={index} className="form-form-group">
          <label> {option.label}:
          {option.required && <span className="text-danger">*</span>}</label>
          {option.type === 'select' ? (
          <select name={option.name} className="form-form-control" onChange={handleChange}>
            <option value="" disabled selected hidden></option>
            {option.options.map((value, index) => (
            <option key={index} value={value} 
            name={option.name}className="form-form-control" onChange={handleChange} >
              {value}
              </option>
              ))}
              </select>
              ) : option.type === 'radio' ? (
              <div>
                {option.options.map((value, index) => (
                <div key={index}>
                  <input type="radio" name={option.name} onChange={handleChange} value={formData[option.name] || value} />
                  <label>{value}</label>
                  </div>
                  ))}
                  {/* {option.type === 'radio' && 
                  ( <div> {option.options.map((value, index) => 
                  ( <div key={index}> 
                  <RadioButton inputId={`${option.name}-${value}`} name={option.name} value={formData[option.name] || value} onChange={handleChange} checked={formData[option.name] === value} /> 
                  <label>{value}</label> 
                  </div> ))} 
                  </div> )} */}
                  </div>
                   ):option.type === 'tel' ? (
                    <PhoneInput
                    
                    className='text-style'
                    name='mobileno'
                    value={formData.mobileno}
                    onChange={handleMobileInput} />
                    
     
                   ) :(
                   <input type={option.type} name={option.name} className="form-form-control" onChange={handleChange} value={formData[option.name] || ''} />
                   )} 
                    {formErrors[option.name] && (
                    <div className="formfield-errors">{formErrors[option.name]}</div>
                    )}
                    </div>))}
                   </div>
                    </div>
                    <div className='cart-pop-total'>
      <div className="cart-pop-link" > Total Amount : </div>
      {errorMessage ? (
  <div className="error-message">{errorMessage}</div>
) : (<h6 className="pop-price-total"></h6>
  // serviceItemType.serviceType !== "Parking" ? (
  //   <h6 className="pop-price-total"></h6>
  // ) : (
  //   <h6 className="pop-price-total"></h6>
  // )
)}
      </div>
      {selectedCard.id===14 || selectedCard.id===23 ? 
                    <div className='upgarding-status'>
                       <input type="checkbox" className='upgrading-checkbox'/>
                      <p >I would like to pay additional <b >{serviceMapping[selectedCard.serviceName][1]} and upgrade to 
                        
                        {" "}  {serviceMapping[selectedCard.serviceName][0]}
                        </b>
                        .
                      </p>
                      <button type="button"
                        class="upgrading-button"
                        onClick={handleClick}
                      >
                        Yes
                      </button>
                  
                      {/* <button type="button" class="btn-custom btn btn-sm btn-xs btn-secondary" style={{marginLeft: '10px'}}>No</button> */}
                    </div>: <></>}
                    </div>
                    
                       
</Dialog>
 );
};



export default Popup;