
import React, { useState } from 'react';
import { useEffect } from 'react';
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import { CSSTransition } from 'react-transition-group';
import { Galleria } from 'primereact/galleria';
import './popup.css';
import { Rating } from 'primereact/rating';
import { SelectButton } from 'primereact/selectbutton';
import { Calendar } from 'primereact/calendar';
import { Dropdown } from 'primereact/dropdown';
import { InputNumber } from 'primereact/inputnumber'; 
import fields from './shoppingFields.json';
import additionalFields from './additionalShoppingFields.json';
import './MyPopup.css';
import { TabView, TabPanel } from 'primereact/tabview';
import { ProgressBar } from 'primereact/progressbar'; 
import { Avatar } from 'primereact/avatar';      
import PhoneInput from 'react-phone-number-input';
import 'react-phone-number-input/style.css';
import { RadioButton } from 'primereact/radiobutton';
import { Divider } from 'primereact/divider';
import { useSelector, useDispatch } from 'react-redux';
import { ToastContainer, toast } from "react-toastify";
import { InputText } from 'primereact/inputtext';
import { fetchWishList, deleteWishList, addToWishList, deleteFromWishList, getWishList } from '../../redux/features/wishlist/wishlistAction';
import { connect } from "react-redux";

const deliveryOptions = [
    { label: 'Airport Terminal Gates', value: 'terminalgate' },
    { label: 'Arrival', value: 'arrival' },
    { label: 'Departure', value: 'departure' },
    { label: 'Pickup at store', value: 'store' }
   ];
  

const MyPopup = ({ product, visible,selectedCard, onHide,addToCart, changeCartPopupStatus,showSavedtoCart=true,iswishlisted, userInfo }) => {
    // console.log(selectedCard,"selectedcard")
    const { id, serviceName, images, description, serviceItemType, currency, unitPrice, offerPrice, quantity } = selectedCard || {};
    // const options = fields.find((field) => String(field.category).includes(selectedCard.category))?.fields
    const options = fields.find((field) => String(field.category).includes("Electronics"))?.fields
    //const options = fields.find((field) => field.category ===selectedCard.category)?.fields;
    const date= new Date(selectedCard.toDate);
    const formattedDate = date.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }); // "May 31, 2023"
    const additionalOptions = additionalFields.fields;
    //const additionalOptions = additionalFields.find((field) => String(field.category).includes(selectedCard.category))?.fields
    const [totalPrice, setTotalPrice] = useState("offerPrice || unitPrice");
    const [formData, setFormData] = useState('');
    const [formErrors, setFormErrors] = useState({});
    const [errorMessage, setErrorMessage] = useState("");
    const [formState, setFormState] = useState({});
    const [email, setEmail] = useState("");
    const [phone, setPhone] = useState("");
    const [name, setName] = useState("");
    const [wishlistSelectedProduct, setWishlistSelectedProduct] = useState([]);
    const [favSelectedProduct, setFavSelectedProduct] = useState([]);
    const [wishicon, setWishicon] = useState(iswishlisted ? true : false);
    
    const dispatch = useDispatch();
  
    useEffect(() => {
      if (userInfo) {
        setEmail(userInfo.email);
        setPhone(userInfo.phoneNumber);
        setName(userInfo.username);
      }
    }, [userInfo, dispatch]);
    function handleAddToWishList(wishproduct) {
        let data = wishlistSelectedProduct;
        const ifExists = wishlistSelectedProduct.find(item => item == wishproduct.id);
        if (!ifExists) {
          data.push(wishproduct.id)
          setWishlistSelectedProduct(data);
        } else {
          const index = favSelectedProduct.indexOf(wishproduct.id);
          data.splice(index, 1);
          setWishlistSelectedProduct(data)
        }
    
        //   console.log("wish values : ", wishproduct.id)
        //   console.log("isAdded : ", isAdded)
        // dispatch(getWishList({token: userInfo.accessToken}))
        let inputData = { 'serviceId': wishproduct.id };
        if (!ifExists) {
          if (userInfo) {
            dispatch(fetchWishList(inputData));
             console.log("input data of wishlist is", inputData)
            dispatch(getWishList({ token: userInfo.accessToken }))
          }
          else {
            dispatch(addToWishList(wishproduct));
             console.log("wishproduct is", wishproduct)
          }
          setWishicon(true)
    
        } else {
          if (userInfo) {
            dispatch(deleteWishList(wishproduct.id));
             console.log("input data of delete wishlist is", wishproduct.id)
            dispatch(getWishList({ token: userInfo.accessToken }))
          } else {
            dispatch(deleteFromWishList(wishproduct.id));
             console.log("delete wishlist is", wishproduct.id)
          }
          setWishicon(false)
    
        }
      }
    const handleChange = (event) => {
             handleCheckPrice();
        const { name, value } = event.target;
        if (event.target.name === 'EmailAddress') { setEmail(event.target.value); }
        if (event.target.name === 'PassengerName') { setName(event.target.value); }
        if (event.target.nodeName === 'SELECT') {
            const selectedOption = event.target.options[event.target.selectedIndex];
            const selectedOptionName = selectedOption.getAttribute('name');
              setFormData((prevData) => ({ ...prevData, [selectedOptionName]: value }));
             
              setFormErrors((prevErrors) => ({ ...prevErrors, [selectedOptionName]: '' }));
              } else {
              setFormData((prevData) => ({ ...prevData, [name]: value }));
             
              setFormErrors((prevErrors) => ({ ...prevErrors, [name]: '' }));
            
              }
              };

        
    const gimages = images.map((image) => ({
           itemImageSrc: image,
           thumbnailImageSrc: image,
           alt: 'Description for Image',
          }));
    const calculatePrice = () => {
        let totalPrice = 0;
        if (offerPrice) {
            totalPrice = offerPrice;
            } else {
            totalPrice = unitPrice;
            }

         if (selectedCard.category !== 'Parking'||selectedCard.category !== 'Services'||selectedCard.category !== 'Lounge'||selectedCard.category !== 'Passenger Service') {
            
             let num_items = 1;
            
            //  let color_price = 90;
            //  let volume_price = 50;
             {options.forEach((option) => {
             if (option.name === "num_items") {
             
             num_items =formData[option.name]||1;
             } 
            //  else if (option.name === "color") {
            //  const color = formData[option.name];
            //  if (color === "Blue - INR 90") {
            //  color_price = 90;
            //  } else if (color === "Black - INR 96") {
            //  color_price = 96;
            //  } else if (color === "Silver - INR 92") {
            //  color_price = 92;
            //  }
            //  totalPrice = totalPrice*num_items+ color_price;
            //  } else if (option.name === "volume") {
            //  const volume = formData[option.name];
            //  if (volume === "30ml") {
            //  volume_price = 30;
            //  } else if (volume === "50ml") {
            //  volume_price = 50;
            //  } else if (volume === "100ml") {
            //  volume_price = 100;
            //  } else if (volume === "200ml") {
            //  volume_price = 200;
            //  } else if (volume === "500ml") {
            //  volume_price = 500;
            //  }
            //  totalPrice = totalPrice*num_items+ volume_price; 
            //  }
             });}
                //    console.log(num_items,"numitems")
                //    console.log(volume_price,"volume")
                //    console.log(totalPrice,"total")
                //    totalPrice = totalPrice*num_items+ color_price + volume_price;
                totalPrice = totalPrice*num_items;
                   totalPrice = totalPrice.toFixed(0);
                   setFormData({ ...formData, totalPrice: totalPrice , numitems: num_items})
                   setFormState({"Sold by":selectedCard.seller})
               
                // console.log(formState,"formstate");
                // console.log(formData,"formdata");
            }       
                     };

 const handleCheckPrice = () => {
     const errors = {};
     const optionsErrors = validateFields(options, formData);
     Object.assign(errors, optionsErrors);
        if (Object.keys(errors).length === 0) {
            const updatedPrice = calculatePrice(totalPrice);
           
            setTotalPrice(updatedPrice);
            } else {
            setFormErrors(errors);
            }
                       
        };
    const validateFields = (options, formData) => {
      
        const errors = {};
        if (options){
        options?.forEach((option) => {
        const { label, required, validation } = option;
        const value = formData[option.name];
            // Check required fields
        if (required && (!value )) {
        errors[option.name] = `This field is required`;
        }
            // Check validation rules
        if (value && validation) {
        switch (validation) {
        case 'numeric':
        if (isNaN(value)) {
        errors[option.name] = `please enter valid${label}`;
        }
        break;
        case 'email':
        if (!/\S+@\S+\.\S+/.test(value)) {
        errors[option.name] = `please enter valid${label} address`;
        }
        break;
        case 'mobile':
        if (!/^\d{10}$/.test(value)) {
        errors[option.name] = `please enter valid${label}`;
            }
        break;
        case 'alphanumeric':
        if (!/^[a-zA-Z0-9]*$/.test(value)) {
        errors[option.name] = `please enter valid${label}`;
        }
        break;
        case 'string':
        if (!/^[a-zA-Z ]*$/.test(value)) {
        errors[option.name] = `please enter valid${label}`;
        }
        break;
        default:
        break;
        }
        }
        });}
        return errors;
        }
    const handleAddToCart = (event) => {
        handleCheckPrice();
        // setFormState({"Sold by":selectedCard.seller, "Total" :formData.totalPrice ,"":selectedCard.loyaltyPoints})
        // setFormState({ ...formData, category: selectedCard.category, points: selectedCard.loyaltyPoints})
        setFormState({"Sold By":selectedCard.seller})
         
          // console.log(formState,"formstate");
        const cartdata = JSON.stringify(formState); 
        console.log(cartdata,"cartdata")
        addToCart(formData.numitems?(formData.numitems):(1),cartdata);
        onHide();
    //     const errors = {};
    //     const additionalErrors = validateFields(additionalOptions, formData);
    //     const optionsErrors = validateFields(options, formData);
    //     Object.assign(errors, additionalErrors, optionsErrors);
    //     console.log(Object.keys(errors),"kkkk")
    //     if (Object.keys(errors).length === 0) {
    //       console.log(formData);
    // console.log(Object.keys(errors),"kkkk")
    // console.log("yes")
    //         // Handle form submission here by sending formData to server or performing any other action
    //        //  console.log(formData);
    //     //sessionStorage.setItem('numItems', parseInt(formData.num_items));
    //     // const passengerName = document.getElementsByName('PassengerName')[0];
    //     // if(passengerName!=null){
    //     //      addToCart(parseInt(formData.num_items));
    //     // }
    //     // // onHide();
    //     } 
    //     else {
        // setFormErrors(errors);
        // }
        changeCartPopupStatus();
        };
        // const handleCheckPriceButton= () => {
        //     handleAddToCart()
        //     // setCurrentScreen(currentScreen + 1);
        //          }   
 const handleMobileInput = data => {
    setFormData({ ...formData, mobileno: data })
    setPhone(data)
    // console.log(formData)
  }
     const responsiveOptions = [
         {
             breakpoint: '991px',
             numVisible: 4
         },
         {
             breakpoint: '767px',
             numVisible: 3
         },
         {
             breakpoint: '575px',
             numVisible: 1
         }
     ];
    
    
     const itemTemplate = (item) => {
         return <img src={item.itemImageSrc} alt={item.alt} style={{width: '353px',height: '318px'}} />
     }
    //  const itemTemplate = (item) => {
    //     return <img src={item.itemImageSrc} alt={item.alt} style={{ marginLeft: 'auto', marginRight: '16px',height:'380px ' }} />;
    // };
     const thumbnailTemplate = (item) => {
         return <img src={item.thumbnailImageSrc} alt={item.alt} />
     }
    
 
 const [currentScreen, setCurrentScreen] = useState(1);
 const handleBackButtonClick = () => {
 setCurrentScreen(currentScreen - 1);
 };
 const handleGoButtonClick = () => {
    calculatePrice();
 setCurrentScreen(currentScreen + 1);

 };


 const renderScreen1 = () => {
 return (

 <>

<div className="container-fluid ">
<div className="row">
<div className="col-md-4 ">
    <div className='pop-image'>
{/* <Galleria value={gimages} responsiveOptions={responsiveOptions} numVisible={5} style={{width: '353px'; height: 280px;}} 
             item={itemTemplate} thumbnail={thumbnailTemplate}/> */}
<Galleria value={gimages} showThumbnails={false} showIndicators indicatorPosition="inside" item={itemTemplate} />
</div>


</div>
<div className="col-md-8">
<h4 className="cartpop-header">{serviceName}</h4>
<h4 className="pop-spec-title">{selectedCard.features}</h4>
<div className='pop-terminal-details'>
<div className='pop-shop-header'>
    Shop : <p className='pop-shop-title'>{selectedCard.seller}</p>
    <div className='product-rating'>
                  <Rating stars={selectedCard.ratingStars} value={selectedCard.ratingStars} readOnly cancel={false} />
                  <span className='total-ratings'>{selectedCard.ratingCount} Ratings</span>                  
                </div>
</div>
{"Cochin International Airport"}
</div>   
<div className='visit-similar-link'>
    <div>
        Visit Store | 
    </div>
    <div style={{marginLeft:'5px'}}>
    Similar Products
</div>
    </div>           
                  
                  <div className='pop-price-container'>
                  <div className='pop-price-block'>
                    {offerPrice?(<div className='price-block'>
                        <div className='pop-all-price'>
                            <div>
                    <span className="pop-unit-price">{currency}&nbsp;{offerPrice}</span>
                    {/* <span className="original-price">Price : {currency}{unitPrice}</span> */}
                    </div>
                    <span className="original-price">Price : {currency}&nbsp;{unitPrice}</span>
                    {/* <span className='pop-tax-desc'>Inclusive of all taxes</span> */}
                    </div>
                    <div className='offer-reward'>
                    <span className="offer-percentage">{selectedCard.offerText}</span>
                    <span className='reward-points'>+{selectedCard.loyaltyPoints} Reward Points</span>
                    </div>
                    {/* <div className='offer-validity-box'> */}
                    {selectedCard.toDate&&<span className="offer-validity">Offer Valid Till {formattedDate}</span>}  
                      {/* </div> */}
                    </div>):(<div className='price-block'>
                        <div className='pop-all-price'>
                            
                    <span className="pop-unit-price">{currency}&nbsp;{unitPrice}</span>
                    
                    
                    {/* <span className='pop-tax-desc'>Inclusive of all taxes</span> */}
                    </div>
                    <div className='offer-reward'>
                    <span className="offer-percentage">{selectedCard.offerText}</span>
                    <span className='reward-points'>+{selectedCard.loyaltyPoints} Reward Points</span>
                    </div>
                    {selectedCard.toDate&&<span className="offer-validity">Offer Valid Till {formattedDate}</span>}  
                    </div>
                    )
                   }
                   
                    
                  </div>
                  </div>
                 
                  {options && (
                <div className='cartpopfields-container '>
                  {options.map((option, index) => (
                    <div key={index} className="form-form-group pop-option">
                      <label>{option.label}{option.required && <span className="text-danger">*</span>}</label>
                      {option.type === 'select' ? (
                        <Dropdown key={option.name} 
                        name={option.name} 
                        options={option.options} 
                        onChange={(e) => handleChange({ target: { name: option.name, value: e.value } })}
                        placeholder={option.label} 
                        value={formData[option.name]||option.options[0]}
                        />
                      )
                        :option.type === 'number' ? (
                          <InputNumber
                          value={formData[option.name]||1}
                          onChange={(e) => handleChange({ target: { name: option.name, value: e.value } })}
                          min={option.min}
                          max={option.max}
                          mode="decimal"
                          name={option.name}
                          showButtons
              />
                          ) : option.type === 'datetime-local' ? (
                            <Calendar    
                            onChange={(e) => 
                              handleChange({ target: { name: option.name, value: e.value }})}
                            
                                      min={option.min}                            
                                      max={option.max}                            
                                      mode="decimal"                            
                                      name={option.name}                            
                                      showIcon                            
                                      showTime                            
                                      hourFormat="24"                           
                                     />
                         ) : (
                        <input type={option.type} name={option.name} className="cartpopform-control"  min={option.min} max={option.max} onChange={handleChange} />
                      )}
       
                    </div>
                  ))}
                </div>
              )}
</div>



</div>


<div className='tabview'>
<TabView>
    <TabPanel header="Product Details">
        <div className='row'>
        <div className="col-md-6">
        <p className='feedback-header'>Product Highlights</p>  
                   
                   <div className="pop-spec">
                     <ul className='p-list'>
                       {description.map((desc, index) => (
                       <li className='p-list-item' key={index}>
                         {desc}
                         </li>))}
                         </ul>
                         </div>
                         <div className='button-highlight'>
                            
                         <Button label='See more product details' outlined />
                  <Button label='Other purchase options' outlined />
                   
                  </div>
        </div>
        <div className="col-md-6">
            {/* <div className='delivery-option'>
        <p className='pop-spec-title-sub'>Delivery options</p>
                  <SelectButton
                  options={deliveryOptions}
                  value={formData[deliveryOptions]}
                  onChange={(e) => handleChange({ target: { name: "deliveryOptions", value: e.value } })}
                  optionLabel="label"
                  optionValue="value"
                  className='delivery-option'

                  /> 
                  </div> */}
                  <div className='other-offers'>
                  <p className='feedback-header'>Other Offers</p>
                  <div className='pop-spec'>
                  <ul className='p-list'>
                      <li className='p-list-item'>
                      Get up to 50% off on your {selectedCard.category} bills with the QNB Qatar Airways Platinum Credit Card at select restaurants across Qatar
                          </li>
                          <li className='p-list-item'>
                          Earn 1.5% cashback on purchases made using the Doha Bank Al Riyada Visa Platinum Credit Card
                          </li >
                          <li className='p-list-item'>
                          Enjoy exclusive offers on Commercial Bank Mastercard Titanium Credit Card, including discounts and more
                          </li>
                          <li className='p-list-item'>
                          Earn 2 reward points for every INR 1 spent on your Ahlibank Visa Infinite Credit Card, redeemable for flights, hotel stays, and other exciting travel rewards
                          </li>
                          </ul> 
                          </div>                 
                  </div>
                  
        </div>
        </div>
    </TabPanel>
    {selectedCard.category==="Electronics"&&<TabPanel header="Specification">
    <div className='row'>
    <p className='feedback-header'>Product Specification</p>
        <div className="col-md-4">
            <div className='spec-col'>
          <div>
          Display technology
          </div>
          <div className='spec-detail'>
          LCD
          </div>
          </div>
          <Divider/>
          <div className='spec-col'>
          <div>
          Memory storage
          </div>
          <div className='spec-detail'>
          128 GB
          </div>
          </div>
          <Divider/>
        </div>
        <div className="col-md-4">
            <div className='spec-col'>
          <div>
          Cellular technology
          </div>
          <div className='spec-detail'>
          5G
          </div>
          </div>
          <Divider/>
          <div className='spec-col'>
          <div>
          Item weight
          </div>
          <div className='spec-detail'>
          206 grams
          </div>
          </div>
          <Divider/>
        </div>
        <div className="col-md-4">
            <div className='spec-col'>
          <div>
          Battery Capacity
          </div>
          <div className='spec-detail'>
          6000 mAh
          </div>
          </div>
          <Divider/>
          <div className='spec-col'>
          <div>
          Material
          </div>
          <div className='spec-detail'>
          Silicone
          </div>
          </div>
          <Divider/>
        </div>
        </div>
    </TabPanel>}
    <TabPanel header="Reviews">
        <div className='row'> 
        <div className='col-md-4'>
            <div className='feedback-header'>
            Reviews
            </div>
            <div className='rating-count'>
                4.1 out of 5
                <span>
                    {selectedCard.rating} ratings
                </span>
            </div>
            <div className='rating-bar'>
                <div className='single-ratings'>
                5
                <Rating stars={1} value={1}  readOnly cancel={false} />
                <ProgressBar value={53} showValue={false}></ProgressBar>
                53%
                </div>
                <div className='single-ratings'>
                4
                <Rating stars={1} value={1} readOnly cancel={false} />
                <ProgressBar value={25} showValue={false}></ProgressBar>
                25%
                </div>
                <div className='single-ratings'>
                3
                <Rating stars={1} value={1} readOnly cancel={false} />
                <ProgressBar value={9} showValue={false}></ProgressBar>
                9%
                </div>
                <div className='single-ratings'>
                2
                <Rating stars={1} value={1} readOnly cancel={false} />
                <ProgressBar value={3} showValue={false}></ProgressBar>
                3%
                </div>
                <div className='single-ratings'>
                    1
                <Rating stars={1} value={1} readOnly cancel={false} />
                <ProgressBar value={9} showValue={false}></ProgressBar>
                9%
                </div>
            
            </div>
            </div>
            <div className='col-md-8'>
                <div className='review-container'>
            <div className='review-header'>
            Recent Reviews
            </div>
            <div className='reviews'>
                <div className='review-sub-header'>
                <Avatar label="WJ" size="large" shape="circle" />
                <div className='customer-details'>
                <p>William Johnson</p>
                <p>16 April 2023</p>
                </div>
                </div>
                <div className='review-headline'>
                Best purchase till date
                </div>
                <p>
                I purchased this product on a whim and it's quickly become a staple in my daily routine. It's well-made and durable
                </p>
            </div>
            <div className='reviews'>
                <div className='review-sub-header'>
                <Avatar label="JD" size="large" shape="circle" />
                <div className='customer-details'>
                <p>John Doe</p>
                <p>1 April 2023</p>
                </div>
                </div>
                <div className='review-headline'>
                Good product
                </div>
                <p>
                I've tried several similar products in the past, but this one is by far the best. It's effective, long-lasting
                </p>
            </div>
            <div className='reviews'>
                <div className='review-sub-header'>
                <Avatar label="ES" size="large" shape="circle" />
                <div className='customer-details'>
                <p>Elizabeth Smith</p>
                <p>19 March 2023</p>
                </div>
                </div>
                <div className='review-headline'>
                Great buy.
                </div>
                <p>
                I was hesitant to try this product at first, but I'm so glad I did! It's been a game-changer for me and I've already recommended it to several friends 
                </p>
            </div>
            <div className='review-link'>
                See all reviews
            </div>
            </div>
            </div>
            </div>
    </TabPanel>
</TabView>

</div>



</div>
 </>

 );

 };




 const renderScreen2 = () => {

    return (
   
    <>
   
   <div className="container-fluid ">
   <div className="row">
   <div className="col-md-2 ">
      <img src={images[0]} className='screen2-image'></img>
   </div>
   <div className="col-md-10">
   <h4 className="cartpop-header">{serviceName}</h4>
   <h4 className="pop-spec-title">{selectedCard.features}</h4>
    </div>
    <div className='contact-details'>
    Contact Details
    </div>
   
    <div className='cartpopfields-container'>
           {additionalOptions?.map((option, index) => (
           <div key={index} className="form-form-group">
             <label> {option.label}:
             {option.required && <span className="text-danger">*</span>}</label>
             {option.type === 'select' ? (
             <select name={option.name} className="form-form-control" onChange={handleChange}>
               <option value="" disabled selected hidden></option>
               {option.options.map((value, index) => (
               <option key={index} value={value} 
               name={option.name}className="form-form-control" onChange={handleChange} >
                 {value}
                 </option>
                 ))}
                 </select>
                 ) : option.type === 'radio' ? (
                 <div>
                   {option.options.map((value, index) => (
                   <div key={index}>
                     <input type="radio" name={option.name} onChange={handleChange} value={formData[option.name] || value} />
                     <label>{value}</label>
                     </div>
                     ))}
                     {/* {option.type === 'radio' && 
                     ( <div> {option.options.map((value, index) => 
                     ( <div key={index}> 
                     <RadioButton inputId={`${option.name}-${value}`} name={option.name} value={formData[option.name] || value} onChange={handleChange} checked={formData[option.name] === value} /> 
                     <label>{value}</label> 
                     </div> ))} 
                     </div> )} */}
                     </div>
                       ):option.type === 'tel' ? (
                         <PhoneInput
                         
                         className='text-style'
                         name='mobileno'
                       value={phone}
                    
                         onChange={handleMobileInput} />
                         
          
                        ): option.type === 'email' ? (
                          <InputText type={option.type} name={option.name} className="form-form-control" onChange={handleChange} placeholder={userInfo && userInfo.email != null ? userInfo.email : ""} value={email} />
                          
           
                         ): option.name === 'PassengerName' ? (
                          <input type={option.type} name={option.name} className="form-form-control" onChange={handleChange} value={name} />
                          
           
                         ):(
                      <input type={option.type} name={option.name} className="form-form-control" onChange={handleChange} value={formData[option.name] || ''} />
                      )} 
                       {formErrors[option.name] && (
                       <div className="formfield-errors">{formErrors[option.name]}</div>
                       )}
                       </div>))}
                      </div> 
       <div className='contact-details'>
    Delivery Details
    </div> 
    <div className='delivery-place'>
    <input type="radio" id="pickup" name="delivery" value="Pickup at store" onChange={(e) => setFormData({ ...formData, delivery: e.target.value })} />
   <label for="pickup">Pickup At Store</label>
   <input type="radio" id="atlocation" name="delivery" value="At Your Location" onChange={(e) => setFormData({ ...formData, delivery: e.target.value })} />
   <label for="atlocation">Deliver At Your Gate</label>
        </div>          
   </div>
   </div>
   
    </>
   
    );
   
    };
   
    
    const headerScreen1 = (
       <div className='headerScreen1'>
       <h4 className="cartpop-headerScreen">{serviceName}</h4>
       </div>
        );
   const headerScreen2 = (
       <div className='headerScreen2'>
           {/* <div className='arrow-left' onClick={handleBackButtonClick}><i className="pi pi-arrow-left"></i></div>
           <p className='headerBackButton'onClick={handleBackButtonClick}> Back</p> */}
           {/* <div className='headerBackButton'  onClick={handleBackButtonClick}>
           <Button label='Back' icon="pi pi-arrow-left"/>
           </div> */}
            <div className='headerBackButton'  onClick={handleBackButtonClick}>
            <i className="pi pi-arrow-left" style={{marginTop:'4px',color:'black'}}></i>
            <div className='back-link'> Back</div> 
            </div>
           
       <h4 className="cartpop-headerScreen">Delivery Details</h4>
       </div>
        );       
   const footerScreen1 = (
   <div className='sreen1-footer'>
        <div className='save-button'>
            {/* <Button icon="pi pi-bookmark" label='Save For Later'/> */}

        {showSavedtoCart && <>{wishlistSelectedProduct && wishlistSelectedProduct.length > 0 && wishlistSelectedProduct.find(item => item == selectedCard.id) ?
        <Button label='Saved For Later' key={selectedCard.id}  onClick={() => handleAddToWishList(selectedCard)}icon="pi pi-bookmark-fill"/>:
        <Button label='Save For Later'  key={selectedCard.id} onClick={() => handleAddToWishList(selectedCard)} icon="pi pi-bookmark"/>}
        </>
        }
            </div> 
       <div className='pop-cart-button'>
       <Button icon=" pi pi-shopping-bag" label='Add to cart' onClick={handleGoButtonClick}/>
       </div>
       
       
       </div>
   )
   const footerScreen2 = (
       <div className='screen2-footer'>
       <div className='sreen1-footer'>
           <div className='screen1-footer2'>
           <div className='pop-price-total'>
           Total Amount : <div className='pop-price-total'>{currency}&nbsp;{formData.totalPrice}</div>
       </div>
           </div>
       <div className='screen2-buttons'>
       <div className='save-button'>
            {/* <Button icon="pi pi-bookmark" label='Save For Later'/> */}

        {showSavedtoCart && <>{wishlistSelectedProduct && wishlistSelectedProduct.length > 0 && wishlistSelectedProduct.find(item => item == selectedCard.id) ?
        <Button label='Saved For Later' key={selectedCard.id}  onClick={() => handleAddToWishList(selectedCard)}icon="pi pi-bookmark-fill"/>:
        <Button label='Save For Later'  key={selectedCard.id} onClick={() => handleAddToWishList(selectedCard)} icon="pi pi-bookmark"/>}
        </>
        }
            </div> 
       <div className='pop-cart-button'>
           <Button icon=" pi pi-shopping-bag" label='Done' onClick={handleAddToCart}/>
           <ToastContainer />
           </div>
           </div>
           
           
       
       </div>
   </div>
           
           )
   
   
   
   
    return (
   
    <Dialog header={currentScreen === 1 ? headerScreen1 : headerScreen2} footer={currentScreen === 1 ? footerScreen1 : footerScreen2} visible={true} style={{ width: '960px', height: '768px' }} className="popup-dialog-box" onHide={onHide}>
    <CSSTransition in={currentScreen === 1} timeout={200} classNames="screen-transition" unmountOnExit>
    <div>{renderScreen1()}</div>
    </CSSTransition>
    <CSSTransition in={currentScreen === 2} timeout={200} classNames="screen-transition" unmountOnExit>
    <div>{renderScreen2()}</div>
    </CSSTransition>
   
    </Dialog>
   
    );
   
   }
   
   
   const mapStateToProps = (state) => {
    return {
      userInfo: state.auth.userInfo
    };
  };
  
   
   
   export default connect(mapStateToProps)(MyPopup);
   
   
   
   