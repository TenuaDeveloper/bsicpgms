import { Component } from "react";

let loaded = false;

class KommunicateChat extends Component {
    constructor(props) {
        super(props);
    }
    componentDidMount = () => {

        if (!loaded) {
            // console.log('chat');

            (function (d, m) {
                var kommunicateSettings = { "appId": "1aaf2506e4376ffebe211d28836204600", "popupWidget": true, "automaticChatOpenOnNavigation": true };
                kommunicateSettings.onInit = function () {
                    var headCol = ".mck-box-top {background-color: #1b4376!important;}"
                    window.Kommunicate.customizeWidgetCss(headCol);
                    var textBgR = ".mck-msg-right .mck-msg-box{background-color: #d7f4fd!important; color:black !important}";
                    window.Kommunicate.customizeWidgetCss(textBgR);
                    var textBgL = ".mck-msg-left .mck-msg-box{background-color: #f2f2f2!important;}";
                    window.Kommunicate.customizeWidgetCss(textBgL);
                };



                var s = document.createElement("script"); s.type = "text/javascript"; s.async = true;
                s.src = "https://widget.kommunicate.io/v2/kommunicate.app";
                var h = document.getElementsByTagName("head")[0]; h.appendChild(s);
                window.kommunicate = m; m._globals = kommunicateSettings;
                loaded = true;
            })(document, window.kommunicate || {});
        }
    }

    render() {
        return (
            <div>
            </div>
        )
    }
}

export default KommunicateChat;