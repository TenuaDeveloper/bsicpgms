import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import './App.scss';
import Footer from 'components/shared/footer/Footer';
import Header from 'components/shared/header/Header';
import AppRouting from 'components/routing/app-routing';
import Login from 'components/login/login'; // import the Login component
import Signup from 'components/signup/signup';
import OtpScreen from 'components/signup/Otpscreen';
import KommunicateChat from 'chat';
// import Kommunicate from '@kommunicate/kommunicate-chatbot-plugin';

const Main = () => {
  // Kommunicate.init("1aaf2506e4376ffebe211d28836204600")
  return (
    <div className='wrapper'>
      <main className="main">
        <Routes>
          <Route path='/login' element={<Login />} />
          <Route path='/signup' element={<Signup />} />
          <Route path='/Otpscreen' element={<OtpScreen />} />
          <Route path='/*' element={<>
            <Header />
            <div className="content">
                <AppRouting />
            </div>            
            <KommunicateChat />
            <Footer />
          </>} />
        </Routes>
      </main>
    </div>
  );
}

const App = () => {
  return (
    <Router>
      <Main />
    </Router>
  );
}

export default App;
