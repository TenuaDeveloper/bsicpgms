import { configureStore } from "@reduxjs/toolkit";
import { setupListeners } from "@reduxjs/toolkit/query";
import { combineReducers } from "@reduxjs/toolkit";
import authReducer from "./features/auth/authSlice";
import { authApi } from "./services/auth/authService";
import pingflightReducer from "./features/pingFlight/pingflightSlice";
import pinInspirationReducer from "./features/pinInspiration/pinInspirationSlice";
import pingPickupDropReducer from "./features/pinPickupDrop/pinPickupDropSlice";
import locationListReducer from "./features/pinInspiration/locationListSlice";
import flightListReducer from "./features/pingFlight/flightListSlice";
import serviceReducer from "./features/airportService/airportServiceSlice";
import offerReducer from "./features/airportOffers/offerSlice";
import cartReducer from "./features/cart/cartslice";
import comnReducer from "./features/common/commonSlice";
import purchaseListReducer from "./features/purchaseList/purchaseListSlice"
import popularReducer from "./features/popular/popularSlice"
import favouriteReducer from "./features/fav/favouriteSlice"
import storage from "redux-persist/lib/storage";
import { UnauthenticatedMiddleware } from "./unauthenticatedmiddleware";
import {
  persistReducer,
  FLUSH,
  REHYDRATE,
  PAUSE,
  PERSIST,
  PURGE,
  REGISTER,
} from "redux-persist";
import { persistStore } from "redux-persist";
import { favReducer, favoriteItemsReducer } from "./features/fav/favSlice"; // Import the reducers
import purchasedItemReducer from './features/purchasedItem/purchasedItemAction'
import wishlistItemsReducer from './features/wishlist/wishlistItemsSlice'
import addtowishlistItemsReducer from './features/wishlist/addtowishlistSlice'
import newItemsReducer from "./features/newItems/newItemsSlice"
import terminalReducer from "./features/terminal/terminalSlice";
import servicesAndOffersTerminalReducer from "./features/terminal/selectedTerminalSlice";
import selectedTerminalReducer from "./features/terminal/selectedTerminal";
import SearchCategoryResultsReducer from "./features/search/searchaction";
import terminalListActionsReducer from './features/pinPickupDrop/terminalListSlice';
import personalizedServicesAndOffersReducer from './features/personalizedServices/personalizedServicesSlice';
import recommendedCategoriesReducer from './features/recommendedCategories/recommendedCategoriesSlice';
import personalizedServicesAndOffersPaginatedReducer from './features/personalizedServicesPaginated/personalizedServicesPaginatedSlice';
import newArrivalReducer from './features/newArrivalsFilter/newarrivalSlice'
import messagesReducers from './features/Notification/messagesSlice'
import cartPopupStatusReducer from './features/cart/cartPopupSlice'
import newPersonalizedServicesAndOffersReducer from './features/newPersonalizedServices/newPersonalizedServicesSlice';
import orderReducer from './features/orders/orderSlice'
import pickMessagesReducer from './features/Notification/pickNotificationSlice'
import inspirationMessagesReducer from './features/Notification/inspirationNotificationslice'
import preferenceReducer from './features/preference/preferenceAction'

const persistConfig = {
  key: "root",
  storage: storage,
  blacklist: ["authApi"],
};

export const rootReducers = combineReducers({
  auth: authReducer,
  flight: pingflightReducer,
  services: serviceReducer,
  offers: offerReducer,
  cart: cartReducer,
  inspiration: pinInspirationReducer,
  locations: locationListReducer,
  flights: flightListReducer,
  pickupDrop: pingPickupDropReducer,
  [authApi.reducerPath]: authApi.reducer,
  common: comnReducer,
  fav: favReducer, // Add the favReducer
  favoriteItems: favoriteItemsReducer, // Add the favoriteItemsReducer
  purchasedItem: purchasedItemReducer,
  purchases: purchaseListReducer,
  wishlistItems: wishlistItemsReducer,
  addtowishlistItems: addtowishlistItemsReducer,
  popular: popularReducer,
  favourite: favouriteReducer,
  preference: preferenceReducer,
  newItems: newItemsReducer,
  terminals: terminalReducer,
  servicesAndOffersTerminal: servicesAndOffersTerminalReducer,
  selectedTerminal: selectedTerminalReducer,
  SearchCategoryResults: SearchCategoryResultsReducer,
  terminallist: terminalListActionsReducer,
  personalizedServicesAndOffers: personalizedServicesAndOffersReducer,
  recommendedCategories: recommendedCategoriesReducer,
  personalizedServicesAndOffersPaginated: personalizedServicesAndOffersPaginatedReducer,
  arrivals: newArrivalReducer,
  messages: messagesReducers,
  cartPopupStatus: cartPopupStatusReducer,
  newPersonalizedServicesAndOffers: newPersonalizedServicesAndOffersReducer,
  orders: orderReducer,
  pickMessages: pickMessagesReducer,
  inspirationMessages: inspirationMessagesReducer
});

const persistedReducer = persistReducer(persistConfig, rootReducers);

export const store = configureStore({
  reducer: persistedReducer,
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      immutableCheck: { warnAfter: 158 },
      serializableCheck: {
        warnAfter: 158,
        ignoredActions: [FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER],
      },
    }).concat(authApi.middleware, UnauthenticatedMiddleware),
});

setupListeners(store.dispatch);

export let persistor = persistStore(store);
