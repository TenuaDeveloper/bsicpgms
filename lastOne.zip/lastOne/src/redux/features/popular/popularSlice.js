import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

const backendURL = process.env.REACT_APP_REST_API_URL || "http://localhost:8080";
// const backendURL = "http://localhost:8080";
const FETCH_POPULAR_URL =  backendURL + "/api/v1/activitytracking/product";

// Define the initial state
const initialState = {
    popular: [],
    error: null,
    loading: false,
};

// Define the async thunk for fetching Purchases
export const fetchPopular = createAsyncThunk(
    'popular/fetchPopular',
    async () => {
        const response = await axios.get(`${FETCH_POPULAR_URL}`)
    //    console.log("fetchPopular: "+JSON.stringify(response.data)); // log the response data
        return response.data;
        }
);

// Define the purchaseListSlice 
const popularSlice = createSlice({
    name: 'popular',
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
        .addCase(fetchPopular.pending, (state) => {
            state.loading = true;
            state.error = null;
        })
        .addCase(fetchPopular.fulfilled, (state, action) => {
            state.loading = false;
            state.popular = action.payload;
        })
        .addCase(fetchPopular.rejected, (state, action) => {
            state.loading = false;
            state.error = action.error.message;
        });
    },
});



// Export the action creators
export const popularActions = {
    fetchPopular,
};
export default popularSlice.reducer;