import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { logout } from '../auth/authSlice';


const backendURL = process.env.REACT_APP_REST_API_URL || "http://localhost:8080";
// const backendURL = "http://localhost:8080";
const bearerToken = localStorage.getItem('userToken')
  ? localStorage.getItem('userToken')
  : null

// Define the initial state
const initialState = {
  purchases: {
    flight: {},
    pickupDrop: {},
    inspiration: {}
  },
  orderDetails: {},
  Orders :{},
  error: null,
  loading: false,
};

// Define the async thunk for fetching Purchases
export const fetchPurchases = createAsyncThunk(
  'purchases/fetchPurchases',
  async (payload) => {
    const response = await axios
      .get(`${backendURL}/api/v1/purchase/listpurchases`, {
        headers: {
          Authorization: `Bearer ${payload.token}`,
        },
      })
       //console.log("fetchPurchases: "+JSON.stringify(response.data)); // log the response data
    return response.data;
  }
);

export const addPurchases = createAsyncThunk(
  'purchases/addPurchases',
  async (payload) => {
    const config = {
      headers: {
        Authorization: `Bearer ${payload.token}`,
      },
    }
    const response = await axios
      .post(`${backendURL}/api/v1/purchase/add/`,{...payload.data}, config )
    return response.data;
  }
);
export const purchageHistory = createAsyncThunk(
  'purchases/purchageHistory',
  async (payload) => {
    const response = await axios
      .get(`${backendURL}/api/v1/purchase/history/`, {
        headers: {
          Authorization: `Bearer ${payload.token}`,
        },
      })
        console.log("fetchPurchase History: "+JSON.stringify(response.data)); // log the response data
    return response.data;
  }
);

// Define the purchaseListSlice 
const purchaseListSlice = createSlice({
  name: 'purchases',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchPurchases.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchPurchases.fulfilled, (state, action) => {
        state.loading = false;
        state.purchases = action.payload;
      })
      .addCase(fetchPurchases.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
      .addCase(logout, (state) => {
        state.purchases = []; // clear purchases array
        state.error = null;
        state.loading = false;
      })
      .addCase(addPurchases.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(addPurchases.fulfilled, (state, action) => {
        state.loading = false;
        state.orderDetails = action.payload;
      })
      .addCase(purchageHistory.fulfilled, (state, action) => {
        state.loading = false;
        state.Orders = action.payload;
      })
      .addCase(addPurchases.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      });
  },
});



// Export the action creators
export const purchaseActions = {
  fetchPurchases,
};
export default purchaseListSlice.reducer;