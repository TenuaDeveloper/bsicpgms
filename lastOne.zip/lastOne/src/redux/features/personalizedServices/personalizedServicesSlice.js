import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { logout } from '../auth/authSlice';

const backendURL = process.env.REACT_APP_REST_API_URL || "http://localhost:8080";
// const backendURL = "http://localhost:8080";

// new url
// const recommendedbackendURL = "https://af2eui6vdd.execute-api.ap-south-1.amazonaws.com/default/recommendation_airport";

// old url
const recommendedbackendURL = "https://ybhxg44xf1.execute-api.ap-south-1.amazonaws.com/default/get_recommendation_dxi";


// Define the initial state
const initialState = {
    personalizedServicesAndOffers: [],
    error: null,
    loading: false,
};

// Define the async thunk for fetching personalizedServicesAndOffers
export const fetchPersonalizedServicesAndOffers = createAsyncThunk(
    'services/personalizedServicesAndOffers',
    async (data) => {
        // var response = {};
        const response = await axios.post(recommendedbackendURL, data).then(
            res => {
                // console.log(res.data, {"productCategories" : Object.keys(res.data.items)})
                return axios.post(`${backendURL}/api/v1/serachfilter/personalizedoffers`, {"productCategories" : Object.keys(res.data.items)}).then(
                    res1 => {
                        return res1;
                    })                    
            }
        )        
        // const response = await axios.post(`${backendURL}/api/v1/serachfilter/personalizedoffers`, data.req);
        
        return response.data;
        }
);

// Define the personalizedServicesAndOffers slice
const personalizedServicesAndOffersSlice = createSlice({
    name: 'offers',
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
        .addCase(fetchPersonalizedServicesAndOffers.pending, (state) => {
            state.loading = true;
            state.error = null;
        })
        .addCase(fetchPersonalizedServicesAndOffers.fulfilled, (state, action) => {
            state.loading = false;
            state.personalizedServicesAndOffers = action.payload;
        })
        .addCase(fetchPersonalizedServicesAndOffers.rejected, (state, action) => {
            state.loading = false;
            state.error = action.error.message;
        })
        .addCase(logout, (state) => {
            state.personalizedServicesAndOffers = []; // clear personalizedServicesAndOffers array
            state.error = null;
            state.loading = false;
        });
    },
});



// Export the action creators
export const personalizedServicesAndOffersActions = {
    fetchPersonalizedServicesAndOffers,
};
export default personalizedServicesAndOffersSlice.reducer;