import axios from 'axios';
import { createAsyncThunk } from '@reduxjs/toolkit';

const backendURL = process.env.REACT_APP_REST_API_URL || "http://localhost:8080";
const CART_OFFER_URL = backendURL + "/api/v1/purchase/crosssell?serviceId=";

// console.log(CART_OFFER_URL)

export const getcartOffer = createAsyncThunk(
  'cartoffer/get',
  async (serviceId, { rejectWithValue }) => {
    const bearerToken = localStorage.getItem('userToken') ? localStorage.getItem('userToken') : null;

    try {
      const config = {
        headers: {
          'Authorization': `Bearer ${bearerToken}`
        },
      }
      const { data } = await axios.get(
        CART_OFFER_URL + serviceId,
        config
      );
      // console.log(`inside ${CART_OFFER_URL} data ->`, data)
      return data;
    } catch (error) {
      if (error.response && error.response.data.message) {
        return rejectWithValue(error.response.data.message)
      } else {
        return rejectWithValue(error.message)
      }
    }
  }
);
