import { createSlice } from '@reduxjs/toolkit'
import { toast } from 'react-toastify';
import { getPinFlight } from './pinAction'
import { logout } from '../auth/authSlice';

const initialState = {
  flightList:[],
  flightError: null
 
}

const pingflightSlice = createSlice({
  name: 'pingFlight',
  initialState,
  reducers: {
    addFlight: (state,action) => {
      if(!state.flightList.some(item => item.flightNo === action.payload.flightNo && item.scheduleDate === action.payload.scheduleDate && item.time === action.payload.time) ){
        let newFlight = {
            id:  state.flightList.length + 1,
            flightNo: action.payload.flightNo,
            time:  action.payload.time,
            scheduleDate:  action.payload.scheduleDate,
            source:  action.payload.source,
            destination:  action.payload.destination,
            terminal:  action.payload.terminal,
            gate:  action.payload.gate,
            flightId: action.payload.flightId,
            active: true,
            flightDepartArrivalStatus: action.payload.flightDepartArrivalStatus,
            flightType: action.payload.flightType,
            zone: action.payload.zone,
            boardingTime: action.payload.boardingTime,
            airlineLogo : action.payload.airlineLogo
          }
          state.flightList.push( newFlight);
        }else {
        }
      if (state.flightList.length === 1) {
          state.flightList[0].selected = true;
        } 
      },

      selectPinFlights: (state, action) => {
        const selectedFlight = state.flightList.find(item => item.id === action.payload.id);
        if (selectedFlight) {
          // If the selected flight is one of the first three items in the list, just update its 'selected' property
          if (state.flightList.indexOf(selectedFlight) < 3) {
            selectedFlight.selected = true;
          } else {
            // Otherwise, remove the selected flight from its current position and insert it at the front of the array
            state.flightList.splice(state.flightList.indexOf(selectedFlight), 1);
            state.flightList.unshift(selectedFlight);
            selectedFlight.selected = true;
          }
          // Deselect all flights except the selected flight
          state.flightList.forEach(item => {
            if (item !== selectedFlight) {
              item.selected = false;
            }
          });
        }
      },      
      
      unSelectPinFlights: (state, action) => {
        // Find the index of the selected flight in the flightList array
        const selectedIndex = state.flightList.findIndex(item => item.id === action.payload.id);
      
        // If the selected flight is found, set its 'selected' property to false
        if (selectedIndex !== -1) {
          state.flightList[selectedIndex].selected = false;
        }
      }
      ,      

     deleteFlight: (state, action) => {
        let { flightList } = state;
        state.flightList = flightList.filter((item) => 
            item.id !==action.payload.id);
        state.flightError = "";
        if (state.flightList.length === 1) {
          state.flightList[0].selected = true;
        } 
      },

      editFlight: (state, action) => {
        let { flightList } = state;
        state.flightList = flightList.map((item) => 
          item.id === action.payload.id ? action.payload : item);
      }
  },
  extraReducers: (builder) => {
    builder
    .addCase(getPinFlight.pending, (state) => {
      state.loading = true
      state.error = null
    })
    .addCase(getPinFlight.fulfilled, (state, action) => {
      state.loading = false;
      const currentDateTime = new Date();

      state.flightList = action.payload.filter((flight) => {
        const [day, month, year] = flight.scheduleDate.split('-');
        const flightDateTime = new Date(`${year}-${month}-${day}T${flight.time}`);
        return flightDateTime >= currentDateTime;
      });
    })
    .addCase(getPinFlight.rejected, (state, { payload }) => {
      state.loading = false
      state.error = payload
    })
    .addCase(logout, (state) => {
        state.flightList = []; // clear flightList array
        state.error = null;
        state.loading = false;
    });
  }

})

export const { addFlight, deleteFlight, editFlight, selectPinFlights, unSelectPinFlights } = pingflightSlice.actions
export default pingflightSlice.reducer;