import React, { useState, useEffect } from 'react';
import Select from 'react-select';
import { useDispatch } from 'react-redux';
import { fetchFlights } from './flightListSlice'; // Import your fetchFlights function from your slice file

const DebouncedDropdown = (props) => {
    const [inputValue, setInputValue] = useState('');
    const [options, setOptions] = useState([]);
    const dispatch = useDispatch();

    useEffect(() => {
        const loadOptions = async () => {
            if (inputValue.length > 0) {
                const data = await dispatch(fetchFlights(inputValue));
                setOptions(data.payload);
            }
        };

        const timer = setTimeout(() => {
            loadOptions();
        }, 300); // Set debounce delay here (e.g. 300ms)

        return () => {
            clearTimeout(timer);
        };
    }, [inputValue, dispatch]);

    return (
        <Select
            {...props}
            value={props.value}
            options={options}
            onInputChange={(value) => setInputValue(value)}
            onChange={props.onChange}
            isSearchable
            placeholder={props.placeholder}
        />
    );
};

export default DebouncedDropdown;
