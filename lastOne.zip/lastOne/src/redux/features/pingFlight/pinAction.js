import axios from 'axios';
import { createAsyncThunk } from '@reduxjs/toolkit';

const backendURL = process.env.REACT_APP_REST_API_URL || "http://localhost:8080";
const ADD_PIN_FLIGHT_URL =  backendURL + "/api/v1/userpingedflight";
const GET_PIN_FLIGHT_URL =  backendURL + "/api/v1/userpingedflight";
const ADD_PIN_INSPIRATION_URL =  backendURL + "/api/v1/userpinnedinspiration";
const GET_PIN_INSPIRATION_URL =  backendURL + "/api/v1/userpinnedinspiration";
const DELETE_PIN_FLIGHT_URL =  backendURL + "/api/v1/userpingedflight/flight";
const DELETE_PIN_INSPIRATION_URL =  backendURL + "/api/v1/userpinnedinspiration/id";
const ADD_PIN_PICKUP_DROP_URL =  backendURL + "/api/v1/userpinnedpickupdrop";
const GET_PIN_PICKUP_DROP_URL =  backendURL + "/api/v1/userpinnedpickupdrop";
const DELETE_PIN_PICKUP_DROP_URL =  backendURL + "/api/v1/userpinnedpickupdrop/id";
const bearerToken = localStorage.getItem('userToken')
  ? localStorage.getItem('userToken')
  : null


//   const formateCartData = (data) => {
//     let d = {};
//     Object.keys(data.cart).forEach(key => {
//         if (data.cart[key]) {
//             d[key] = data.cart[key]
//         } else {
//             d[key] = {}
//         }
//     })
//    return d
// }

export const addPinFlight = createAsyncThunk(
  'pinAction/addPinFlight',
  async (payload, { rejectWithValue }) => {
    try {
      const config = {
        headers: {
          "Content-Type" : 'application/json',
          'Authorization': `Bearer ${payload.token}`
        },
      }
      const inputData = { 
        'flightNo': payload.flightNo, 
        'scheduleDate':payload.scheduleDate, 
        'time':payload.time, 
        'source': payload.source,
        'destination': payload.destination,
        'terminal': payload.terminal,
        'gate': payload.gate, 
        'flightId': payload.flightId,
        'flightDepartArrivalStatus': payload.flightDepartArrivalStatus,
        'flightType':payload.flightType,
        'zone':payload.zone, 
        'boardingTime':payload.boardingTime 
    }
      const { data } = await axios.post(
        ADD_PIN_FLIGHT_URL,
        inputData,
        config
      )
      // console.log("inside addPinFlight data ->",data)
      return data;
    } catch (error) {
      if (error.response && error.response.data.message) {
        return rejectWithValue(error.response.data.message)
      } else {
        return rejectWithValue(error.message)
      }
    }
  }
);

export const deletePinFlight = createAsyncThunk(
  'pinAction/deletePinFlight',
  async (payload, { rejectWithValue }) => {
    try {
      const config = {
        headers: {
          "Content-Type" : 'application/json',
          'Authorization': `Bearer ${payload.token}`
        },
      }
      const { data } = await axios.delete(
        `${DELETE_PIN_FLIGHT_URL}/${payload.flightNo}`,
        config
      )
      // console.log("inside deletePinFlight data ->",data)
      return data;
    } catch (error) {
      if (error.response && error.response.data.message) {
        return rejectWithValue(error.response.data.message)
      } else {
        return rejectWithValue(error.message)
      }
    }
  }
);

// console.log(ADD_PIN_INSPIRATION_URL)
export const addPinInspiration = createAsyncThunk(
  'pinAction/addPinInspiration',
  async (payload, { rejectWithValue }) => {
    try {
      const config = {
        headers: {
          "Content-Type" : 'application/json',
          'Authorization': `Bearer ${payload.token}`
        },
      }
      const inputData = { 
        'place': payload.place, 
        'location': payload.location, 
        'scheduleMonth':payload.scheduleMonth
      }
      const { data } = await axios.post(
        ADD_PIN_INSPIRATION_URL,
        inputData,
        config
      )
      // console.log("inside addPinInspiration data ->",data)
      return data;
    } catch (error) {
      if (error.response && error.response.data.message) {
        return rejectWithValue(error.response.data.message)
      } else {
        return rejectWithValue(error.message)
      }
    }
  }
);

export const deletePinInspiration = createAsyncThunk(
  'pinAction/deletePinInspiration',
  async (payload, { rejectWithValue }) => {
    try {
      const config = {
        headers: {
          "Content-Type" : 'application/json',
          'Authorization': `Bearer ${payload.token}`
        },
      }
      const { data } = await axios.delete(
        `${DELETE_PIN_INSPIRATION_URL}/${payload.id}`,
        config
      )
      // console.log("inside deletePinInspiration data ->",data)
      return data;
    } catch (error) {
      if (error.response && error.response.data.message) {
        return rejectWithValue(error.response.data.message)
      } else {
        return rejectWithValue(error.message)
      }
    }
  }
);

export const addPinPickupDrop = createAsyncThunk(
  'pinAction/addPinPickupDrop',
  async (payload, { rejectWithValue }) => {
    try {
      const config = {
        headers: {
          "Content-Type" : 'application/json',
          'Authorization': `Bearer ${payload.token}`
        },
      }
      const inputData = { 
        'terminal': payload.terminal, 
        'scheduleDate':payload.scheduleDate, 
        'time': payload.time 
      }
    
      const { data } = await axios.post(
        ADD_PIN_PICKUP_DROP_URL,
        inputData,
        config
      )
      // console.log("inside addPinPickupDrop data ->",data)
      return data;
    } catch (error) {
      if (error.response && error.response.data.message) {
        return rejectWithValue(error.response.data.message)
      } else {
        return rejectWithValue(error.message)
      }
    }
  }
);

export const deletePinPickupDrop = createAsyncThunk(
  'pinAction/deletePinPickupDrop',
  async (payload, { rejectWithValue }) => {
    try {
      const config = {
        headers: {
          "Content-Type" : 'application/json',
          'Authorization': `Bearer ${payload.token}`
        },
      }
      const { data } = await axios.delete(
        `${DELETE_PIN_PICKUP_DROP_URL}/${payload.id}`,
        config
      )
      // console.log("inside deletePinPickupDrop data ->",data)
      return data;
    } catch (error) {
      if (error.response && error.response.data.message) {
        return rejectWithValue(error.response.data.message)
      } else {
        return rejectWithValue(error.message)
      }
    }
  }
);

export const getPinFlight = createAsyncThunk(
  'pinAction/getPinFlight',
  async (payload, { rejectWithValue }) => {
    try {
          const config = {
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${payload.token}`
            },
          }
    const response = await axios.get(GET_PIN_FLIGHT_URL, config)
      const modifiedData = response.data.map(item => {
          return {
              ...item
          };
      });
      return modifiedData;
    } 
    catch (error) {
            if (error.response && error.response.data.message) {
              return rejectWithValue(error.response.data.message)
            } else {
              return rejectWithValue(error.message)
            }
          }
      }
);

export const getPinPickupDrop = createAsyncThunk(
  'pinAction/getPinPickupDrop',
  async (payload, { rejectWithValue }) => {
    try {
          const config = {
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${payload.token}`
            },
          }
    const response = await axios.get(GET_PIN_PICKUP_DROP_URL, config)
      const modifiedData = response.data.map(item => {
          return {
              ...item
          };
      });
      return modifiedData;} catch (error) {
            if (error.response && error.response.data.message) {
              return rejectWithValue(error.response.data.message)
            } else {
              return rejectWithValue(error.message)
            }
          }
      }
);

export const getPinInspiration = createAsyncThunk(
  'pinAction/getPinInspiration',
  async (payload, { rejectWithValue }) => {
    try {
          const config = {
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${payload.token}`
            },
          }
    const response = await axios.get(GET_PIN_INSPIRATION_URL, config)
      const modifiedData = response.data.map(item => {
          return {
              ...item
          };
      });
      return modifiedData;} catch (error) {
            if (error.response && error.response.data.message) {
              return rejectWithValue(error.response.data.message)
            } else {
              return rejectWithValue(error.message)
            }
          }
      }
);

