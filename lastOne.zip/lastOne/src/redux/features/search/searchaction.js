import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

const backendURL = process.env.REACT_APP_REST_API_URL || "http://localhost:8080";

const initialState = {
  SearchCategoryResults: [],
  error: null,
  loading: false,
};

export const fetchSearchCategoryResults = createAsyncThunk(
  'search/tag',
  async ({ tag, category }, { rejectWithValue }) => {
    try {
      // console.log("inside fetchSearchResults")
      // console.log("tag is:",tag)
      // console.log("category is:",category)
      // console.log(`${backendURL}/api/v1/airportservices/search?tag=${tag}&category=${category}`);
      const response = await axios.get(`${backendURL}/api/v1/airportservices/search?tag=${tag}&category=${category}`);
      // console.log("search result is", response.data)
      return response.data;
    } catch (error) {
      if (error.response && error.response.data.message) {
        return rejectWithValue(error.response.data.message)
      } else {
        return rejectWithValue(error.message)
      }
    }
  }
);


const fetchSearchCategoryResultsSlice = createSlice({
  name: 'SearchCategoryResults',
  initialState,
  reducers: {
    resetSearchCategoryResults: (state) => {
      // console.log("********search reset*********")
      state.SearchCategoryResults = [];
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchSearchCategoryResults.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchSearchCategoryResults.fulfilled, (state, action) => {
        state.loading = false;
        state.SearchCategoryResults = action.payload;
      })
      .addCase(fetchSearchCategoryResults.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      });
  },
});

export const fetchSearchCategoryResultsSliceAction = {
  fetchSearchCategoryResults,
};
export const { resetSearchCategoryResults } = fetchSearchCategoryResultsSlice.actions;
export default fetchSearchCategoryResultsSlice.reducer;