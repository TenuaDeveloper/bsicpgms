import axios from 'axios'
import { createAsyncThunk } from '@reduxjs/toolkit'
const backendURL = process.env.REACT_APP_REST_API_URL || "http://localhost:8080";
const SIGIN_IN_URL =  backendURL + "/api/auth/signin";
const SIGN_UP_URL = backendURL + "/api/auth/signup"
export const userLogin = createAsyncThunk(
  'user/login',
  async ({ username, password }, { rejectWithValue }) => {
    try {
      // configure header's Content-Type as JSON
      const config = {
        headers: {
          'Content-Type': 'application/json',
        },
      }

      const { data } = await axios.post(
        SIGIN_IN_URL,
        { username, password },
        config
      )
// console.log("All Response Data in SIGIN_IN_URL======> ",data)
      // store user's token in local storage
      // console.log("logged in",data.accessToken)
      localStorage.setItem('userToken', data.accessToken)

      return data
    } catch (error) {
      // return custom error message from API if any
      if (error.response && error.response.data.message) {
        return rejectWithValue(error.response.data.message)
      } else {
        return rejectWithValue(error.message)
      }
    }
  }
)

export const userSignUp = createAsyncThunk(
  'user/SignUp',
  async ({ username, email, phone, password }, { rejectWithValue }) => {
    try {
      // configure header's Content-Type as JSON
      const config = {
        headers: {
          'Content-Type': 'application/json',
        },
      }

      const data = await axios.post(
        SIGN_UP_URL,
        {username, email, phone, password },
        config
      )

      // store user's token in local storage
      // localStorage.setItem('userToken', data.accessToken)

      return {...data, username, password}
    } catch (error) {
      // return custom error message from API if any
      if (error.response && error.response.data.message) {
        return rejectWithValue(error.response.data.message)
      } else {
        return rejectWithValue(error.message)
      }
    }
  }
)

export const registerUser = createAsyncThunk(
  'user/register',
  async ({ username, email,phoneno, password }, { rejectWithValue }) => {
    try {
      const config = {
        headers: {
          'Content-Type': 'application/json',
        },
      }
      
          // console.log("Is REached", username, email,phoneno, password,SIGN_UP_URL)
      const res = await axios.post(
        // `${backendURL}/api/user/register`,
        SIGN_UP_URL,
        { username, email,phoneno, password },
        config
      )
    } catch (error) {
      // console.log("ERROR : ", error)
      if (error.response && error.response.data.message) {
        return rejectWithValue(error.response.data.message)
      } else {
        return rejectWithValue(error.message)
      }
    }
  }
)
