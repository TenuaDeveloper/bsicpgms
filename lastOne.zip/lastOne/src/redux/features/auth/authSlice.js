import { createSlice } from '@reduxjs/toolkit'
import { userSignUp, userLogin } from './authActions'
// initialize userToken from local storage
const userToken = localStorage.getItem('userToken')
  ? localStorage.getItem('userToken')
  : null

const initialState = {
  loading: false,
  userInfo: null,
  profile: null,
  userToken,
  error: null,
  success: false,
  userSignUpInfo: {}
}

const authSlice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    logout: (state) => {
      localStorage.clear(); // clear the entire local storage
      // localStorage.removeItem('userToken') // delete token from storage
      state.loading = false
      state.userInfo = null
      state.userToken = null
      state.error = null
    },
    setCredentials: (state, { payload }) => {
      state.userInfo = payload
    },

    updateProfile: (state, { payload }) => {
      state.profile = payload
    },
    onRegisterStart: () => {
      return initialState
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(userLogin.pending ,(state) => {
      state.loading = true
      state.error = null
    })
    .addCase(userLogin.fulfilled, (state, { payload }) => {
      state.loading = false
      state.userInfo = payload
      state.userToken = payload.accessToken
    })
    .addCase(userLogin.rejected, (state, { payload }) => {
      state.loading = false
      state.error = payload
    })
    .addCase(userSignUp.pending, (state) => {
      state.loading = true
      state.error = null
    })
    .addCase(userSignUp.fulfilled, (state, { payload }) => {
      // console.log("CALLED")
      state.loading = false
      state.success = true // registration successful
      state.userSignUpInfo = {
        username: payload.username,
        password: payload.password
      }
    })
    .addCase(userSignUp.rejected, (state, { payload }) => {
      state.loading = false
      state.error = payload
    })
  }
})

export const { logout, setCredentials ,updateProfile, onRegisterStart} = authSlice.actions

export default authSlice.reducer

