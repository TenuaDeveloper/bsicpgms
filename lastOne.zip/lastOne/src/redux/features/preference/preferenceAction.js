import { combineReducers, createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import axios from 'axios';
import { logout } from '../auth/authSlice';

const backendURL = process.env.REACT_APP_REST_API_URL || 'http://localhost:8080';
const ADD_PREFERENCE = `${backendURL}/api/v1/userpreference/add`;
const GET_USER_PREFERENCE = `${backendURL}/api/v1/userpreference`;
const GET_ALL_PREFERENCE = `${backendURL}/api/v1/airportservices/category`;
const DELETE_PREFERENCE = `${backendURL}/api/v1/userpreference/delete/category`

const preferenceItems = [
  "Watches",
  "Electronics",
  "Cosmetics",
  "Chocolates",
  "Fashion",
  "Resturant",
  "Lounge",
  "Toys",
  "Hotel",
  "Fragrances",
  "Flight Ticket",
  "Parking",
  "Passenger Service",
  "Bags",
  "Food and Beverages",
  "Liquor"
]

const bearerToken = localStorage.getItem('userToken')
  ? localStorage.getItem('userToken')
  : null

// Define the initial state
const preferenceInitialState = {
  preference: [],
  error: null,
  loading: false,
};

const userPreferenceInitialState = {
  userpreference: [],
  error: null,
  loading: false,
};

export const fetchPreference = createAsyncThunk(
  'preference/fetchpreference',
  async () => {
    const response = await axios.get(GET_ALL_PREFERENCE);
    if (response.data){
      console.log(response.data);
      return response.data;
    }else{
      return preferenceItems;
    }
    
  }
);

export const fetchExistingPreference = createAsyncThunk(
  'fetchexisitngpreference/preference',
  async (payload) => {
    const config = {
      headers: {
        "Content-Type": 'application/json',
        Authorization: `Bearer ${payload.token}`
      },
    }
    const { data } = await axios.get(
      GET_USER_PREFERENCE,
      config
    )
    return data;
  }
);

export const storeUserPreference = createAsyncThunk(
  'storeuserpreference/preference',
  async (inputData, { rejectWithValue }) => {
    try {
      const config = {
        headers: {
          "Content-Type": 'application/json',
          Authorization: `Bearer ${inputData.token}`
        },
      }
      const { data } = await axios.post(
        ADD_PREFERENCE,
        inputData,
        config
      )
      return data;
    } catch (error) {
      if (error.response && error.response.data.message) {
        return rejectWithValue(error.response.data.message)
      } else {
        return rejectWithValue(error.message)
      }
    }
  }
);

export const deletePreference = createAsyncThunk(
  'preference/del',
  async (inputData, { rejectWithValue }) => {
    try {
      const config = {
        headers: {
          "Content-Type" : 'application/json',
          Authorization : `Bearer ${inputData.token}`
        },
      }
      const { data } = await axios.delete(
        `${DELETE_PREFERENCE}/${inputData.category}`,
        config
      )
      // console.log("inside removefav data ->",data)
      return data;
    } catch (error) {
      if (error.response && error.response.data.message) {
        return rejectWithValue(error.response.data.message)
      } else {
        return rejectWithValue(error.message)
      }
    }
  }
);

const preferenceListSlice = createSlice({
  name: 'preference',
  initialState: preferenceInitialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchPreference.pending, (state) => {
        return { ...state, loading: true, error: null };
      })
      .addCase(fetchPreference.fulfilled, (state, action) => {
        return { ...state, loading: false, preference: action.payload };
      })
      .addCase(fetchPreference.rejected, (state, action) => {
        return { ...state, loading: false, error: action.error.message };
      });
  },
});

const preferenceUserSlice = createSlice({
  name: 'userpreference',
  initialState: userPreferenceInitialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchExistingPreference.pending, (state) => {
        return { ...state, loading: true, error: null };
      })
      .addCase(fetchExistingPreference.fulfilled, (state, action) => {
        return { ...state, loading: false, userpreference: action.payload };
      })
      .addCase(fetchExistingPreference.rejected, (state, action) => {
        return { ...state, loading: false, error: action.error.message };
      })
      .addCase(logout, (state) => {
          state.userpreference = []; // clear personalizedServicesAndOffers array
          state.error = null;
          state.loading = false;
      });
  },
});

const rootReducer = combineReducers({
  preference: preferenceListSlice.reducer,
  userpreference: preferenceUserSlice.reducer,
});

export default rootReducer;
export const preferenceActions = {
  fetchPreference,
  fetchExistingPreference,
};