import { createSlice } from '@reduxjs/toolkit'
import { toast } from 'react-toastify';
import { getPinInspiration } from '../pingFlight/pinAction'
import { logout } from '../auth/authSlice';

const initialState = {
  inspirationList:[],
  error: null
 
}

const pinInspirationSlice = createSlice({
  name: 'pinInspiration',
  initialState,
  reducers: {
    addInspiration: (state,action) => {
      if(!state.inspirationList.some(item => item.location === action.payload.location && item.scheduleMonth === action.payload.scheduleMonth)){
        let newInspiration = {
            id:  state.inspirationList.length + 1,
            place: action.payload.place,
            location: action.payload.location,
            scheduleMonth:  action.payload.scheduleMonth,
            active: true,
            selected: false
          }
          state.inspirationList.push( newInspiration);
        }else {
        }
        if (state.inspirationList.length === 1) {
          state.inspirationList[0].selected = true;
        } 
      },

      selectInspiration: (state, action) => {
        const selectedItem = state.inspirationList.find(item => item.id === action.payload.id);
      
        if (selectedItem) {
          // If the selected item is one of the first three items in the list, just update its 'selected' property
          if (state.inspirationList.indexOf(selectedItem) < 3) {
            selectedItem.selected = true;
          } else {
            // Otherwise, remove the selected item from its current position and insert it at the front of the array
            state.inspirationList.splice(state.inspirationList.indexOf(selectedItem), 1);
            state.inspirationList.unshift(selectedItem);
            selectedItem.selected = true;
          }
          // Deselect all items except the selected item
          state.inspirationList.forEach(item => {
            if (item !== selectedItem) {
              item.selected = false;
            }
          });
        }
      },      
      
      unSelectInspiration: (state, action) => {
        const selectedItemIndex = state.inspirationList.findIndex(
          (item) => item.id === action.payload.id
        );
      
        if (selectedItemIndex !== -1) {
          state.inspirationList[selectedItemIndex].selected = false;
        }
      },      

     deleteInspiration: (state, action) => {
        let { inspirationList } = state;
        // console.log(state,"=========Delete action" ,action)
        state.inspirationList = inspirationList.filter((item) => 
            item.id !==action.payload.id);
      },

      editInspiration: (state, action) => {
        let { inspirationList } = state;
        state.inspirationList = inspirationList.map((item) => 
          item.id === action.payload.id ? action.payload : item);
      }
  },
  extraReducers: (builder) => {
    builder
    .addCase(getPinInspiration.pending, (state) => {
      state.loading = true
      state.error = null
    })
    .addCase(getPinInspiration.fulfilled, (state, action) => {
      state.loading = false;
      state.inspirationList = action.payload;
    })
    .addCase(getPinInspiration.rejected, (state, { payload }) => {
      state.loading = false
      state.error = payload
    })
    .addCase(logout, (state) => {
        state.inspirationList = []; // clear inspirationList array
        state.error = null;
        state.loading = false;
    });
  }
})

export const { addInspiration, deleteInspiration, editInspiration,selectInspiration, unSelectInspiration } = pinInspirationSlice.actions
export default pinInspirationSlice.reducer;