import { createSlice } from '@reduxjs/toolkit'
import { getPinPickupDrop } from '../pingFlight/pinAction'
import { logout } from '../auth/authSlice';

const initialState = {
    pickupDropList:[],
  error: null
 
}

const pinPickupDropSlice = createSlice({
  name: 'pinPickupDrop',
  initialState,
  reducers: {
    addPickupDrop: (state,action) => {
      if(!state.pickupDropList.some(item => item.terminal === action.payload.terminal && item.scheduleDate === action.payload.scheduleDate) ){
        let newPickupDrop = {
            id:  state.pickupDropList.length + 1,
            terminal:  action.payload.terminal,
            scheduleDate:  action.payload.scheduleDate,
            time:  action.payload.time,
            terminalName:  action.payload.terminalName,
            active: true
          }
          state.pickupDropList.push(newPickupDrop);
          state.error = ""
        }else {
        }
        if (state.pickupDropList.length === 1) {
          state.pickupDropList[0].selected = true;
        }
      },

      selectPinPickupDrop: (state, action) => {
        const selectedItem = state.pickupDropList.find(item => item.id === action.payload.id);
      
        if (selectedItem) {
          // If the selected item is one of the first three items in the list, just update its 'selected' property
          if (state.pickupDropList.indexOf(selectedItem) < 3) {
            selectedItem.selected = true;
          } else {
            // Otherwise, remove the selected item from its current position and insert it at the front of the array
            state.pickupDropList.splice(state.pickupDropList.indexOf(selectedItem), 1);
            state.pickupDropList.unshift(selectedItem);
            selectedItem.selected = true;
          }
          // Deselect all items except the selected item
          state.pickupDropList.forEach(item => {
            if (item !== selectedItem) {
              item.selected = false;
            }
          });
        }
      },      
      
      unSelectPinPickupDrop: (state, action) => {
        const selectedItemIndex = state.pickupDropList.findIndex(
          (item) => item.id === action.payload.id
        );
      
        if (selectedItemIndex !== -1) {
          state.pickupDropList[selectedItemIndex].selected = false;
        }
      },
      
     deletePickupDrop: (state, action) => {
        let { pickupDropList } = state;
        // console.log(state,"=========Delete action" ,action)
        state.pickupDropList = pickupDropList.filter((item) => 
            item.id !==action.payload.id);
      },

      editPickupDrop: (state, action) => {
        let { pickupDropList } = state;
        state.pickupDropList = pickupDropList.map((item) => 
          item.id === action.payload.id ? action.payload : item);
      }
  },
  extraReducers: (builder) => {
    builder
    .addCase(getPinPickupDrop.pending, (state) => {
      state.loading = true
      state.error = null
    })
    .addCase(getPinPickupDrop.fulfilled, (state, action) => {
      state.loading = false;
      const currentDateTime = new Date();
    
      state.pickupDropList = action.payload.filter((pickupDrop) => {
        const [day, month, year] = pickupDrop.scheduleDate.split('-');
        const pickupDropDateTime = new Date(`${year}-${month}-${day}`);
        return pickupDropDateTime >= currentDateTime;
      });
    })
    .addCase(getPinPickupDrop.rejected, (state, { payload }) => {
      state.loading = false
      state.error = payload
    })
    .addCase(logout, (state) => {
        state.pickupDropList = []; // clear inspirationList array
        state.error = null;
        state.loading = false;
    });
  }
})

export const { addPickupDrop, deletePickupDrop, editPickupDrop, selectPinPickupDrop, unSelectPinPickupDrop } = pinPickupDropSlice.actions
export default pinPickupDropSlice.reducer;
