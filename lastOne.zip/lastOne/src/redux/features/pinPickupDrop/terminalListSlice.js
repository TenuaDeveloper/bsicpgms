import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

const backendURL = process.env.REACT_APP_REST_API_URL || "http://localhost:8080";

// Define the initial state
const initialState = {
    terminallist: [],
    error: null,
    loading: false,
};

export const fetchPickDropTerminalData = createAsyncThunk(
    'terminallist/fetchPickDropTerminalData',
    async (date) => {
        const response = await axios.get(`${backendURL}/api/v1/flightschedule/terminal/${date}`);
        const modifiedData = response.data.map(item => {
            return {
                ...item,
                terminal:item,
                label: `Terminal ${item}`
            };
        });
        return modifiedData;
    }
);

// Define the locationListSlice slice
const terminalListSlice = createSlice({
    name: 'terminallist',
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
        .addCase(fetchPickDropTerminalData.pending, (state) => {
            state.loading = true;
            state.error = null;
        })
        .addCase(fetchPickDropTerminalData.fulfilled, (state, action) => {
            state.loading = false;
            state.terminallist = action.payload;
        })
        .addCase(fetchPickDropTerminalData.rejected, (state, action) => {
            state.loading = false;
            state.error = action.error.message;
        });
    },
});



// Export the action creators
export const terminalListActions = {
    fetchPickDropTerminalData,
};
export default terminalListSlice.reducer;