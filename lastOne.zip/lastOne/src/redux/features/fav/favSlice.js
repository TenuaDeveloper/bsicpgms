import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

// initialize userToken from local storage
const userToken = localStorage.getItem("userToken")
  ? localStorage.getItem("userToken")
  : null;

const initialState = {
  loading: false,
  userToken,
  error: null,
  success: false,
  favoriteItems: [],
};

const favSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    updateFavoriteItems: (state, { payload }) => {
      state.favoriteItems = payload;
    },
  },
});

export const fetchFavoriteItems = createAsyncThunk(
  "favorites/fetchFavoriteItems",
  async (_, thunkAPI) => {
    try {
      const response = await thunkAPI.extraArgument.getFav();
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response.data);
    }
  }
);

const favoriteItemsSlice = createSlice({
  name: "favoriteItems",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchFavoriteItems.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchFavoriteItems.fulfilled, (state, { payload }) => {
        state.loading = false;
        state.favoriteItems = payload;
        state.error = null;
      })
      .addCase(fetchFavoriteItems.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
      });
  },
});

export const {
  updateFavoriteItems,
} = favSlice.actions;

export const favReducer = favSlice.reducer;
export const favoriteItemsReducer = favoriteItemsSlice.reducer;
