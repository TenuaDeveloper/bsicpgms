import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { logout } from '../auth/authSlice';

const backendURL = process.env.REACT_APP_REST_API_URL || "http://localhost:8080";
// const backendURL = "http://localhost:8080";
const GET_FAV_URL =  backendURL + "/api/v1/favourites/listFavouriteItems";
const bearerToken = localStorage.getItem('userToken')
  ? localStorage.getItem('userToken')
  : null

// Define the initial state
const initialState = {
    favourite: [],
    error: null,
    loading: false,
};

// Define the async thunk for fetching Purchases
export const fetchFavourites = createAsyncThunk(
    'favourite/fetchFavourites',
    async (payload) => {
        const response = await axios.get(`${GET_FAV_URL}`, {
            headers: {
              Authorization: `Bearer ${payload.token}`,
            },
          })
        // console.log("fetchFavourites: "+JSON.stringify(response.data)); // log the response data
        return response.data;
        }
);

// Define the purchaseListSlice 
const favouriteSlice = createSlice({
    name: 'favourite',
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
        .addCase(fetchFavourites.pending, (state) => {
            state.loading = true;
            state.error = null;
        })
        .addCase(fetchFavourites.fulfilled, (state, action) => {
            state.loading = false;
            state.favourite = action.payload;
        })
        .addCase(fetchFavourites.rejected, (state, action) => {
            state.loading = false;
            state.error = action.error.message;
        })
        .addCase(logout, (state) => {
            state.favourite = []; // clear favourite array
            state.error = null;
            state.loading = false;
        });
    },
});



// Export the action creators
export const favouriteActions = {
    fetchFavourites,
};
export default favouriteSlice.reducer;