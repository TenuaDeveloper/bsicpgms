import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import _ from 'lodash';

const backendURL = process.env.REACT_APP_REST_API_URL || "http://localhost:8080";
// const backendURL = "http://localhost:8080";

// new url
// const recommendedbackendURL = "https://af2eui6vdd.execute-api.ap-south-1.amazonaws.com/default/recommendation_airport";

// old url
// const recommendedbackendURL = "https://ybhxg44xf1.execute-api.ap-south-1.amazonaws.com/default/get_recommendation_dxi";


// Define the initial state
const initialState = {
    newPersonalizedServicesAndOffers: [],
    error: null,
    loading: false,
};

// Define the async thunk for fetching personalizedServicesAndOffers
export const fetchPersonalizedServicesAndOffers = createAsyncThunk(
    'services/newPersonalizedServicesAndOffers',
    async (payload) => {

        // console.log("Started fetchPersonalizedServicesAndOffers....", payload)
        const response = await axios({
            method: "post",
            url: `${backendURL}/api/v1/serachfilter/personalizedoffers?${payload.filter}`,
            timeout: 1000 * 15, // Wait for 5 seconds
            headers: {
              "Content-Type": "application/json"
            },
            data: payload.req            
          })
        //   console.log("End fetchPersonalizedServicesAndOffers....", response.data)

        // console.log("airportservices: "+JSON.stringify(response.data)); // log the response data
        // data.selectedPageNo
        
        return { "resultData": response.data.resultData, "pageNo": payload.selectedPageNo, "filterType": payload.filterType};
        }
);

// Define the personalizedServicesAndOffers slice
const personalizedServicesAndOffersSlice = createSlice({
    name: 'newPersonalizedServicesAndOffers',
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
        .addCase(fetchPersonalizedServicesAndOffers.pending, (state) => {
            state.loading = true;
            state.error = null;
        })
        .addCase(fetchPersonalizedServicesAndOffers.fulfilled, (state, action) => {
            state.loading = false;
            // console.log("reduxxx", action.payload)
            let filterType = "services";
            if(action.payload.filterType == "popular") {
                filterType = "poular";
            } else if(action.payload.filterType == "promotions") {
                filterType = "promotions";
            }
            const serviceTypeList = Object.keys(action.payload.resultData);            
            const categoriesList = Object.keys(action.payload.resultData[filterType]);
            
            // console.log(categoriesList, serviceTypeList)
            var newArray = [];
            var satisfied = false;
            var counter = 0;
            var maxlength = 0;
            // console.log(action.payload.resultData)
            categoriesList.forEach(item1 => {
                serviceTypeList.forEach(item2 => {
                    if(action.payload.resultData[item2][item1] != undefined && action.payload.resultData[item2][item1] && action.payload.resultData[item2][item1].length > 0) {
                        maxlength = action.payload.resultData[item2][item1].length + maxlength;
                    }
                })                              
            })
            while (!satisfied) {
                categoriesList.forEach(item1 => {
                    serviceTypeList.forEach(item2 => {
                        if(action.payload.resultData[item2][item1] != undefined && action.payload.resultData[item2][item1] && action.payload.resultData[item2][item1].length > 0) {
                        // console.log("insidefunc", action.payload.resultData[item2][item1])
                        if(newArray.length == 32*action.payload.pageNo) {
                            satisfied = true;
                            return;
                        }
                        if(newArray.length == maxlength) {
                            satisfied = true;
                            return;
                        }
                        var slicedServices = action.payload.resultData[item2][item1].slice(0+counter, 1+counter);
                        newArray = [...newArray, ...slicedServices];
                    }
                    })                                     
                })
                counter++;
                if(counter > maxlength) {
                    counter = 0;
                }
            } 
            const returnData = {"servicesAndOffers" : newArray, "pageNo": action.payload.pageNo}  
            // console.log(returnData)          
            // state.newPersonalizedServicesAndOffers = action.payload;
            state.newPersonalizedServicesAndOffers = returnData;
        })
        .addCase(fetchPersonalizedServicesAndOffers.rejected, (state, action) => {
            state.loading = false;
            state.error = action.error.message;
        });
    },
});



// Export the action creators
export const personalizedServicesAndOffersActions = {
    fetchPersonalizedServicesAndOffers,
};
export default personalizedServicesAndOffersSlice.reducer;