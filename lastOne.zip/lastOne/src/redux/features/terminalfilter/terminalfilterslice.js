import { createSlice } from '@reduxjs/toolkit';
import { terminalFilter, recentSearch } from './terminalfilterAction';
import { logout } from '../auth/authSlice';

const initialState = {
  purchases: [],
  loading: false,
  error: null
};

const terminalSlice = createSlice({
  name: 'terminal',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(terminalFilter.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(terminalFilter.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(terminalFilter.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  }
});

const recentSearchSlice = createSlice({
  name: 'recentSearch',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(recentSearch.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(recentSearch.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(recentSearch.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
  }
});

export const terminalReducer = terminalSlice.reducer;
export const recentSearchReducer = recentSearchSlice.reducer;
