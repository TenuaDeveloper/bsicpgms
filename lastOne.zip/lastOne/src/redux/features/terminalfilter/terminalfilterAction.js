import axios from 'axios';
import { createAsyncThunk } from '@reduxjs/toolkit';

const backendURL = process.env.REACT_APP_REST_API_URL || 'http://localhost:8080';
const TERMINAL_FILTER_ENDPOINT = `${backendURL}/api/v1/airportservices/fetch/byFlightIds`;
const GET_SEARCHED_ITEM =  `${backendURL}/api/v1/activitytracking/fetchSearched`;

const bearerToken = localStorage.getItem('userToken')
  ? localStorage.getItem('userToken')
  : null

export const terminalFilter = createAsyncThunk(
  'terminal/filter',
  async (flightNumber, { rejectWithValue }) => {
    try {
      const config = {
        headers: {
          'Content-Type': 'application/json',
        },
      };
      const { data } = await axios.get(
        `${TERMINAL_FILTER_ENDPOINT}?flightList=${flightNumber}`,
        config
      );
      // console.log('Inside terminal: data ->', flightNumber,data);
      return data;
    } catch (error) {
      if (error.response && error.response.data.message) {
        return rejectWithValue(error.response.data.message);
      } else {
        return rejectWithValue(error.message);
      }
    }
  }
);

export const recentSearch = createAsyncThunk(
  'search/filter',
  async ( _, { rejectWithValue }) => {
    try {
      const config = {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${bearerToken}`
        },
      }
      const { data } = await axios.get(
        GET_SEARCHED_ITEM,
        config
      )
      return data;
    } catch (error) {
      if (error.response && error.response.data.message) {
        return rejectWithValue(error.response.data.message)
      } else {
        return rejectWithValue(error.message)
      }
    }
  }
);
