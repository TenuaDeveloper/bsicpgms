import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { logout } from '../auth/authSlice';

// new url
// const backendURL = "https://af2eui6vdd.execute-api.ap-south-1.amazonaws.com/default/recommendation_airport";

// old url
const backendURL = "https://ybhxg44xf1.execute-api.ap-south-1.amazonaws.com/default/get_recommendation_dxi";

// Define the initial state
const initialState = {
    recommendedCategories: [],
    error: null,
    loading: false,
};

// Define the async thunk for fetching recommendedCategories
export const fetchRecommendedCategories = createAsyncThunk(
    '/recommendation_airport',
    async (data) => {
        const response = await axios.post(backendURL, data);
        return response.data;
        }
);

// Define the recommendedCategories slice
const recommendedCategoriesSlice = createSlice({
    name: 'recommendedCategories',
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
        .addCase(fetchRecommendedCategories.pending, (state) => {
            state.loading = true;
            state.error = null;
        })
        .addCase(fetchRecommendedCategories.fulfilled, (state, action) => {
            state.loading = false;
            state.recommendedCategories = action.payload;
        })
        .addCase(fetchRecommendedCategories.rejected, (state, action) => {
            state.loading = false;
            state.error = action.error.message;
        })
        .addCase(logout, (state) => {
            state.recommendedCategories = []; // clear recommendedCategories array
            state.error = null;
            state.loading = false;
        });
    },
});



// Export the action creators
export const recommendedCategoriesActions = {
    fetchRecommendedCategories,
};
export default recommendedCategoriesSlice.reducer;