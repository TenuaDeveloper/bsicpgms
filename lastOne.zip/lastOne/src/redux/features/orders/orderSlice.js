import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";



const initialState = {
  loading: false,
  error: null,
  success: false,
  ordersData: [],
};


const orderSlice = createSlice({
    name: "order",
    initialState,
    reducers: {
      setOrderData: (state, { payload }) => {
        state.ordersData = payload;
      },
    },
  });


//   const OrdersItemsSlice = createSlice({
//     name: "orderedItems",
//     initialState,
//     reducers: {

//     },
//     extraReducers: (builder) => {
//       builder
//         .addCase(getOrderItems.pending, (state) => {
//           state.loading = true;
//         })
//         .addCase(getOrderItems.fulfilled, (state, { payload }) => {
//           state.loading = false;
//           state.ordersData = payload;
//           state.error = null;
//         })
//         .addCase(getOrderData.rejected, (state, { payload }) => {
//           state.loading = false;
//           state.error = payload;
//         });
//     },
//   });

  export const {
    setOrderData,
  } = orderSlice.actions;
  export default orderSlice.reducer;