import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

const backendURL = process.env.REACT_APP_REST_API_URL || "http://localhost:8080";

//Define initial State Of Arrivals

const initialState = {

    newArrivals: [],
    error: null,
    loading: false
}

//Async thunk for fetching new Arrivals
// console.log("Backend URL =====>",backendURL)
export const fetchNewArrivals = createAsyncThunk(
    'arrvals/fetchNewArrivals',
    async (payload) => {
        const response = await axios.get(`${backendURL}/api/v1/serachfilter/servicefiltersearch?${payload.terminal}`)
           console.log("Response of New Arrivals :====>",response.data)
        return response.data;
    }
);

const newarrivalSlice = createSlice({
    name: 'arrivals',
    initialState,
    reducers: {
        resetnewArrivals: (state) => {
            state.newArrivals = [];
        }
    },
    extraReducers: (builder) => {
        builder
            .addCase(fetchNewArrivals.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchNewArrivals.fulfilled, (state, action) => {
                state.loading = false;
                state.newArrivals = action.payload;
            })
            .addCase(fetchNewArrivals.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error.message;
            });
    },
});



// Export the action creators
export const arrivalActions = {
    fetchNewArrivals, resetnewArrivals: newarrivalSlice.actions.resetnewArrivals
};
// export const { resetnewArrivals } = newarrivalSlice.actions;
export default newarrivalSlice.reducer;