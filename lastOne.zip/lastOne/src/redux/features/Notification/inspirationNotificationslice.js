import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    inspnotification: []

}
const inspirationNotificationSlice = createSlice({
    name: "inspirationMessages",
    initialState,
    reducers: {
        addInspMessage: (state, action) => {
            let { inspnotification } = state;
            if (inspnotification.length < 5) {
                state.inspnotification.push(action.payload);
            }
        },
        removeInspMessage: (state, action) => {
            let { inspnotification } = state;
            inspnotification.map((item) =>
                console.log(item.index));
            console.log(action.payload, "******************removemessage")
            state.inspnotification = inspnotification.filter((item, index) =>
                index !== action.payload);
        },
        clearInspMessages: (state, action) => {
            state.inspnotification = [];
        },
    },
});

export const { addInspMessage, removeInspMessage, clearInspMessages } = inspirationNotificationSlice.actions;

export default inspirationNotificationSlice.reducer;
