import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    picknotification: []

}
const pickNotificationSlice = createSlice({
    name: "pickMessages",
    initialState,
    reducers: {
        addPickMessage: (state, action) => {
            let { picknotification } = state;
            if (picknotification.length < 5) {
                state.picknotification.push(action.payload);
            }
        },
        removePickMessage: (state, action) => {
            let { picknotification } = state;
            picknotification.map((item) =>
                console.log(item.index));
            console.log(action.payload, "******************removemessage")
            state.picknotification = picknotification.filter((item, index) =>
                index !== action.payload);
        },
        clearPickMessages: (state, action) => {
            state.picknotification = [];
        },
    },
});

export const { addPickMessage, removePickMessage, clearPickMessages } = pickNotificationSlice.actions;

export default pickNotificationSlice.reducer;
