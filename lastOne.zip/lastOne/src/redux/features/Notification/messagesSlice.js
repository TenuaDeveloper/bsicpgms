import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    notification: []

}
const messagesSlice = createSlice({
    name: "messages",
    initialState,
    reducers: {
        addMessage: (state, action) => {
            let { notification } = state;
            if (notification.length < 4) {
                state.notification.push(action.payload);
            }
        },
        removeMessage: (state, action) => {
            let { notification } = state;
            notification.map((item) =>
                console.log(item.index));
            console.log(action.payload, "******************removemessage")
            state.notification = notification.filter((item, index) =>
                index !== action.payload);
        },
        clearMessages: (state, action) => {
            state.notification = [];
        },
    },
});

export const { addMessage, removeMessage, clearMessages } = messagesSlice.actions;

export default messagesSlice.reducer;
