import { useSelector } from "react-redux";
import _ from 'lodash'
let totTalPrice;
let qty = 1
const getTotalCartCount = () => {
  let count = 0;
  const { cart } = useSelector(state => state.cart);
  totTalPrice = 0;
  Object.keys(cart).forEach(cartKey => {
    Object.keys(cart[cartKey]).forEach(key => {
      // count += cart[cartKey][key].length;
      cart[cartKey][key].map((item) => {

        qty = item.quantity === undefined ? item.unitAdded : item.quantity
        count += qty || 1
        totTalPrice = totTalPrice + ((item.unitPrice) * (qty))
      })
    })
  })
  return count;
}

const offerAmountCal = (data) => {
  let offerAmmount = 0;
  if (data.offer) {
    if (data.offerType == "Percentage") {
      offerAmmount = data.unitPrice - (data.offerPrice / 100) * data.unitPrice;
      // console.log("^^^^^^^^^^",data, offerAmmount)
    }
    if (data.offerType == "Flat") {
      offerAmmount = data.unitPrice - data.offerPrice;
    }
    if (data.offerType == "Others") {
      offerAmmount = data.unitPrice;
    }
  }
  return offerAmmount.toFixed(2);
}


const findData = (data) => {
  //checking base case
  if (_.isEmpty(data)) return false;

  // when data is there
  if (Array.isArray(data)) return true

  // check data in defth of object
  for (let key in data) {
    return findData(data[key])
  }

  return;
}

const getSelectedData = () => {
  const { cart, orders } = useSelector(state => state);
  if (findData(cart.cart)) {
    return cart.cart;
  }
  return orders.ordersData;
}

const getTotalSelectedItemPrice = () => {
  let count = 0;
  const { cart } = useSelector(state => state.cart);
  let price = 0;

  Object.keys(cart).forEach(cartKey => {
    Object.keys(cart[cartKey]).forEach(key => {
      // count += cart[cartKey][key].length;
      cart[cartKey][key].map((item) => {
        if (item) {
          //  console.log(item)
          qty = item.quantity == undefined ? item.unitAdded : item.quantity
          // qty = 1;
          if (item.offer) {
            price = price + (offerAmountCal(item) * qty)
          }
          else {
            price = price + (item.unitPrice * qty)
          }
        }

      })
    })
  })
  return price;
}

const getUnitSelectedItemPrice = () => {
  let count = 0;
  const { cart } = useSelector(state => state.cart);
  let price = 0;

  Object.keys(cart).forEach(cartKey => {
    Object.keys(cart[cartKey]).forEach(key => {
      // count += cart[cartKey][key].length;
      cart[cartKey][key].map((item) => {
        if (item) {
          qty = item.quantity == undefined ? item.unitAdded : item.quantity
          // qty = 1;
          price = price + (item.unitPrice * qty)
        }

      })
    })
  })
  return price;
}

const getOfferDiscountPrice = () => {
  let price = 0;
  const unitPrice = getUnitSelectedItemPrice();
  const totalPrice = getTotalSelectedItemPrice();
  price = unitPrice - totalPrice;
  return price;
}

const getOfferDiscount = () => {
  let price = 0;
  const unitPrice = getUnitSelectedItemPrice();
  const totalPrice = getTotalSelectedItemPrice();
  price = unitPrice - totalPrice;
  const percentage = (price / unitPrice) * 100;
  return percentage;
}


export {
  getTotalCartCount,
  totTalPrice,
  getTotalSelectedItemPrice,
  getUnitSelectedItemPrice,
  getOfferDiscountPrice,
  getOfferDiscount
}