import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';


// Define the initial state
const initialState = {
    cartPopupStatus: false,
    error: null,
    loading: false,
};

// export const fetchCartPopupStatus = createAsyncThunk(
//     'terminallist/cartPopupStatus',
//     async (data) => {
//         // const response = await axios.get(`${backendURL}/api/v1/flightschedule/terminal/${date}`);
//         // const modifiedData = response.data.map(item => {
//         //     return {
//         //         ...item,
//         //         terminal:item,
//         //         label: `Terminal ${item}`
//         //     };
//         // });
//         return data;
//     }
// );

// Define the locationListSlice slice
const cartPopupStatusSlice = createSlice({
    name: 'cartPopupStatus',
    initialState,
    reducers: {
      changeCartPopupStatusReducer: (state,action) => {
        console.log(action.payload)
          state.cartPopupStatus = action.payload;
        },
    },
    // extraReducers: (builder) => {
    //     builder
    //     .addCase(fetchCartPopupStatus.pending, (state) => {
    //         state.loading = true;
    //         state.error = null;
    //     })
    //     .addCase(fetchCartPopupStatus.fulfilled, (state, action) => {
    //         state.loading = false;
    //         state.cartPopupStatus = action.payload;
    //     })
    //     .addCase(fetchCartPopupStatus.rejected, (state, action) => {
    //         state.loading = false;
    //         state.error = action.error.message;
    //     });
    // },
});

// Export the action creators
export const { changeCartPopupStatusReducer } = cartPopupStatusSlice.actions
export default cartPopupStatusSlice.reducer;