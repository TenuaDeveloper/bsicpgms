import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { addToCartAPI, getItemInCartAPI, deleteItemInCartAPI } from './cartAction'
const userToken = localStorage.getItem("userToken")
  ? localStorage.getItem("userToken")
  : null;

// Define the initial state
const initialState = {
  cart:{
    flight:{},
    pickupDrop:{},
    inspiration:{},
    uncategorized:{},
  },
  error: {},
  loading: false,
  reedemInfo:{}
};

// Define the Cart slice
const cartSlice = createSlice({
  name: 'cart',
  initialState,
  reducers: {
    addToCart: (state, action) => {
      const { type, data, flightNumber, prodItem, productDetails } = action.payload;
      // console.log("flightNumber",flightNumber)
      if(flightNumber){
        if (state.cart[type][flightNumber]){
          let arr = state.cart[type][flightNumber];
          // let isExist = arr.filter(item => data.id = item.id).length; /// we will look into this later
          if (arr) {
            if (arr.find(ele => ele.id == data.id)) {
              arr = arr.map(ele => {
                if (ele.id == data.id) {
                  return {
                    ...ele,
                    quantity: Number(ele.quantity)+Number(data.quantity)
                  }
                }
                return ele;
              })
            } else {
              arr.push({...data, ...prodItem, "productDetails": productDetails})
            }
            state.cart[type] = {
              ...state.cart[type],
              [flightNumber]: arr
            }
          }
        } else {
          let arr = [];
          arr.push({...data, ...prodItem, "productDetails": productDetails})
          state.cart[type] = {
            ...state.cart[type],
            [flightNumber]: arr
          }
        }
      }
    else{
      let arr = [];
      arr.push({...data, ...prodItem, "productDetails": productDetails})
      state.cart[type] = {
        ...state.cart[type],
        [type]: arr
      }
    }
    },
    removeCart: (state, action) => {
      // console.log("=========== removeCart ===========")
      try {
        const {itemIndex,itemKey,type} =  action.payload
        // console.log(itemIndex+"itemIndex , itemKey"+itemKey)
        state.cart[type][itemKey] = state.cart[type][itemKey].filter((_, index) => index!==itemIndex)
        if(state.cart[type][itemKey].length===0)
        {
          delete state.cart[type][itemKey]
        }
      } catch (error) {
        // console.log("Error while removing cart", error);
      }
      
    },
    itemSelect: (state, action) => {
      const { itemIndex, key, type } = action.payload;
      state.cart[type][key] = state.cart[type][key].map((item, index) => {
        if (index === itemIndex) {
          return {
            ...item,
            selected: true
          }
        }
        return { ...item }
      });
    },
    itemUnSelect: (state, action) => {
      const { itemIndex, key, type } = action.payload;
      state.cart[type][key] = state.cart[type][key].map((item, index) => {
        if (index === itemIndex) {
          return {
            ...item,
            selected: false
          }
        }
        return { ...item }
      });
    },

    selectAll: (state, action) => {
      const { list, type } = action.payload;
      if(type==='flight'){
        for(let i = 0 ; i < list.length; i++){
          let flightId =  list[i]
          state.cart.flight[flightId] = state.cart.flight[flightId].map((item, index) => {
            return {
              ...item,
              selected: true
            }
          });
        }
      }
      else if(type==='pickupDrop'){
        for(let i = 0 ; i < list.length; i++){
          let flightNo =  list[i]
          state.cart.pickupDrop[flightNo] = state.cart.pickupDrop[flightNo].map((item, index) => {
            return {
              ...item,
              selected: true
            }
          });
        }
      }
      else if(type==='inspiration'){
        for(let i = 0 ; i < list.length; i++){
          let location =  list[i]
          state.cart.inspiration[location] = state.cart.inspiration[location].map((item, index) => {
            return {
              ...item,
              selected: true
            }
          });
        }
      }
      else if(type==='uncategorized'){
        for(let i = 0 ; i < list.length; i++){
          let key =  list[i]
          state.cart.uncategorized[key] = state.cart.uncategorized[key].map((item, index) => {
            return {
              ...item,
              selected: true
            }
          });
        }
      }
    },

    unSelectAll: (state, action) => {
      const { list, type } = action.payload;
      if(type==='flight'){
        for(let i = 0 ; i < list.length; i++){
          let flightId =  list[i]
          state.cart.flight[flightId] = state.cart.flight[flightId].map((item, index) => {
            return {
              ...item,
              selected: false
            }
          });
        }
      }
      else if(type==='pickupDrop'){
        for(let i = 0 ; i < list.length; i++){
          let flightNo =  list[i]
          state.cart.pickupDrop[flightNo] = state.cart.pickupDrop[flightNo].map((item, index) => {
            return {
              ...item,
              selected: false
            }
          });
        }
      }
      else if(type==='inspiration'){
        for(let i = 0 ; i < list.length; i++){
          let location =  list[i]
          state.cart.inspiration[location] = state.cart.inspiration[location].map((item, index) => {
            return {
              ...item,
              selected: false
            }
          });
        }
      }
      else if(type==='uncategorized'){
        for(let i = 0 ; i < list.length; i++){
          let key =  list[i]
          state.cart.uncategorized[key] = state.cart.uncategorized[key].map((item, index) => {
            return {
              ...item,
              selected: false
            }
          });
        }
      }
    },
    
    removeCartItemById: (state, action) => { // for removing paid items from the cart
      const { id, key, type } = action.payload;
      if(type==='flight'){
        const updatedFlight = state.cart.flight[key].filter(item => item.id !== id);
        state.cart.flight[key] = updatedFlight;
        if(state.cart.flight[key].length===0)
        {
          delete state.cart.flight[key]
        }
      }
      else if(type==='pickupDrop'){
        // console.log(key)
        const updatedPickup = state.cart.pickupDrop[key].filter(item => item.id !== id);
        state.cart.pickupDrop[key] = updatedPickup;
        if(state.cart.pickupDrop[key].length===0)
        {
          delete state.cart.pickupDrop[key]
        }
      }
      else if(type==='inspiration'){
        const updatedInspiration = state.cart.inspiration[key].filter(item => item.id !== id);
        state.cart.inspiration[key] = updatedInspiration;
        if(state.cart.inspiration[key].length===0)
        {
          delete state.cart.inspiration[key]
        }
      }
      else if(type==='uncategorized'){
        const updatedUncategorized = state.cart.uncategorized[key].filter(item => item.id !== id);
        state.cart.uncategorized[key] = updatedUncategorized;
        if(state.cart.uncategorized[key].length===0)
        {
          delete state.cart.uncategorized[key]
        }
      }
    },
    
    removeCartItemByPin: (state, action) => { // for removing paid items from the cart
      const { itemKey, type } = action.payload;
      // console.log(itemKey)
      delete state.cart[type][itemKey]
    },
	
    moveCartItemByPin: (state, action) => { // for moving items from pinned cart to uncategorized
      const { itemKey, type } = action.payload;
      state.cart.uncategorized['uncategorized'] = state.cart[type][itemKey].map((item, index) => {
        return {
          ...item,
          selected: false
        }
      });
    },
    resetCart:(state)=>{
        return initialState;  

    },
    addRedeemData:(state,action)=>{
      return {
        ...state,
        reedemInfo:{
          ...state.reedemInfo,
          ...action.payload
        },
      }
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(addToCartAPI.pending ,(state) => {
      state.loading = true
      state.error = {}
    })
    .addCase(addToCartAPI.fulfilled, (state, { payload }) => {
      state.loading = false
      state.error = {}
      state.cart = {
        ...state.cart,
        ...payload
      }
      //console.log("Cart payload Data========> ", payload)
      // state.cart = payload.accessToken
    })
    .addCase(addToCartAPI.rejected, (state, { payload }) => {
      state.loading = false
      state.error = payload
    })
    .addCase(getItemInCartAPI.pending, (state) => {
      state.loading = true
      state.error = null
    })
    .addCase(getItemInCartAPI.fulfilled, (state, { payload }) => {
      // console.log("CALLED", payload)
      state.loading = false
      state.cart = {
        ...state.cart,
        ...payload
      }
    })
    .addCase(getItemInCartAPI.rejected, (state, { payload }) => {
      state.loading = false
      state.error = payload
    })
  }
});

export const { addToCart, removeCart, itemSelect, itemUnSelect, selectAll, unSelectAll, removeCartItemById, removeCartItemByPin, moveCartItemByPin, resetCart,addRedeemData} = cartSlice.actions;

export default cartSlice.reducer;


