import axios from 'axios'
import { useSelector } from "react-redux";
import { createAsyncThunk } from '@reduxjs/toolkit'

const backendURL = process.env.REACT_APP_REST_API_URL || "http://localhost:8080";
const ADD_TO_CART_URL = backendURL + "/api/v1/pinned/cart/add";
const GET_CART = backendURL + "/api/v1/pinned/cart/listallcartitems/"
const DELETE_CART_URL = backendURL + "/api/v1/pinned/cart"
const UPDATE_TO_CART_URL = backendURL + "/api/v1/pinned/cart/update";

const CONFIG = {
    headers: {
        'Content-Type': 'application/json'
    }
}

const formateCartData = (data) => {
    let d = {};
    Object.keys(data.cart).forEach(key => {
        if (data.cart[key]) {
            d[key] = data.cart[key]
        } else {
            d[key] = {}
        }
    })
    // console.log("Formated Data :---",data)
   return d
}

const getCart = async (config) => {
    return await axios({
        url: GET_CART,
        method: 'get',
        headers: config.headers
        }
    )
}

export const addToCartAPI = createAsyncThunk(
    'cart/add',
    async (payload, { rejectWithValue }) => {
        try {
            // console.log("addToCartAPI called ")
            const config = {
                headers: {
                    ...CONFIG.headers,
                    'Authorization': `Bearer ${payload.token}`,
                }
                
            }
            // console.log("inspiration==================================",payload.location)
            const data = {
                "serviceId": payload.serviceId,
                "quantity": payload.quantity,
                "flightId": payload.flightId,
                "location": payload.location,
                "pinnedFlight" : payload.pinnedFlight,
                "pickupDrop" : payload.pickupDrop,
                "inspiration" : payload.inspiration,
                "terminal": payload.terminal,
                "productDetails":payload.productDetails
            }
            await axios.post(
                ADD_TO_CART_URL,
                {...data},
                config
            )
            const response = await getCart(config)
            return formateCartData(response.data);

        } catch (error) {
            // console.log("ERROR: ",error)
            // return custom error message from API if any
            if (error.response && error.response.data.message) {
                return rejectWithValue(error.response.data.message)
            } else {
                return rejectWithValue(error.message)
            }
        }
    }
)

export const getItemInCartAPI = createAsyncThunk(
    'cart/get',
    async (payload, { rejectWithValue }) => {
        try {
            // console.log("called get cart")
            const config = {
                headers: {
                    ...CONFIG.headers,
                    'Authorization': `Bearer ${payload.token}`,
                }
                
            }
            const response = await getCart(config)
            return formateCartData(response.data);
        } catch (error) {
            // console.log("ERROR: ",error)
            // return custom error message from API if any
            if (error.response && error.response.data.message) {
                return rejectWithValue(error.response.data.message)
            } else {
                return rejectWithValue(error.message)
            }
        }
    }
)

export const deleteItemInCartAPI = createAsyncThunk(
    'cart/delete',
    async (payload, { rejectWithValue }) => {
        // console.log("here - deleteItemInCartAPI")
        try {
            // console.log("called get cart")
            const config = {
                headers: {
                    ...CONFIG.headers,
                    'Authorization': `Bearer ${payload.token}`,
                }
            }
            const { data } = await axios.delete(
                `${DELETE_CART_URL}/removepinnedflightcartitem?serviceId=${payload.serviceId}&flightId=${payload.flightId}&flightType=${payload.flightType}&location=${payload.location}&terminal=${payload.terminal}`,
                config
              )
            //   console.log("inside deleteItemInCart data ->",data)
              return data;
        } catch (error) {
            // console.log("ERROR: ",error)
            // return custom error message from API if any
            if (error.response && error.response.data.message) {
                return rejectWithValue(error.response.data.message)
            } else {
                return rejectWithValue(error.message)
            }
        }
    }
)

export const deleteAllItemInCartAPI = createAsyncThunk(
    'cart/delete',
    async (payload, { rejectWithValue }) => {
        try {
            // console.log("called delete all pin cart")
            const config = {
                headers: {
                    ...CONFIG.headers,
                    'Authorization': `Bearer ${payload.token}`,
                }
            }
            const { data } = await axios.delete(
                `${DELETE_CART_URL}/removeallpinnedflightcartitems?flightId=${payload.flightId}&flightType=${payload.flightType}&location=${payload.location}&terminal=${payload.terminal}`,
                config
              )
            //   console.log("inside deleteAllItemInCart data ->",data)
              return data;
        } catch (error) {
            // console.log("ERROR: ",error)
            // return custom error message from API if any
            if (error.response && error.response.data.message) {
                return rejectWithValue(error.response.data.message)
            } else {
                return rejectWithValue(error.message)
            }
        }
    }
)

export const moveAllItemToUncategorizedCartAPI = createAsyncThunk(
    'cart/delete',
    async (payload, { rejectWithValue }) => {
        try {
            // console.log("called move all pin cart")
            const config = {
                headers: {
                  "Content-Type" : 'application/json',
                  Authorization : `Bearer ${payload.token}`
                },
              }
            const { data } = await axios.post(
                `${DELETE_CART_URL}/movepinnedcartitem?flightId=${payload.flightId}&flightType=${payload.flightType}&location=${payload.location}&terminal=${payload.terminal}`,
                payload,
                config
              )
            //   console.log("inside moveAllItemToUncategorizedCartAPI data ->",data)
              return data;
        } catch (error) {
            // console.log("ERROR: ",error)
            // return custom error message from API if any
            if (error.response && error.response.data.message) {
                return rejectWithValue(error.response.data.message)
            } else {
                return rejectWithValue(error.message)
            }
        }
    }
)

export const disCountandPoints=(data)=>{
    'cart/reddemPoints',
    ()=>data
}

export const updateCartItemAPI = createAsyncThunk(
    'cart/update',
    async (payload, { rejectWithValue }) => {
        try {
            // console.log("addToCartAPI called ")
            const config = {
                headers: {
                    ...CONFIG.headers,
                    'Authorization': `Bearer ${payload.token}`,
                }
                
            }
            // console.log("inspiration==================================",payload.location)
            const data = {
                "serviceId": payload.serviceId,
                "quantity": payload.quantity,
                "flightId": payload.flightId,
                "location": payload.location,
                "pinnedFlight" : payload.pinnedFlight,
                "pickupDrop" : payload.pickupDrop,
                "inspiration" : payload.inspiration,
                "terminal": payload.terminal,
                "productDetails":payload.productDetails
            }
            await axios.post(
                UPDATE_TO_CART_URL,
                {...data},
                config
            )
            const response = await getCart(config)
            return formateCartData(response.data);

        } catch (error) {
            // console.log("ERROR: ",error)
            // return custom error message from API if any
            if (error.response && error.response.data.message) {
                return rejectWithValue(error.response.data.message)
            } else {
                return rejectWithValue(error.message)
            }
        }
    }
)