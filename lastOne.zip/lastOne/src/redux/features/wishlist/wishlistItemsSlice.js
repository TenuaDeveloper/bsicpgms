import { createSlice } from '@reduxjs/toolkit';
import { getWishList} from './wishlistAction';
import { logout } from '../auth/authSlice';

const initialState = {
  wishlistItems: [],
};

const wishlistItemsSlice = createSlice({
  name: 'wishlistItems',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
    .addCase(getWishList.fulfilled, (state, action) => {
      state.wishlistItems = action.payload;
    })
    .addCase(logout, (state) => {
      state.wishlistItems = []; // clear wishlist array
      state.error = null;
      state.loading = false;
  });
  },
});

// Export the action creators
export const wishListActions = {
  getWishList,
};

export default wishlistItemsSlice.reducer
