import { createSlice } from '@reduxjs/toolkit';
import { addToWishList, deleteFromWishList   } from './wishlistAction';

const initialState = {
  addtowishlistItems: [],
  loading: false,
  error: null
};

const addtowishlistSlice = createSlice({
  name: 'addtowishlistItems',
  initialState,
  reducers: {
    // Other reducers for this slice can be defined here...
  },
  extraReducers: (builder) => {
    builder
      .addCase(addToWishList.pending, (state) => {
        state.loading = true;
      })
      .addCase(addToWishList.fulfilled, (state, action) => {
        state.loading = false;
        state.addtowishlistItems.push(action.payload);
      })
      .addCase(addToWishList.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
      .addCase(deleteFromWishList.pending, (state) => {
        state.loading = true;
      })
      .addCase(deleteFromWishList.fulfilled, (state, action) => {
        state.loading = false;
        state.addtowishlistItems = state.addtowishlistItems.filter(item => item.id !== action.payload);
      })
      .addCase(deleteFromWishList.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      });
  }
});

// Export the action creators
export const purchaseActions = {
  addToWishList,deleteFromWishList,
};


export default addtowishlistSlice.reducer;
