import axios from 'axios';
import { createAsyncThunk } from '@reduxjs/toolkit';

const backendURL = process.env.REACT_APP_REST_API_URL || "http://localhost:8080";
const FETCH_WISH_URL =  backendURL + "/api/v1/wishList/add";
const GET_WISH_URL =  backendURL + "/api/v1/wishList/listwishlist";
const DELETE_WISH_URL =  backendURL + "/api/v1/wishList/delete";
const bearerToken = localStorage.getItem('userToken')
  ? localStorage.getItem('userToken')
  : null

// console.log(FETCH_WISH_URL)
export const fetchWishList = createAsyncThunk(
  'wishlistItems/fetchWishList',
  async (inputData, { rejectWithValue }) => {
    try {
      const config = {
        headers: {
          "Content-Type" : 'application/json',
          Authorization : `Bearer ${bearerToken}`
        },
      }
      const { data } = await axios.post(
        FETCH_WISH_URL,
        inputData,
        config
      )
      // console.log("inside addToWishlist data ->",data)
      return data;
    } catch (error) {
      if (error.response && error.response.data.message) {
        return rejectWithValue(error.response.data.message)
      } else {
        return rejectWithValue(error.message)
      }
    }
  }
);


  export const getWishList = createAsyncThunk(
    'wishlistItems/getWishList',
    async (payload, { rejectWithValue }) => {
    try {
      const config = {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${payload.token}`
        },
      }
      const { data } = await axios.get(GET_WISH_URL, config)
      
      // console.log("inside getWishlist data ->",data)
      return data;
    } catch (error) {
      if (error.response && error.response.data.message) {
        return rejectWithValue(error.response.data.message)
      } else {
        return rejectWithValue(error.message)
      }
    }
  }
);

export const deleteWishList = createAsyncThunk(
  'wishlistItems/deleteWishList',
  async (serviceId, { rejectWithValue }) => {
    try {
      const config = {
        headers: {
          "Content-Type" : 'application/json',
          Authorization : `Bearer ${bearerToken}`
        },
      }
      const { data } = await axios.delete(
        `${DELETE_WISH_URL}/${serviceId}`,
        config
      )
      // console.log("inside removewishlist data ->",data)
      return data;
    } catch (error) {
      if (error.response && error.response.data.message) {
        return rejectWithValue(error.response.data.message)
      } else {
        return rejectWithValue(error.message)
      }
    }
  }
);
export const addToWishList = createAsyncThunk(
  'wishlistItems/addToWishList',
  async (wishproduct, thunkAPI) => {
    return wishproduct; // This value will be used as the `payload` property of the action object
  }
);
export const deleteFromWishList = createAsyncThunk(
  'wishlistItems/deleteFromWishList',
  async (id, thunkAPI) => {
    // console.log("id",id)
    return id;
  }
);