import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

const backendURL = process.env.REACT_APP_REST_API_URL || "http://localhost:8080";
// const backendURL = "http://localhost:8080";

// Define the initial state
const initialState = {
    personalizedServicesAndOffersPaginated: [],
    error: null,
    loading: false,
};

// Define the async thunk for fetching personalizedServicesAndOffers
export const fetchPersonalizedServicesAndOffersPaginated = createAsyncThunk(
    'services/personalizedServicesAndOffersPaginated',
    async (data) => {
        return data;
        }
);

// Define the personalizedServicesAndOffers slice
const personalizedServicesAndOffersPaginatedSlice = createSlice({
    name: 'offers',
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
        .addCase(fetchPersonalizedServicesAndOffersPaginated.pending, (state) => {
            state.loading = true;
            state.error = null;
        })
        .addCase(fetchPersonalizedServicesAndOffersPaginated.fulfilled, (state, action) => {
            state.loading = false;
            const serviceTypeList = Object.keys(action.payload.resultData);            
            const categoriesList = Object.keys(action.payload.resultData.offers);
            var newArray = [];
            var satisfied = false;
            var counter = 0;
            var maxlength = 0;
            while (!satisfied) {
                categoriesList.forEach(item1 => {
                    if(newArray.length == 32*action.payload.pageNo) {
                        satisfied = true;
                        return;
                    }
                    serviceTypeList.forEach(item2 => {
                        if(newArray.length == 32*action.payload.pageNo) {
                            satisfied = true;
                            return;
                        }
                        if(action.payload.resultData[item2][item1].length > maxlength) {
                            maxlength = action.payload.resultData[item2][item1].length;
                        }
                        var slicedServices = action.payload.resultData[item2][item1].slice(0+counter, 1+counter);
                        newArray = [...newArray, ...slicedServices];
                    })                    
                })
                counter++;
                if(counter > maxlength) {
                    counter = 0;
                }
            } 
            const returnData = {"servicesAndOffers" : newArray, "pageNo": action.payload.pageNo}
            state.personalizedServicesAndOffersPaginated = returnData;
        })
        .addCase(fetchPersonalizedServicesAndOffersPaginated.rejected, (state, action) => {
            state.loading = false;
            state.error = action.error.message;
        });
    },
});



// Export the action creators
export const personalizedServicesAndOffersPaginatedActions = {
    fetchPersonalizedServicesAndOffersPaginated,
};
export default personalizedServicesAndOffersPaginatedSlice.reducer;