import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

const backendURL = process.env.REACT_APP_REST_API_URL || "http://localhost:8080";

const initialState = {
    servicesAndOffersTerminal: [],
    error: null,
    loading: false,
};

// Define the async thunk for fetching services
export const fetchServicesAndOffersTerminal = createAsyncThunk(
    'services/fetchServicesAndOffers/terminal',
    async (terminalId) => {
        //console.log(terminalId,"terminalId")
        const response = await axios.get(`${backendURL}/api/v1/airportservices/getserviceoffers/${terminalId}`);
        //console.log("airportservices: "+JSON.stringify(response.data)); // log the response data
        return response.data;
        }
);

// Define the services slice
const servicesAndOffersTerminalSlice = createSlice({
    name: 'servicesAndOffersTerminal',
    initialState,
    reducers: {
        resetservicesAndOffersTerminal: (state) => {
            state.servicesAndOffersTerminal = [];
        }
    },
    extraReducers: (builder) => {
        builder
        .addCase(fetchServicesAndOffersTerminal.pending, (state) => {
            state.loading = true;
            state.error = null;
        })
        .addCase(fetchServicesAndOffersTerminal.fulfilled, (state, action) => {
            state.loading = false;
            state.servicesAndOffersTerminal = action.payload;
        })
        .addCase(fetchServicesAndOffersTerminal.rejected, (state, action) => {
            state.loading = false;
            state.error = action.error.message;
        });
    },
});



// Export the action creators
export const servicesAndOffersTerminalSliceAction = {
    fetchServicesAndOffersTerminal, resetservicesAndOffersTerminal: servicesAndOffersTerminalSlice.actions.resetservicesAndOffersTerminal
};
export default servicesAndOffersTerminalSlice.reducer;