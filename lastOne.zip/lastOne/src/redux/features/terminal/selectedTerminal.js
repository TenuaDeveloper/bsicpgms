import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

// Define the initial state
const initialState = {
  selectedTerminal: "",
  error: {},
  loading: false,
};



// Define the Cart slice
const commonSlice = createSlice({
  name: 'selectedTerminal',
  initialState,
  reducers: {
    selectedTerminalValue: (state, action) => {
      state.selectedTerminal = action.payload.option
    }
  }
});

export const { selectedTerminalValue } = commonSlice.actions;

export default commonSlice.reducer;


