import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

const backendURL = process.env.REACT_APP_REST_API_URL || "http://localhost:8080";

// Define the initial state
const initialState = {
    terminals: [],
    error: null,
    loading: false,
};

// Define the async thunk for fetching services
export const fetchTerminals = createAsyncThunk(
    'services/fetchTerminal',
    async () => {
        const response = await axios.get(`${backendURL}/api/v1/airportservices/getTerminals`);
       //console.log("airportservices: "+JSON.stringify(response.data)); // log the response data
        return response.data;
        }
);

// Define the services slice
const terminalSlice = createSlice({
    name: 'terminals',
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
        .addCase(fetchTerminals.pending, (state) => {
            state.loading = true;
            state.error = null;
        })
        .addCase(fetchTerminals.fulfilled, (state, action) => {
            state.loading = false;
            state.terminals = action.payload;
        })
        .addCase(fetchTerminals.rejected, (state, action) => {
            state.loading = false;
            state.error = action.error.message;
        });
    },
});



// Export the action creators
export const terminalActions = {
    fetchTerminals,
};
export default terminalSlice.reducer;