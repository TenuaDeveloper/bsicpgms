import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

const backendURL = process.env.REACT_APP_REST_API_URL || "http://localhost:8080";

// Define the initial state
const initialState = {
    newItems: [],
    error: null,
    loading: false,
};

// Define the async thunk for fetching new Items
export const fetchNewItems = createAsyncThunk(
    'services/fetchNewItems',
    async () => {
        const response = await axios.get(`${backendURL}/api/v1/airportservices/newitems`);
        // console.log("airportNewItems: "+JSON.stringify(response.data)); // log the response data
        return response.data;
        }
);

// Define the new items slice
const newItemsSlice = createSlice({
    name: 'newItems',
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
        .addCase(fetchNewItems.pending, (state) => {
            state.loading = true;
            state.error = null;
        })
        .addCase(fetchNewItems.fulfilled, (state, action) => {
            state.loading = false;
            state.newItems = action.payload;
        })
        .addCase(fetchNewItems.rejected, (state, action) => {
            state.loading = false;
            state.error = action.error.message;
        });
    },
});



// Export the action creators
export const newItemsActions = {
    fetchNewItems,
};
export default newItemsSlice.reducer;