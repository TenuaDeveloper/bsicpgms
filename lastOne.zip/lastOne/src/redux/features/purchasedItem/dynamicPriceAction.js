import {createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

const backendURL = process.env.REACT_APP_REST_API_URL || "http://localhost:8080";



export const fetchDynamicPrice = createAsyncThunk(
    'dynamicPrice/fetchdynamicPrice',
     async ({fromTime, toTime, serviceName}) => {
        const response = await axios.get(`${backendURL}/api/v1/purchase/dynamicprice?from=${fromTime}&to=${toTime}&serviceName=${serviceName}`);
        const totalPrice = response.data;
        return totalPrice;
    }
);
export const dynamicActions = {
    fetchDynamicPrice,
  };
