import axios from 'axios';
import { createSlice,  createAsyncThunk } from '@reduxjs/toolkit';

const backendURL = process.env.REACT_APP_REST_API_URL || "http://localhost:8080";
const Add_Purchase_URL =  backendURL + "/api/v1/purchase/addservice";
const bearerToken = localStorage.getItem('userToken')
  ? localStorage.getItem('userToken')
  : null

const initialState = {
    bookingId: "",
    error: null,
    loading: false,
  };

// console.log(Add_Purchase_URL)

export const addingPurchasedItem = createAsyncThunk(
  'purchasedItem/addingPurchasedItem ',
  async (inputdata, { rejectWithValue }) => {
    // console.log("input json is", inputdata)
    try {
      const config = {
        headers: {
          "Content-Type" : 'application/json',
          Authorization : `Bearer ${bearerToken}`
        },
      }
      const { data } = await axios.post(
        Add_Purchase_URL,
        inputdata,
        config
      )
      // console.log("purchase booking id is", data.bookingId)
      return data;
    } catch (error) {
      if (error.response && error.response.data.message) {
        return rejectWithValue(error.response.data.message)
      } else {
        return rejectWithValue(error.message)
      }
    }
  }
);

const purchasedItemSlice = createSlice({
  name: 'purchasedItem',
  initialState,
  reducers: {
    resetBookingId: (state) => {
      // console.log("********inside purchased item slice reset*********")
      state.bookingId = null;
    }
  },
  extraReducers: (builder) => {
    builder
    .addCase(addingPurchasedItem.pending, (state) => {
        state.loading = true;
        state.error = null;
    })
    .addCase(addingPurchasedItem.fulfilled, (state, action) => {
        state.loading = false;
        state.bookingId = action.payload;
    })
    .addCase(addingPurchasedItem.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
    });
},
});

export const purchaseActions = {
  addingPurchasedItem,
};

export const { resetBookingId } = purchasedItemSlice.actions;

export default purchasedItemSlice.reducer;

